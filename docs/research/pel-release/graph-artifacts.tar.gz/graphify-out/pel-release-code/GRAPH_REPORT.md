# Advisory source graph for the Pel release

This graph uses Graphify 0.9.61. It does not meet the existing 0.9.48 publication qualification.
The canonical graph and its refresh metadata remain unchanged.
Generated bundles and unsupported languages have inventory rows.
A separate vendor AST fragment covers 62 vendored files. This first-party graph excludes that fragment.
The inventory includes 690 code files and all 1,917 tracked paths.
The invalid launcher-build-bad.ts fixture has partial AST coverage.
AST extraction includes historical first-party code. These nodes do not establish current release authority.
Code extraction used zero model tokens and made no provider calls.

[graphify] MultiDiGraph edge-collapse diagnostic
input: <in-memory>
input_stage: provided JSON (normal graph.json is post-build)
effective_directed: <direct-call>
nodes: 6714
unverified_code_nodes: 0
raw_edges: 20997
valid_candidate_edges: 19443
missing_endpoint_edges: 0
dangling_endpoint_edges: 1554
self_loop_edges: 41
exact_duplicate_edges: 717
directed_unique_endpoint_pairs: 18237
directed_same_endpoint_collapsed_edges: 1206
undirected_unique_endpoint_pairs: 18229
undirected_same_endpoint_collapsed_edges: 1214
same_endpoint_group_count: 1185
relation_variant_groups: 255
source_file_variant_groups: 0
source_location_variant_groups: 223
context_variant_groups: 5
post_build_graph_type: DiGraph
post_build_edges: 18237
producer_suppression_sites: 12
producer_suppression_examples:
  - L1336 seen_ids arity=unknown
  - L1869 seen_ids arity=unknown
  - L1871 seen_doc_refs arity=unknown
  - L2241 seen_ids arity=unknown
  - L2388 seen_ids arity=unknown
  - L3026 seen_keys arity=unknown
  - L3195 seen_keys arity=unknown
  - L4887 seen_ids arity=unknown
examples:
  - components_council_packages_application_test_r3_closed_json_test -> components_council_packages_application_test_r3_closed_json_test_get edges=4 relations=['contains'] locations=['L243', 'L491', 'L558', 'L627'] contexts=['']
  - components_council_packages_application_test_r3_closed_json_test -> components_council_packages_application_test_r3_closed_json_test_ownkeys edges=3 relations=['contains'] locations=['L246', 'L547', 'L622'] contexts=['']
  - components_council_packages_application_test_r3_closed_json_test -> components_council_packages_application_test_r3_closed_json_test_getownpropertydescriptor edges=3 relations=['contains'] locations=['L249', 'L554', 'L631'] contexts=['']
  - components_council_packages_domain_test_spec_correctness_test -> components_council_packages_schema_src_index edges=3 relations=['imports_from'] locations=['L2', 'L20', 'L3'] contexts=['import']
  - components_council_packages_platform_node_src_digest -> components_council_packages_application_src_index edges=3 relations=['imports_from'] locations=['L2', 'L3', 'L6'] contexts=['import']
note: normal graph.json is post-build; raw producer loss must be measured earlier.

# Graph Report - foreman-dsl-release  (2026-09-12)

## Corpus Check
- 522 files · ~705,015 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 6714 nodes · 18237 edges · 219 communities (180 shown, 34 thin omitted)
- Extraction: 99% EXTRACTED · 1% INFERRED · 0% AMBIGUOUS · INFERRED: 183 edges (avg confidence: 0.72)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- test-helpers / errors
- identifiers / quorum.test
- fm-session-main / fm-session-main.test
- execution-terminal-policy / execution-ledger
- preflight / preflight.test
- contract-suite / entities
- preflight-program / canary-materializer
- prompt-preflight / review-admission
- supervisor-live-services / supervisor
- tracked-delete / schema
- release-coverage-cli.test
- schema-lowering / r3-closed-json.test
- release-authority / decode
- release-coverage
- run-journal / run-journal.test
- spec-correctness-admission.test / spec-correctness-admission
- vendor-preflight / vendor-preflight-live
- architecture-git / architecture-evaluate
- ready-token.test / provider-health.test
- release-coverage-cli
- admit.test / approval-commit.integration.test
- files-only / contract-suite
- outbox.test / memory-index
- tool-check-run / tool-check-cli
- graphify-qualification / graphify-qualification-main
- queue-admission / queue-cli
- resume-worktree-restore / resume-queue-execution
- session-sqlite-bootstrap / sqlite-migration
- round-contract / round-reducer
- files-only / import-remap
- common / worktree
- spec-correctness-program.test / spec-correctness-admission
- queue-services / vendor-preflight-cli
- vendor-preflight-manifest / foreman-setup-main
- files-only / bounds
- foreman-setup / foreman-setup.test
- verify-runtime
- schema / architecture-manifest
- round-live-services / round-transaction.test
- posix / posix-bootstrap
- credential-profile
- vendor-preflight-contract / vendor-preflight-store
- failures / port
- credential-profile-preflight / credential-profile-preflight.test
- release-admission.test / release-admission
- sqlite-store / sidecar
- execution-contract / release-program
- release-authority.test / release-admission-cli.test
- ace / ace.test
- lock / eventlog
- execution-guard-cli / execution-contract
- replay / replay.test
- tier2-shared / tier2-compare-main
- spec-correctness-cli.test
- contract-suite / contract.test
- canonical-json / failures
- attempt / failures
- execution-ledger.test / execution-contract
- tool-check-atomicity / tool-check-platform
- preflight-cli.test / preflight-cli
- spec-correctness-admission.test
- resume-decision.test / resume-decision
- graph-context / graph-context.test
- project-registry / project-registry.test
- architecture-ts-inspect / bun
- process-runner / process-runner.test
- capability / platform
- heartbeat / services
- dependency-drift / dependency-drift.test
- config / eventlog
- round-reducer.test / supervisor.test
- round-cli / round-cli.test
- tracked-delete.test / approval-delta.test
- release-policy / release-policy.test
- schema / files-only
- install-verify.test / install-verify-fs
- outbox-store.test / projection
- secret-scan / secret-scan.test
- repo-hygiene / repo-hygiene.test
- evidence / stall
- spec-correctness
- spec-correctness
- projection-lease / projection-epoch
- credential-profile / credential-profile.test
- gate-ground / gate-ground-checks
- release-coverage.test / release-coverage
- release-authority-cli / release-authority-cli.test
- live-services / git-env
- release-admission-cli / release-admission-main
- tier1-replay
- watch / checkpoint
- hosted-node24-ci.test
- run-checks
- cli / main
- resume-safety-services / resume-safety-services.test
- appliance-lock
- secret-scan
- qdrant-memory-index
- port / files-only
- qdrant-memory-index.test / projection-epoch.test
- rootless-engine-qualification / rootless-engine-qualification.test
- appliance-doctor / appliance-doctor.test
- credential-profile-lane-cli / credential-profile-lane-cli.test
- graph-evaluation / graph-evaluation.test
- install-verify-schema / install-plugin-drift
- qdrant-client-port / qdrant-memory-index
- credential-profile-lane / credential-profile-lane.test
- audit-run / telemetry
- services / platform
- run / preconditions.bash
- spec-correctness.test / spec-correctness
- check-architecture.mjs
- cli / cli.test
- lane-run / eventlog
- spec-correctness-cli / spec-correctness-admission
- architecture-adapter / architecture-adapter.test
- open / files-only-lock-contender
- execution-contract.test / execution-contract
- install-verify / architecture-git
- schema-file-materializer / schema-file-materializer.test
- budget / budget.test
- secret-scan
- evidence-mechanism
- install-verify-fs
- transformers-embedding / projection-epoch
- lane-ownership-harness
- lanectl
- queries / failures
- verify-runtime-manifest / verify-runtime-manifest.test
- selftest-test-infrastructure
- spec-correctness
- spec-correctness.test / spec-correctness
- backend-boundary.test / ${mod}
- install-verify-cli / architecture-main
- metrics-lint
- maintenance
- ci-local
- qdrant-client-port.test
- fm-session-golden.test / round-live-services
- vendor-concurrency-test
- tool-check.ps1
- check-schema-structure.py
- appliance-lock / appliance-lock.test
- rfc3339 / rfc3339.test
- agy
- claude
- codex
- grok
- audit-call
- check-inventory
- projection-epoch.test / qdrant-live.test
- resume / checkpoint
- liveness
- helpers.bash
- graph-store
- appliance-doctor-main / appliance-lock
- secret-scan / secret-scan-main
- plugin-lessons
- inject-regressions
- bootstrap-wsl
- schema-live-gate
- qdrant-memory-index
- secret-scan
- architecture-evaluate.test
- graph-project
- credential-profile / credential-profile-preflight.test
- sqlite-store-open-race.test
- graph-project-harness
- check-registry-compare
- workspace.test / DomainDynamic
- secret-scan
- run-tests
- run-tests.test
- spec-correctness-cli.test
- bootstrap-windows.ps1
- busy-timeout-lock-holder
- busy-timeout.test
- init-firewall
- durable-preflight
- reap-stale-lanes
- run_known_bad
- wsl-clock-preflight
- write-atomic.test
- docs-check
- lane-review-bundle
- review-quorum
- positive-control.bash
- release-metrics-harness
- run_contract
- install.ps1
- install
- check-drift
- fetch-model-docs.py
- foreman-env-write
- tool-check
- check-drift
- entrypoint
- verify-runtime
- foreman-setup
- lane-complete-check
- lane-queue
- lane-supervise
- readme-structure-check
- fixture-adapter
- version-line-bad
- version-line-good
- council-prettier-bad
- council-prettier-good
- mkdir-atomicity
- tier2-collect
- tier2-compare
- tier2-trigger-scan
- plugin-drift
- repo-hygiene

## God Nodes (most connected - your core abstractions)
1. `canonicalize()` - 165 edges
2. `sha256Hex()` - 88 edges
3. `isCoreFailure()` - 82 edges
4. `isSha256Hex()` - 74 edges
5. `raise()` - 69 edges
6. `SqliteSessionStore` - 62 edges
7. `decodeStrictSync()` - 57 edges
8. `parseJsonRejectDuplicateKeys()` - 54 edges
9. `decodeRunId()` - 52 edges
10. `makeLiveEndstopLedgerLayer()` - 51 edges

## Surprising Connections (you probably didn't know these)
- `loadAuthoredCapabilityEmbed()` --calls--> `isVendorPreflightContractFailure()`  [EXTRACTED]
  scripts/build-runtime.ts → packages/orchestration/src/vendor-preflight-contract.ts
- `trustedLowered()` --calls--> `lowerProviderSchema()`  [EXTRACTED]
  components/council/packages/application/test/r3-lowering-boundary.test.ts → components/council/packages/application/src/schema-lowering.ts
- `assertSecretSafeFailure()` --calls--> `decodeStrictSync()`  [EXTRACTED]
  components/council/packages/application/test/run-preflight.test.ts → components/council/packages/schema/src/decode.ts
- `loadFixture()` --calls--> `decodeStrictSync()`  [EXTRACTED]
  components/council/packages/domain/test/review-admission.test.ts → components/council/packages/schema/src/decode.ts
- `makeTransportOps()` --indirect_call--> `buildCanaryMaterial()`  [INFERRED]
  components/council/packages/runtime-node/test/preflight-program.test.ts → components/council/packages/platform-node/src/canary-materializer.ts

## Import Cycles
- None detected.

## Communities (219 total, 34 thin omitted)

### Community 0 - "test-helpers / errors"
Cohesion: 0.03
Nodes (138): AceParseError, AceSemanticError, ArtifactDigestMismatch, ArtifactEncodingInvalid, ArtifactLengthMismatch, ArtifactLimitExceeded, ArtifactMissing, ArtifactReadError (+130 more)

### Community 1 - "identifiers / quorum.test"
Cohesion: 0.03
Nodes (109): approvalValidationReason(), AuthorityBearingApprovalClass, authorityBearingApprovalClasses, authorizeCommitment(), Check, CommitmentContext, CommitmentDecision, CommitmentDenialReason (+101 more)

### Community 2 - "fm-session-main / fm-session-main.test"
Cohesion: 0.03
Nodes (89): assessSidecarReplace(), BOOLEAN_ARGS, buildFreshnessFromStore(), buildRecoveryFromStore(), CliRefusal, currentGitProjectIdentity(), currentSessionId(), dbPath() (+81 more)

### Community 3 - "execution-terminal-policy / execution-ledger"
Cohesion: 0.05
Nodes (96): decodeRunId(), isUtcSecondTimestamp(), executionContractFamilySha256(), ExecutionFamilyFailure, ExecutionMilestone, isExecutionContractFailure(), isExecutionFamilyFailure(), authorityMatchesReservation() (+88 more)

### Community 4 - "preflight / preflight.test"
Cohesion: 0.04
Nodes (80): asStrictBoolean(), asStrictNonNegativeInteger(), asStrictString(), baseTerminal(), buildClaudeCanaryInvocation(), CLAUDE_FABLE_5_1_MODEL, ClaudeCanaryInvocationInput, ClaudeOuterWire (+72 more)

### Community 5 - "contract-suite / entities"
Cohesion: 0.05
Nodes (80): ALL_CASES, assert(), assertRejects(), assertViolation(), Case, CaseResult, CASES, categoryOf() (+72 more)

### Community 6 - "preflight-program / canary-materializer"
Cohesion: 0.04
Nodes (84): BundleVerificationError, CanaryMaterializerError, PreflightIdentityError, ProviderVersionProbeError, BundleVerifierService, CanaryMaterializerService, PreflightIdentitySourceService, ProviderVersionProbeService (+76 more)

### Community 7 - "prompt-preflight / review-admission"
Cohesion: 0.03
Nodes (91): attemptFailure(), classifyReviewAttempt(), completedInvalidResponse(), evidenceGapsValid(), expectedArtifactSet(), findingsValid(), hostArtifactPreconditionsHold(), InvalidReviewResponseReason (+83 more)

### Community 8 - "supervisor-live-services / supervisor"
Cohesion: 0.05
Nodes (82): RunJournal, RoundResumeDecisionV1, QueueSubmissionV1, ResumeQueueExecutionResultV1, EXIT_CONFIG, EXIT_FAIL, EXIT_OK, MSG_INTERNAL_FAILURE (+74 more)

### Community 9 - "tracked-delete / schema"
Cohesion: 0.06
Nodes (82): admitCheck(), admitEntry(), denied(), failed(), GitIdentitySnapshot, pathHasGlob(), pathIsGroup(), validateTrackedDeleteTargets() (+74 more)

### Community 10 - "release-coverage-cli.test"
Cohesion: 0.03
Nodes (74): assertCanonicalResult(), assertUnchangedSnapshot(), BOOTSTRAP_ARGV, BOOTSTRAP_TAIL, briefFileBytes(), ByteSnapshot, CallLog, Capture (+66 more)

### Community 11 - "schema-lowering / r3-closed-json.test"
Cohesion: 0.05
Nodes (69): ProviderSchemaLowererLive, ANNOTATION_KEYWORDS, bytesEqual(), callIntrinsicGetter(), canonicalJsonBytes(), captureClosedJson(), captureExactRecord(), captureFailure() (+61 more)

### Community 12 - "release-authority / decode"
Cohesion: 0.07
Nodes (86): isSha256Hex(), ApprovedOpenSpecManifestBuildResultV1, ApprovedOpenSpecManifestV1, ApprovedOpenSpecManifestValidationResultV1, AUDIT_VERDICTS, BLOCKING_AUDIT_VERDICTS, BLOCKING_OUTCOME_ACTIONS, CHECK_STATUSES (+78 more)

### Community 13 - "release-coverage"
Cohesion: 0.05
Nodes (86): ALLOWED_WORKFLOWS, bootstrapKey(), bootstrapOwner(), BRIEF_KEYS, BRIEF_SCHEMA, bytesEqual(), canonicalBriefFileBytes(), collectV050OwnerPackageNames() (+78 more)

### Community 14 - "run-journal / run-journal.test"
Cohesion: 0.05
Nodes (71): replayNdjsonBytes(), acquireLockSync(), allocateSync(), appendSync(), attemptHasDurableTerminal(), attemptLockPath(), attemptPath(), Branded (+63 more)

### Community 15 - "spec-correctness-admission.test / spec-correctness-admission"
Cohesion: 0.04
Nodes (66): encodeUtf8(), asReviewAttemptInput(), bindEvaluation(), buildCompletedResult(), closedSuccessfulTerminalCandidate(), compareUtf8ByteOrder(), computeSpecSetSha256(), evaluateSpecCorrectnessAdmission() (+58 more)

### Community 16 - "vendor-preflight / vendor-preflight-live"
Cohesion: 0.05
Nodes (78): ExecutionChildLimitsV2, ExecutionContractFailure, ExecutionContractFailureReason, ExecutionFamilyDerivationV2, ExecutionFamilyFailureReason, ExecutionLimitsV1, ENDSTOP_EXIT_CONFIG, ENDSTOP_EXIT_FAIL (+70 more)

### Community 17 - "architecture-git / architecture-evaluate"
Cohesion: 0.07
Nodes (70): commitAll(), git(), initRepo(), ArchCliIo, emit(), parseArchitectureArgv(), ParsedArchArgs, runArchitectureCli() (+62 more)

### Community 18 - "ready-token.test / provider-health.test"
Cohesion: 0.05
Nodes (70): ProviderHealthError, ReadyTokenIssuanceError, ProviderCanaryPrompt, ProviderCanarySchema, ProviderProcessRunner, mapAdapterError(), mapProcessError(), runProviderHealthCanary() (+62 more)

### Community 19 - "release-coverage-cli"
Cohesion: 0.05
Nodes (78): baseLiveReleaseCoverageCliServices, boundedReadOpenFlagsLive(), BRIEF_SCHEMA, buildTrustedGitEnvironment(), buildTrustedOpenSpecEnvironment(), callPort(), capturedStderrText(), CHILD_SCHEMA (+70 more)

### Community 20 - "admit.test / approval-commit.integration.test"
Cohesion: 0.04
Nodes (62): approval(), approvedFromSeed(), C, CT, NOW, P, parentBlob(), PT (+54 more)

### Community 21 - "files-only / contract-suite"
Cohesion: 0.06
Nodes (21): StubEmptyBackend, FactRow, MeasurementRow, ObligationRow, ObligationStatus, SessionRow, assertReceiptCounterMintable(), cloneQueue() (+13 more)

### Community 22 - "outbox.test / memory-index"
Cohesion: 0.04
Nodes (26): HangingMemoryIndex, NullMemoryIndex, PoisonMemoryIndex, ThrowingMemoryIndex, defensiveRecords(), DrainOptions, drainOutbox(), DrainResult (+18 more)

### Community 23 - "tool-check-run / tool-check-cli"
Cohesion: 0.05
Nodes (66): setupReady(), EXIT_INVALID_ARGUMENTS, EXIT_NOT_READY, EXIT_OUTPUT_WRITE_FAILED, EXIT_READY, isLane(), isProfile(), MSG_LANE_CLAUDE (+58 more)

### Community 24 - "graphify-qualification / graphify-qualification-main"
Cohesion: 0.06
Nodes (73): acquireGraphifyPublicationLockV1(), canonicalCompare(), deriveRenames(), DIAGNOSTIC_KEYS, diagnosticsValid(), encoder, exactKeys(), GRAPH_ROOT_KEYS (+65 more)

### Community 25 - "queue-admission / queue-cli"
Cohesion: 0.05
Nodes (64): ADD_USAGE, cmdAdd(), cmdEnsure(), cmdKill(), cmdStatus(), ensureGroup(), EnsureOptions, EXIT_CONFIG (+56 more)

### Community 26 - "resume-worktree-restore / resume-queue-execution"
Cohesion: 0.04
Nodes (64): resumeAttemptFailure, ResumeAttemptReservationV1, runJournalFailure, Branded, buildLaneRunRoundVector(), ExecBranded, isQueueSubmitFailure(), isResumeQueueExecutionFailure() (+56 more)

### Community 27 - "session-sqlite-bootstrap / sqlite-migration"
Cohesion: 0.05
Nodes (51): sidecarPathFor(), allocateCorruptBackupPath(), BACKUP_SIDECARS, BACKUP_TRIPLET_SUFFIXES, backupTripletOccupied(), BootstrapOpts, bootstrapStore(), compactUtcTimestamp() (+43 more)

### Community 28 - "round-contract / round-reducer"
Cohesion: 0.07
Nodes (67): isAttemptFailure(), ATTEMPT_IDENTITY_KEYS, attemptIdentitiesEqual(), Branded, containsNul(), decodeAttemptIdentityValue(), decodeCheckpointIdentityV1(), decodeCommandArgv() (+59 more)

### Community 29 - "files-only / import-remap"
Cohesion: 0.07
Nodes (52): baseWithSession(), countRows(), emptySnapshot(), NextIds, SESSION_MODEL_VERSION, SessionSnapshot, acquireWriterLock(), claimsDir() (+44 more)

### Community 30 - "common / worktree"
Cohesion: 0.07
Nodes (53): checks-run.sh script, evidence-collect.sh script, fc_sigint_lane(), foreman-cleanup.sh script, malformed(), foreman-fit-report.sh script, gate-eval.sh script, gg_apply_config() (+45 more)

### Community 31 - "spec-correctness-program.test / spec-correctness-admission"
Cohesion: 0.04
Nodes (59): acceptProviderResponse, approvedFinalResponse, asDigest(), BASELINE_IDS, baseSha, candidateId, completedTerminal, computeSpecSetDigest() (+51 more)

### Community 32 - "queue-services / vendor-preflight-cli"
Cohesion: 0.06
Nodes (58): vendorLayer(), cancelOwnedFinalizer(), CapturedProcessResult, isNotFoundError(), liveBoundedFs, liveEnvVars, livePathLookup, liveProcessExec (+50 more)

### Community 33 - "vendor-preflight-manifest / foreman-setup-main"
Cohesion: 0.05
Nodes (56): EXIT_BOUNDARY_FAILURE, finalizeSetupExitCode(), io, loadCapabilityTable(), pending, repoRoot, settleExit(), MSG_CAPABILITY_TABLE_LOAD_FAILED (+48 more)

### Community 34 - "files-only / bounds"
Cohesion: 0.08
Nodes (61): GENERATION_ID_WIDTH, GRAPH_STORE_SCHEMA_VERSION, MAX_FILE_BYTES, MAX_JSON_DEPTH, MAX_JSON_NODES, MAX_LOCK_RETRIES, MAX_ROOT_FILES, MAX_TRAVERSAL_STEPS (+53 more)

### Community 35 - "foreman-setup / foreman-setup.test"
Cohesion: 0.06
Nodes (61): CredentialVendor, liveCredentialProfileFsLayer, buildVendorHomeChildEnv(), defaultCredentialProfileId(), makeCredentialProfilePreflight(), profilePreflightRecordPath(), authInstruction(), captureText() (+53 more)

### Community 36 - "verify-runtime"
Cohesion: 0.03
Nodes (63): root, tmp, tmpA, tmpB, trackedApplianceDoctor, trackedApplianceDoctorPath, trackedCheck, trackedCredentialProfile (+55 more)

### Community 37 - "schema / architecture-manifest"
Cohesion: 0.12
Nodes (52): expectArray(), expectExactLiteral(), expectNumber(), expectObject(), expectString(), rejectUnknownKeys(), isCoreFailure(), schemaMismatch() (+44 more)

### Community 38 - "round-live-services / round-transaction.test"
Cohesion: 0.07
Nodes (50): AttemptIdentity, RunId, decideRoundOutcome(), incomplete(), isPresentNonempty(), OutcomeDecisionInput, ReportReadFailureReason, ReportReadResult (+42 more)

### Community 39 - "posix / posix-bootstrap"
Cohesion: 0.08
Nodes (43): main(), parseArgs(), ParsedArgs, NOTE: deliberately BEFORE the pidns bootstrap below -- this, resolveCliArgs(), runDetached(), usage(), UsageError (+35 more)

### Community 40 - "credential-profile"
Cohesion: 0.08
Nodes (53): authorityOpenFlags(), captureDirIdentity(), checkComponent(), classifyFromStats(), cleanupTemp(), closeQuiet(), CREDENTIAL_PROFILE_REFUSAL_REASONS, CREDENTIAL_PROFILE_SCHEMA_VERSION (+45 more)

### Community 41 - "vendor-preflight-contract / vendor-preflight-store"
Cohesion: 0.08
Nodes (47): AUTH_VALUES, Branded, checkRecordConsistency(), CURRENCY_VALUES, decodeArgv(), decodeFact(), decodeNonBlankBounded(), decodeOptionalBoundedString() (+39 more)

### Community 42 - "failures / port"
Cohesion: 0.08
Nodes (36): MAX_QUERY_RESULTS, Branded, capabilityUnavailable(), CapabilityUnavailableError, DocumentNotFoundError, GRAPH_STORE_FAILURE_BRAND, GraphStoreError, GraphStoreFailureReason (+28 more)

### Community 43 - "credential-profile-preflight / credential-profile-preflight.test"
Cohesion: 0.10
Nodes (48): authorityDirChain(), authorityOpenFlags(), captureAuthorityDirsForRead(), CapturedAuthorityDirs, captureDirIdentity(), captureFileIdentity(), cleanupTemp(), closeQuiet() (+40 more)

### Community 44 - "release-admission.test / release-admission"
Cohesion: 0.06
Nodes (45): canonicalFileSha256(), CheckedEvidence, checkEvidence(), compareUtf8(), designReceipt(), encoder, evaluateReleaseAdmissionV1(), evaluateReleaseEvidenceAfterGitResolutionV1() (+37 more)

### Community 45 - "sqlite-store / sidecar"
Cohesion: 0.11
Nodes (10): CountedKind, raise(), assertNoDuplicateKeys(), parseLine(), isCurrentOutboxSchema(), isLegacyOutboxSchema(), maxInternalNumericReceipt(), outboxColumnNames() (+2 more)

### Community 46 - "execution-contract / release-program"
Cohesion: 0.08
Nodes (47): childBriefKeys, childContractKeys, childViolatesProgram(), compareUtf8V2(), contractKeys, decodeChildBriefV1(), decodeExecutionContractFamilyV2(), decodeExecutionContractV1() (+39 more)

### Community 47 - "release-authority.test / release-admission-cli.test"
Cohesion: 0.04
Nodes (46): ReleaseAdmissionCliServices, BUNDLE, CANDIDATE, canonicalFile(), Capture, COMMIT, DESIGN, encoder (+38 more)

### Community 48 - "ace / ace.test"
Cohesion: 0.07
Nodes (45): AceDeterminedObject, AceDeterminer, AceDiagnostic, AceDocument, AceLexicon, AceLexiconVerb, AceParseResult, AceSentence (+37 more)

### Community 49 - "lock / eventlog"
Cohesion: 0.10
Nodes (46): el_attempt_new(), el_init(), _el_reclaim_one(), fm_lock_acquire(), fm_lock__acquire_flock(), fm_lock__acquire_flock_command_holder(), fm_lock__acquire_mkdir(), fm_lock__bin_mtime() (+38 more)

### Community 50 - "execution-guard-cli / execution-contract"
Cohesion: 0.10
Nodes (45): canonicalize(), isCommitSha40(), canonicalFileSha256V2(), decodeExecutionFamilySourceFileV1(), deriveExecutionContractFamilyV2(), CanonicalFile, childSnapshot(), DecodedOutcome (+37 more)

### Community 51 - "replay / replay.test"
Cohesion: 0.08
Nodes (37): EVENT_LOG_SCHEMA_VERSION, MAX_EVENT_JSON_NODES, MAX_EVENT_NESTING_DEPTH, MAX_PHYSICAL_LINE_BYTES, MAX_PHYSICAL_LINES, MAX_REPLAY_INPUT_BYTES, MAX_RUN_ID_LENGTH, eventDecodeFailure (+29 more)

### Community 52 - "tier2-shared / tier2-compare-main"
Cohesion: 0.14
Nodes (36): collect(), invoke_adapter(), main(), pinned_identity(), bootstrap_ci(), budget_command(), budget_field(), compare_command() (+28 more)

### Community 53 - "spec-correctness-cli.test"
Cohesion: 0.04
Nodes (37): abstentionFinalResponse, abstentionResult, acceptProviderResponse, approvedFinalResponse, approvedResult, BASELINE_IDS, baseSha, candidateId (+29 more)

### Community 54 - "contract-suite / contract.test"
Cohesion: 0.13
Nodes (33): ALL_CASES, assert(), CASE_CATEGORY, caseDependsOnCycleRejected(), caseExpectedEmptyTrueNegative(), caseLineageAttemptsFromRound(), caseLineageClaimsContradicting(), caseLineageQueryNamesComplete() (+25 more)

### Community 55 - "canonical-json / failures"
Cohesion: 0.13
Nodes (33): boundBytes(), readFdBounded(), isCanonicalJsonText(), isParseFail(), PARSE_FAIL, ParseFail, parseJsonRejectDuplicateKeys(), fail() (+25 more)

### Community 56 - "attempt / failures"
Cohesion: 0.11
Nodes (37): AttemptId, decodeAttemptId(), decodeAttemptIdentity(), decodeAttemptIdText(), decodeLaneId(), extractPayloadAttempt(), isPositiveSafeInteger(), LaneId (+29 more)

### Community 57 - "execution-ledger.test / execution-contract"
Cohesion: 0.06
Nodes (32): EvaluationChildLimitsV2, ExecutionChildContractV2, executionContractSha256(), ExecutionContractV1, ExecutionFamilySourceV1, StandardChildLimitsV2, strictEndstopLimits, A (+24 more)

### Community 58 - "tool-check-atomicity / tool-check-platform"
Cohesion: 0.11
Nodes (39): AtomicityProbeResult, captureText(), checkPinnedVerdict(), countMkdirContentionViolations(), firstLine(), isExistingWritableDir(), parsePinnedRegisterToml(), parseTomlString() (+31 more)

### Community 59 - "preflight-cli.test / preflight-cli"
Cohesion: 0.06
Nodes (33): encodeUtf8Bounded(), MAX_STDERR_BYTES, MAX_STDIN_BYTES, nodeIo, PreflightCliIo, readStdinBounded(), runPreflightCli(), STATIC_PARSE_FAILURE (+25 more)

### Community 60 - "spec-correctness-admission.test"
Cohesion: 0.05
Nodes (38): abstainEvaluation, abstentionResponse, acceptEvaluation, admissionInput, approvedResponse, artifactId(), baseSha, changesEvaluation (+30 more)

### Community 61 - "resume-decision.test / resume-decision"
Cohesion: 0.09
Nodes (39): makeAttemptIdentity(), identity(), decideRoundResume(), DecideRoundResumeInput, isValidLockState(), isValidProcessState(), isValidResumeCount(), isValidResumeMaxAttempts() (+31 more)

### Community 62 - "graph-context / graph-context.test"
Cohesion: 0.08
Nodes (35): AUDITOR_RELATIONS, boundedString(), boundedTaskText(), buildGraphContextV1(), compareUtf8(), edgeIdentity(), encoder, GraphContextBlockV1 (+27 more)

### Community 63 - "project-registry / project-registry.test"
Cohesion: 0.10
Nodes (38): compareUtf8(), decodeProjectRegistryFileV1(), emptyProjectRegistryV1(), hasExactOwnKeys(), isEnoent(), isPlainObject(), loadProjectRegistryFileV1(), parseProject() (+30 more)

### Community 64 - "architecture-ts-inspect / bun"
Cohesion: 0.12
Nodes (32): addBinding(), BabelNode, bindPattern(), BUN_MODULES, childFieldIsTypeOnly(), classifyTsNode(), collectHoistedBindings(), globalThisRuntimeProperty() (+24 more)

### Community 65 - "process-runner / process-runner.test"
Cohesion: 0.09
Nodes (25): ProviderProcessError, BoundedSpool, ProviderProcessRunnerService, BoundedStreamCollector, closeStdin(), collectHomePaths(), createTerminalCloseState(), digestOf() (+17 more)

### Community 66 - "capability / platform"
Cohesion: 0.16
Nodes (34): CapabilityDiagnostic, capabilityFromProbe(), CapabilityKind, CapabilityProbeReason, capabilityRecord, ContainmentRequirement, formatCapabilityDiagnostic(), formatRefusalLine() (+26 more)

### Community 67 - "heartbeat / services"
Cohesion: 0.09
Nodes (32): buildHeartbeatLine(), DETACH_HANDOFF_BOUND_MS, firstValidHeartbeatLine(), formatHeartbeatLine(), HEARTBEAT_KEYS, HeartbeatKey, HeartbeatLine, HeartbeatValidation (+24 more)

### Community 68 - "dependency-drift / dependency-drift.test"
Cohesion: 0.10
Nodes (32): buildCheckerAuthority(), CheckerAuthority, collectCheckerAuthority(), DriftIo, DriftRunOptions, EXIT_AGREE, EXIT_DRIFT, EXIT_FAIL_CLOSED (+24 more)

### Community 69 - "config / eventlog"
Cohesion: 0.09
Nodes (31): _CFG_ENV_VAR, cfg_get(), cfg_load(), _cfg_parse_toml(), _CFG_VALUES, config.sh script, el_compact(), el_cursor_commit() (+23 more)

### Community 70 - "round-reducer.test / supervisor.test"
Cohesion: 0.08
Nodes (34): ReplayRecord, plan(), makeStubWorktreeRestore(), absentReportSnapshot(), CheckpointIdentityV1, RoundOutcomeV1, RoundPlanV1, attemptId (+26 more)

### Community 71 - "round-cli / round-cli.test"
Cohesion: 0.09
Nodes (26): EXIT_BOUNDARY_FAILURE, EXIT_COMPLETED, EXIT_INCOMPLETE_OR_DEFECT, EXIT_INVALID_ARGUMENTS, isEqualOrDescendant(), MSG_BOUNDARY_FAILURE, MSG_INTERNAL_FAILURE, MSG_INVALID_ARGUMENTS (+18 more)

### Community 72 - "tracked-delete.test / approval-delta.test"
Cohesion: 0.08
Nodes (27): actionIdentityCanonical(), P, PT, validateApprovalDelta(), CurrentEntry, MAX_TRACKED_BATCH_BYTES, MAX_TRACKED_PATH_BYTES, A_TXT (+19 more)

### Community 73 - "release-policy / release-policy.test"
Cohesion: 0.10
Nodes (27): sha256Hex(), ACTIONS, decodeCoverageOutput(), emit(), liveReleasePolicyServices, parseReleasePolicyArgv(), phaseForCoverage(), refused() (+19 more)

### Community 74 - "schema / files-only"
Cohesion: 0.12
Nodes (27): schemaValidation(), SchemaValidationError, cloneDocMap(), mergePublication(), allowedFieldsFor(), asIdSet(), asIdSetStrict(), BUSINESS_KEYS (+19 more)

### Community 75 - "install-verify.test / install-verify-fs"
Cohesion: 0.07
Nodes (30): dirIdentity(), fileIdentity(), baseNodes(), releaseRuntimeMemoryNodes(), root, skillRoot, skillTree(), trackedCredentialProfile (+22 more)

### Community 76 - "outbox-store.test / projection"
Cohesion: 0.10
Nodes (20): SessionStoreError, sessionStoreFailure, copyRecord(), synthesizeOutbox(), addFact(), BackendHarness, filesHarness, HARNESSES (+12 more)

### Community 77 - "secret-scan / secret-scan.test"
Cohesion: 0.07
Nodes (26): DEFAULT_SECRET_SCAN_BOUNDS, EXIT_CLEAN, EXIT_INVALID_ARGUMENTS, FIXTURE_DECLARATION_RELPATH, FIXTURE_SUBTREE_PREFIX, isSecretScanResult(), MAX_DIRECTORY_ENTRIES, MAX_FILE_BYTES (+18 more)

### Community 78 - "repo-hygiene / repo-hygiene.test"
Cohesion: 0.11
Nodes (28): ALLOWED_MODE_CHANGES, ALLOWED_ROOT_MD, captureRepoHygieneSnapshot(), checkEvidenceDuplicates(), checkModeRegression(), checkRootDuplicatesDocs(), checkRootMarkdown(), evaluateRepoHygiene() (+20 more)

### Community 79 - "evidence / stall"
Cohesion: 0.14
Nodes (27): evidence_canonical_record_to(), evidence_collect_paths_to(), evidence_content_digest(), _evidence_git(), evidence_git_status_to(), evidence_is_git_worktree(), evidence_legacy_porcelain_digest(), evidence_parse_status_paths_file() (+19 more)

### Community 80 - "spec-correctness"
Cohesion: 0.10
Nodes (29): asciiBytes(), CANONICAL_BASELINE_IDS, CANONICAL_HEADER_CELLS, collectRowCellInlines(), COMMONMARK_BLOCK_HTML_TAGS, compareDigestByteOrder(), compareUtf8ByteOrder(), concatBytes() (+21 more)

### Community 81 - "spec-correctness"
Cohesion: 0.08
Nodes (30): CoverageNumerator, coverageNumeratorMatches(), dispositionSum(), hasMetricDefectOrInvention(), isAcceptMetrics(), itemIdentity, metricsBaseConsistent(), NonNegativeSafeInteger (+22 more)

### Community 82 - "projection-lease / projection-epoch"
Cohesion: 0.10
Nodes (11): ProjectionEpochCoordinator, ProjectionEpochSource, catchUp(), QUALIFICATION, record(), LeaseRow, ProjectionLease, ProjectionLeasePort (+3 more)

### Community 83 - "credential-profile / credential-profile.test"
Cohesion: 0.10
Nodes (23): absoluteConfigRoot(), configRootRelForVendor(), CredentialProfileResult, decodeCredentialProfileRecordV1(), EXIT_OK, EXIT_REFUSED, initProfile(), isCredentialProfileResult() (+15 more)

### Community 84 - "gate-ground / gate-ground-checks"
Cohesion: 0.08
Nodes (19): gg_canary_evaluate_fixture(), GG_CHECK_LAST_UNEVALUATED, gate-ground-checks.sh script, gg_canary_corpus_readable(), gg_canary_run(), gg_canary_unverified(), gg_check_mode(), gg_now_ms() (+11 more)

### Community 85 - "release-coverage.test / release-coverage"
Cohesion: 0.07
Nodes (23): ReleaseCoverageFailureReason, ReleaseCoveragePhaseV1, ReleasePackageBriefV1, RoadmapAssignmentV1, ApplyDep, ARCHITECTURAL_EXPECTED, architecturalSchemaPath, ArtifactDep (+15 more)

### Community 86 - "release-authority-cli / release-authority-cli.test"
Cohesion: 0.10
Nodes (26): RegisteredEvaluationVerdictV1, RegisteredReleaseOutcomeV1, actions, authorityRegistration(), commonArgs(), CommonRegistrationArgs, decodeFile(), encoder (+18 more)

### Community 87 - "live-services / git-env"
Cohesion: 0.17
Nodes (23): stubFs, gitArgv(), sanitizedGitEnv(), shouldStrip(), STRIP_PREFIXES, root, bytesEqual(), createFileExclusiveSync() (+15 more)

### Community 88 - "release-admission-cli / release-admission-main"
Cohesion: 0.13
Nodes (26): ACTIONS, closedGitEnvironment(), commandTail(), compareUtf8(), encoder, execFileAsync, invalid(), isContainedPath() (+18 more)

### Community 89 - "tier1-replay"
Cohesion: 0.13
Nodes (28): assert_audit_watchdog_defect(), assert_audit_watchdog_trace(), assert_crlf_worktree_defect(), assert_crlf_worktree_trace(), assert_decision_trace(), assert_formal_setsid_defect(), assert_formal_setsid_trace(), assert_grok_empty_burst_defect() (+20 more)

### Community 90 - "watch / checkpoint"
Cohesion: 0.18
Nodes (25): ckpt_latest(), main(), watch.sh script, wd_baseline_ts(), wd_classify_v2(), wd_grace_clamp(), wd_hb_last_epoch(), wd_is_queued() (+17 more)

### Community 91 - "hosted-node24-ci.test"
Cohesion: 0.11
Nodes (23): checkParsedCouncilGateContract(), councilRoot, executableRunLines(), EXPECTED_ENV, EXPECTED_JOB, EXPECTED_RUN_LINES, fail(), GateCheckFailure (+15 more)

### Community 92 - "run-checks"
Cohesion: 0.20
Nodes (26): assert_toolchain(), build_quint_cmd(), check_coverage_registry(), check_vacuous_registry(), classify_output(), cleanup_owned(), demonstrate_wrong_grep(), die() (+18 more)

### Community 93 - "cli / main"
Cohesion: 0.15
Nodes (23): argvWithoutDetach(), CliParseResult, EXIT_LAUNCHER_ERROR, EXIT_TIMEOUT, FOREMAN_LAUNCH_VERSION, formatVersionLine(), mapSuperviseExit(), parseArgs() (+15 more)

### Community 94 - "resume-safety-services / resume-safety-services.test"
Cohesion: 0.14
Nodes (20): ResumeLockState, ResumeProcessState, classifyResumeLock(), classifyResumeProcess(), errorCode(), isPositiveSafeInteger(), isValidAbsoluteLockPath(), liveResumeSafetyServices (+12 more)

### Community 95 - "appliance-lock"
Cohesion: 0.14
Nodes (25): APPLIANCE_KEYS, ApplianceLockDecodeResultV1, ApplianceLockValidationResultV1, AppliancePinsResultV1, exactPackageVersion(), exactSemver(), exactStringArray(), exactTable() (+17 more)

### Community 96 - "secret-scan"
Cohesion: 0.09
Nodes (24): BoundDir, Counters, DirIdentity, ExemptionMap, FileRead, FixtureLoad, Frame, isUnderFixtureSubtree() (+16 more)

### Community 97 - "qdrant-memory-index"
Cohesion: 0.16
Nodes (14): RFC-9562, collectionStem(), KINDS, QdrantMemoryIndex, QdrantMemoryIndexOptions, qdrantPointIdV1(), QdrantPointPayloadV1, QUALIFICATION_INDEXES (+6 more)

### Community 98 - "port / files-only"
Cohesion: 0.11
Nodes (3): FilesOnlyGraphStore, GraphStore, JsonObject

### Community 99 - "qdrant-memory-index.test / projection-epoch.test"
Cohesion: 0.11
Nodes (5): Port, QdrantApplyV1, QdrantQualificationV1, QdrantQueryV1, RecordingPort

### Community 100 - "rootless-engine-qualification / rootless-engine-qualification.test"
Cohesion: 0.13
Nodes (22): ACCOUNT_KEYS, DIRECTORY_KEYS, exactKeys(), plainObject(), PROBE_KEYS, qualifyRootlessEngineV1(), refused(), ROOT_KEYS (+14 more)

### Community 101 - "appliance-doctor / appliance-doctor.test"
Cohesion: 0.13
Nodes (21): ApplianceDoctorCliIo, ApplianceDoctorObservationV1, ApplianceDoctorReasonV1, ApplianceDoctorResultV1, ApplianceDoctorServices, DIRECTORY_KEYS, DIRECTORY_STATE_KEYS, evaluateApplianceDoctorV1() (+13 more)

### Community 102 - "credential-profile-lane-cli / credential-profile-lane-cli.test"
Cohesion: 0.14
Nodes (16): CredentialProfileFs, CredentialProfileInput, isValidProfileId(), CREDENTIAL_PROFILE_LANE_EXIT_OK, CREDENTIAL_PROFILE_LANE_EXIT_REFUSED, CredentialProfileLaneCliIo, FLAG_ORDER, isSafeArgument() (+8 more)

### Community 103 - "graph-evaluation / graph-evaluation.test"
Cohesion: 0.12
Nodes (17): buildGraphEvaluationReportV1(), encoder, GraphEvaluationArmV1, GraphEvaluationBuildResultV1, GraphEvaluationObservationV1, GraphEvaluationOutcomeV1, GraphEvaluationReportV1, GraphEvaluationRunSetV1 (+9 more)

### Community 104 - "install-verify-schema / install-plugin-drift"
Cohesion: 0.20
Nodes (20): artifactKey(), artifactSetEqual(), compareRuntimePluginDrift(), compareVerifiedSnapshots(), failReasonOf(), InstallFs, INSTALL_VERIFY_SCHEMA_VERSION, InstallArtifactDescriptor (+12 more)

### Community 105 - "qdrant-client-port / qdrant-memory-index"
Cohesion: 0.19
Nodes (12): aliases(), aliasName(), collectionStem(), epochMetadata(), INDEXES, nodeCount(), object(), PlainObject (+4 more)

### Community 106 - "credential-profile-lane / credential-profile-lane.test"
Cohesion: 0.13
Nodes (19): CredentialProfileFsShape, CredentialProfileRefusalReason, admitCredentialProfileLane(), CREDENTIAL_PROFILE_LANE_REFUSAL_REASONS, CredentialProfileLaneRefusalReason, CredentialProfileLaneResult, mapProfileRefusal(), mapStoreFailure() (+11 more)

### Community 107 - "audit-run / telemetry"
Cohesion: 0.19
Nodes (19): ar_atomic_integer(), ar_cleanup_processes(), ar_emit_lineage(), ar_end_timing(), ar_fail(), ar_reap_watchdog(), ar_record_outcome(), ar_watchdog_wait() (+11 more)

### Community 108 - "services / platform"
Cohesion: 0.10
Nodes (18): ExecveRequest, TaskkillRequest, CapabilityWriteError, HeartbeatWriteError, liveByteSink, liveCapabilityWriter, liveChildSpawner, LiveClockLayer (+10 more)

### Community 109 - "run / preconditions.bash"
Cohesion: 0.14
Nodes (13): preconditions.bash script, preconditions_platform(), require_platform(), absolute_path(), acquire_bats_mutex(), bats_args, lookup_baseline(), lookup_skip_budget() (+5 more)

### Community 110 - "spec-correctness.test / spec-correctness"
Cohesion: 0.15
Nodes (14): acceptBody(), allMappedItems(), BASELINE_IDS, changesBody(), changesBodyNoFindings(), decodeResponse(), encodeUtf8(), evaluate() (+6 more)

### Community 111 - "check-architecture.mjs"
Cohesion: 0.14
Nodes (17): bareBuiltinRoots, councilPackage(), executableExtensions, inspectSource(), isDeclarationOrPropertyName(), isForbiddenAdapterLayer(), isForbiddenApplicationLayer(), isForbiddenDomainLayer() (+9 more)

### Community 112 - "cli / cli.test"
Cohesion: 0.23
Nodes (17): CliIo, cmdCapabilities(), cmdContract(), cmdSmoke(), cmdVersionRef(), defaultIo, printJson(), redactPaths() (+9 more)

### Community 113 - "lane-run / eventlog"
Cohesion: 0.20
Nodes (19): cleanup(), emit_kill_alert(), GIT_ASK_YESNO, kill_cmd_bounded(), kill_launcher_bounded(), lane_default_credential_profile(), lane_emit_ownership(), lane_exit_source() (+11 more)

### Community 114 - "spec-correctness-cli / spec-correctness-admission"
Cohesion: 0.16
Nodes (17): encodeResultLine(), encodeUtf8Bounded(), MAX_STDERR_BYTES, MAX_STDIN_BYTES, MAX_STDOUT_BYTES, nodeIo, readStdinBounded(), runSpecCorrectnessCli() (+9 more)

### Community 115 - "architecture-adapter / architecture-adapter.test"
Cohesion: 0.18
Nodes (17): DENY, escapeRegExp(), hasSmuggledOperators(), inspectLaneRunMigrationAdapter(), inspectLaneSuperviseMigrationAdapter(), inspectLegacyAdapter(), inspectPosixShellAdapter(), isCommentOrBlank() (+9 more)

### Community 116 - "open / files-only-lock-contender"
Cohesion: 0.16
Nodes (15): main(), send, waitForRelease(), openFilesOnlyStore(), CANONICAL_BACKENDS, CanonicalBackend, nonemptyPath(), normalizeBackend() (+7 more)

### Community 117 - "execution-contract.test / execution-contract"
Cohesion: 0.14
Nodes (17): ExecutionChildBriefV1, ExecutionContractFamilyV2, canonicalFile(), CHILDREN, derive(), deriveV050(), encoder, INPUT (+9 more)

### Community 118 - "install-verify / architecture-git"
Cohesion: 0.25
Nodes (17): MAX_BLOB_BYTES, enumerateDistExact(), identitiesEqual(), isHardLinked(), joinRuntime(), mapFsMissing(), ReadFail, ReadOk (+9 more)

### Community 119 - "schema-file-materializer / schema-file-materializer.test"
Cohesion: 0.24
Nodes (13): SchemaFileMaterializationError, cleanupFailed(), createFailed(), defaultSchemaFileMaterializerOps, delay(), ensureRemoved(), materializeCanarySchemaFile(), removeWithRetry() (+5 more)

### Community 120 - "budget / budget.test"
Cohesion: 0.17
Nodes (15): BudgetDimension, budgetDimensions, BudgetReconciliationDecision, BudgetReservationDecision, BudgetState, emptyBudgetVector, initialBudgetState(), mapVector() (+7 more)

### Community 121 - "secret-scan"
Cohesion: 0.24
Nodes (17): closeQuiet(), dirOpenFlags(), fileOpenFlags(), identitiesEqual(), identityOf(), isNotFound(), isSafeDirentName(), isSafeExemptionPath() (+9 more)

### Community 122 - "evidence-mechanism"
Cohesion: 0.49
Nodes (16): case_content_blindspot(), case_deletion(), case_flags(), case_harness_nonzero(), case_rename(), case_roots(), case_shellcheck(), case_unreadable() (+8 more)

### Community 123 - "install-verify-fs"
Cohesion: 0.22
Nodes (14): identityFromStats(), InstallFileIdentity, InstallFsError, InstallOpenFile, linkIdentity(), liveInstallFs, makeMemoryInstallFs(), MemoryInstallFsHooks (+6 more)

### Community 124 - "transformers-embedding / projection-epoch"
Cohesion: 0.28
Nodes (11): ProjectionCatchUpBatchV1, ProjectionEpochCoordinatorOptions, createTransformersEmbeddingV1(), isContained(), normalizeTransformersEmbeddingOutputV1(), PINNED_TRANSFORMERS_MODEL_V1, pinnedTransformersPipelinePlanV1, sameIdentity() (+3 more)

### Community 125 - "lane-ownership-harness"
Cohesion: 0.38
Nodes (14): assert_contains(), case_claim_survives_reexec(), case_foreign_safety(), case_harness_nonzero(), case_healthy_negatives(), case_never_launched(), case_no_output_hash(), case_pgrep_regression() (+6 more)

### Community 126 - "lanectl"
Cohesion: 0.26
Nodes (13): cmd_adopt(), cmd_claim(), cmd_launch(), cmd_progress(), cmd_ps(), cmd_reap(), cmd_sweep(), etime_secs() (+5 more)

### Community 127 - "queries / failures"
Cohesion: 0.34
Nodes (11): LimitExceededError, asList(), DocumentIndex, enforceQueryResultBound(), idOf(), indexFromDocuments(), listByType(), queryAttemptsFromRound() (+3 more)

### Community 128 - "verify-runtime-manifest / verify-runtime-manifest.test"
Cohesion: 0.18
Nodes (11): runVerifyRuntime(), verifyRuntimeTree(), ManifestVerifyFail, ManifestVerifyOk, ManifestVerifyResult, mapResult(), root, trackedManifest (+3 more)

### Community 129 - "selftest-test-infrastructure"
Cohesion: 0.43
Nodes (13): assert_contains(), assert_status(), check_annual_overdue_report(), check_detection_criterion(), check_fractional_delta_boundary(), check_preconditions(), check_runner(), measure_delta_pair() (+5 more)

### Community 130 - "spec-correctness"
Cohesion: 0.23
Nodes (13): buildMetrics(), bytesEqual(), callDecodeUtf8(), callSha256(), countDispositions(), evaluateSpecCorrectnessV1(), hasUnpairedSurrogate(), invalid() (+5 more)

### Community 131 - "spec-correctness.test / spec-correctness"
Cohesion: 0.15
Nodes (6): InventedCompletionV1, SpecCorrectnessCoverageRatioV1, SpecCorrectnessItemResultV1, cleanMetrics, defectMetrics, invention

### Community 132 - "backend-boundary.test / ${mod}"
Cohesion: 0.26
Nodes (9): BoundaryHit, isDistPath(), isSessionStoreSrc(), isTestPath(), productionOffenders(), REPO_ROOT, scanSource(), TEST_ALLOWLIST (+1 more)

### Community 133 - "install-verify-cli / architecture-main"
Cohesion: 0.24
Nodes (11): io, emit(), InstallCliIo, isInstallCommand(), ParsedInstallArgs, parseInstallArgv(), runInstallCli(), installFailed() (+3 more)

### Community 134 - "metrics-lint"
Cohesion: 0.33
Nodes (12): ml_blocker_open(), ml_claims_value(), ml_has_companion(), ml_is_uncomputable(), ml_lint_file(), ml_lint_text(), ml_lower(), ml_main() (+4 more)

### Community 135 - "maintenance"
Cohesion: 0.29
Nodes (10): append_item(), directory_hash(), render_human(), run_compat(), run_graph(), run_upstream(), maintenance.sh script, update_recorded_hash() (+2 more)

### Community 136 - "ci-local"
Cohesion: 0.29
Nodes (12): gate_bats(), gate_dependencies(), gate_docs(), gate_formal(), gate_hygiene(), gate_install(), gate_lanes(), gate_openspec() (+4 more)

### Community 138 - "fm-session-golden.test / round-live-services"
Cohesion: 0.30
Nodes (10): childEnv(), commitPinned(), ENTRY, GOLDEN, HERE, normalize(), run(), TSX_LOADER (+2 more)

### Community 139 - "vendor-concurrency-test"
Cohesion: 0.27
Nodes (11): ARGV, LANE_ROOTS, POST_AUTH, PRE_AUTH, vendor-concurrency-test.sh script, vct_auth_status(), vct_build_argv(), vct_env_var() (+3 more)

### Community 140 - "tool-check.ps1"
Cohesion: 0.31
Nodes (9): Check-One(), Get-FileSha256(), Get-FsClass(), Get-HostClassForPin(), Get-LockAtomicityProbe(), Get-PinnedVerdict(), Get-Ver(), Test-Cmd() (+1 more)

### Community 141 - "check-schema-structure.py"
Cohesion: 0.35
Nodes (8): collect_failures(), extract_schema(), main(), Structural checks for the frozen terminusdb-schema (T1 + T2). Exit 0 only when…, Demonstrate the checker FAILS on known-bad inputs., run_on(), self_test(), Path

### Community 142 - "appliance-lock / appliance-lock.test"
Cohesion: 0.22
Nodes (8): renderApplianceLockV1(), LOCK_PATH, MANIFEST_PATH, ROOT, validateApplianceLockProjectionV1(), lockPath, manifestPath, root

### Community 143 - "rfc3339 / rfc3339.test"
Cohesion: 0.36
Nodes (9): approvalChronologyValid(), approvalIntervalValid(), ChronologyResult, daysInMonth(), fracToMs(), isLeapYear(), isRfc3339Instant(), parseRfc3339Ms() (+1 more)

### Community 144 - "agy"
Cohesion: 0.24
Nodes (5): _adapter_report_cli_version(), adapter_result_text(), adapter_result_verdict(), _adapter_validate_verdict_file(), agy.sh script

### Community 145 - "claude"
Cohesion: 0.24
Nodes (5): _adapter_report_cli_version(), adapter_result_text(), adapter_result_verdict(), _adapter_validate_verdict_file(), claude.sh script

### Community 146 - "codex"
Cohesion: 0.24
Nodes (5): _adapter_report_cli_version(), adapter_result_text(), adapter_result_verdict(), _adapter_validate_verdict_file(), codex.sh script

### Community 147 - "grok"
Cohesion: 0.24
Nodes (5): _adapter_report_cli_version(), adapter_result_text(), adapter_result_verdict(), _adapter_validate_verdict_file(), grok.sh script

### Community 148 - "audit-call"
Cohesion: 0.35
Nodes (10): _ac_config_get(), _ac_configured_candidates(), _ac_configured_model(), _ac_default_model(), _ac_has_adapter(), _ac_has_audit_capability(), ac_model_family(), ac_select_auditor() (+2 more)

### Community 149 - "check-inventory"
Cohesion: 0.45
Nodes (10): emit_row(), main(), scan_assertions(), scan_gate_runner(), scan_gate_scripts(), scan_gate_workflows(), scan_probes(), scan_probes_ts() (+2 more)

### Community 150 - "projection-epoch.test / qdrant-live.test"
Cohesion: 0.22
Nodes (5): Embedding, index(), LiveEmbedding, EmbeddingPort, FixedEmbedding

### Community 151 - "resume / checkpoint"
Cohesion: 0.33
Nodes (8): ckpt_snapshot(), checkpoint.sh script, exact_delete_extras(), main(), recover_prompt_payload(), resolve_checkpoint_sha(), resume.sh script, usage()

### Community 152 - "liveness"
Cohesion: 0.33
Nodes (7): lv_classify_pid(), lv_cputime_secs(), lv_etime_secs(), lv_is_dispatched_lane(), lv_is_live(), lv_ps_fields(), liveness.sh script

### Community 154 - "graph-store"
Cohesion: 0.39
Nodes (8): gs_capabilities(), gs_contract_files_only(), gs_contract_stub_expect_fail(), _gs_pkg_parent(), gs_python(), gs_smoke_no_store(), gs_version_ref(), graph-store.sh script

### Community 155 - "appliance-doctor-main / appliance-lock"
Cohesion: 0.33
Nodes (8): commandVersion(), directoryState(), exactSkillDirectories(), exitCode, observe(), REQUIRED_SKILLS, decodeApplianceLockV1(), invalid()

### Community 156 - "secret-scan / secret-scan-main"
Cohesion: 0.33
Nodes (8): EXIT_NOT_CLEAN, liveSecretScan, startSecretScanMain(), parseSecretScanArgv(), renderSecretScanJson(), runSecretScanCli(), stripSecretScanNodeArgv(), writeFully()

### Community 157 - "plugin-lessons"
Cohesion: 0.44
Nodes (8): harness_error(), main(), normalize_release(), record_finding(), run_candidates(), run_check(), plugin-lessons.sh script, usage()

### Community 158 - "inject-regressions"
Cohesion: 0.31
Nodes (5): main(), make_tree(), run_case(), inject-regressions.sh script, UNPROTECTED

### Community 159 - "bootstrap-wsl"
Cohesion: 0.54
Nodes (7): DEBIAN_FRONTEND, have(), install_apt(), link_native(), log(), native_ok(), bootstrap-wsl.sh script

### Community 160 - "schema-live-gate"
Cohesion: 0.50
Nodes (6): fail(), http_post(), log(), pass(), schema-live-gate.sh script, usage()

### Community 162 - "secret-scan"
Cohesion: 0.32
Nodes (8): closeDirQuiet(), fireAfterBindDirectory(), fireAfterObserveRegularFile(), isPemPrivateKeyLine(), isRefusedSecretFilename(), processDirectory(), refuse(), scanPemLines()

### Community 163 - "architecture-evaluate.test"
Cohesion: 0.25
Nodes (5): BASE, EXEC_IDENTITY, HEAD, MB, REPO_ROOT

### Community 164 - "graph-project"
Cohesion: 0.43
Nodes (7): gp_finding_hash(), gp_project_file(), gp_project_stream(), gp_usage(), gp_validate_events(), LC_ALL, graph-project.sh script

### Community 165 - "credential-profile / credential-profile-preflight.test"
Cohesion: 0.33
Nodes (7): makeCredentialProfileRecord(), readyRecord(), sampleWrapper(), seedR7aAuthority(), profileIdentityOf(), renderCredentialProfileRecord(), renderCredentialProfileRecordFile()

### Community 166 - "sqlite-store-open-race.test"
Cohesion: 0.38
Nodes (5): here, holderPath, waitForExit(), waitForLocked(), withExclusiveHolder()

### Community 167 - "graph-project-harness"
Cohesion: 0.48
Nodes (6): expect_rc(), known_nodes(), LC_ALL, record(), graph-project-harness.sh script, write_good_log()

### Community 168 - "check-registry-compare"
Cohesion: 0.57
Nodes (6): compare(), derive_inventory(), fail(), main(), check-registry-compare.sh script, validate_registry()

### Community 170 - "secret-scan"
Cohesion: 0.33
Nodes (6): fireAfterBindRoot(), isPositiveSafeIntegerBound(), isValidAbsoluteRoot(), normalizeRootInput(), scanWorktreeSync(), validateSecretScanBounds()

### Community 171 - "run-tests"
Cohesion: 0.33
Nodes (4): childEnv, empty, patterns, result

### Community 172 - "run-tests.test"
Cohesion: 0.33
Nodes (3): repositoryRoot, runTestsScript, scriptsDir

### Community 173 - "spec-correctness-cli.test"
Cohesion: 0.50
Nodes (5): asDigest(), computeSpecSetDigest(), encode(), sha256Hex(), [Symbol.asyncIterator]()

### Community 174 - "bootstrap-windows.ps1"
Cohesion: 0.80
Nodes (4): Have(), Log(), ScoopInstall(), WingetInstall()

### Community 175 - "busy-timeout-lock-holder"
Cohesion: 0.40
Nodes (4): db, holdMs, lockKind, send

### Community 177 - "init-firewall"
Cohesion: 0.70
Nodes (4): apply(), check(), resolve_and_allow(), init-firewall.sh script

### Community 178 - "durable-preflight"
Cohesion: 0.70
Nodes (4): dp_one(), dp_verify(), main(), durable-preflight.sh script

### Community 179 - "reap-stale-lanes"
Cohesion: 0.80
Nodes (4): cputime_secs(), etime_secs(), is_dispatched_lane(), reap-stale-lanes.sh script

### Community 180 - "run_known_bad"
Cohesion: 0.67
Nodes (3): expect_fail(), PYTHONPATH, run_known_bad.sh script

### Community 183 - "docs-check"
Cohesion: 0.83
Nodes (3): forced_missing(), record(), docs-check.sh script

### Community 184 - "lane-review-bundle"
Cohesion: 0.83
Nodes (3): _is_meta_path(), _paths_to_json(), lane-review-bundle.sh script

### Community 185 - "review-quorum"
Cohesion: 0.67
Nodes (3): rq_evaluate(), _rq_is_positive_int(), review-quorum.sh script

### Community 187 - "release-metrics-harness"
Cohesion: 0.67
Nodes (3): expect_case(), FOREMAN_REPO_ROOT, release-metrics-harness.sh script

## Knowledge Gaps
- **1452 isolated node(s):** `CLAUDE_FABLE_5_1_MODEL`, `ClaudeOuterWire`, `promptBytes`, `canaryInput`, `CodexThreadStartedWire` (+1447 more)
  These have ≤1 connection - possible missing edges or undocumented components. (Counts symbols only; 1995 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)
- **34 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `openFilesOnly()` connect `cli / cli.test` to `files-only / bounds`?**
  _High betweenness centrality (0.000) - this node is a cross-community bridge._
- **Why does `FilesOnlyGraphStore` connect `port / files-only` to `schema / files-only`, `files-only / bounds`, `failures / port`, `queries / failures`?**
  _High betweenness centrality (0.000) - this node is a cross-community bridge._
- **Why does `SqliteSessionStore` connect `sqlite-store / sidecar` to `contract-suite / entities`, `fm-session-main / fm-session-main.test`, `files-only / import-remap`, `files-only / contract-suite`?**
  _High betweenness centrality (0.000) - this node is a cross-community bridge._
- **What connects `CLAUDE_FABLE_5_1_MODEL`, `ClaudeOuterWire`, `promptBytes` to the rest of the system?**
  _1452 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `test-helpers / errors` be split into smaller, more focused modules?**
  _Cohesion score 0.03096821877309682 - nodes in this community are weakly interconnected._
- **Should `identifiers / quorum.test` be split into smaller, more focused modules?**
  _Cohesion score 0.02712859659424545 - nodes in this community are weakly interconnected._
- **Should `fm-session-main / fm-session-main.test` be split into smaller, more focused modules?**
  _Cohesion score 0.03443526170798898 - nodes in this community are weakly interconnected._