# Advisory combined Pel release graph

This graph combines structural code extraction, Markdown structure, selected semantic research, and source inventory.
Inventory nodes do not imply semantic review. Historical sources do not establish current release authority.
Host semantic token usage is unknown. No paid provider extraction calls were made by this graph build.
Graphify 0.9.61 output is advisory and does not meet the canonical 0.9.48 publication qualifier.

# Graph Report - foreman-dsl-release  (2026-09-12)

## Corpus Check
- 2059 files · ~4,376,447 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 21780 nodes · 51660 edges · 1817 communities (1094 shown, 723 thin omitted)
- Raw edge confidence labels: {"EXTRACTED": 52755, "INFERRED": 207}. These labels do not imply full semantic review.
Host semantic extraction token usage: unknown (not metered). Deterministic extraction requires no model calls.

## Community Hubs (Navigation)
- identifiers / quorum.test
- backend-boundary.test / fm-session-golden.test
- execution-terminal-policy / execution-ledger
- preflight / preflight.test
- schema / architecture-manifest
- services / platform
- effect-docs-url-inventory
- execution-contract / execution-guard-cli
- test-helpers / r3-error-safety.test
- release-coverage / release-coverage.test
- credential-profile / credential-profile-lane-cli
- release-authority / release-authority.test
- install-verify.test / install-verify-fs
- vendor-preflight-contract / vendor-preflight-cli
- bugeventlog
- tracked-delete.test / tracked-delete
- secret-scan / secret-scan.test
- entities / import-remap
- spec-correctness-admission.test / spec-correctness-admission
- release-coverage-cli.test
- appliance-lock / rootless-engine-qualification
- supervisor / resume-safety-services
- contract-suite / port
- queue-admission / queue-services
- tool-check-run / tool-check-cli
- prompt-preflight / prompt-preflight.test
- preflight-program / run-preflight.test
- round-contract / round-reducer
- graphify-qualification / graphify-qualification-main
- schema-lowering / r3-closed-json.test
- gemini-tools
- credential-profile-preflight / credential-profile-lane
- fm-session-main / write-atomic-writer
- release-coverage-cli
- durable-runtime
- claude-fable / claude-effort
- errors / prompt-preflight
- spec
- resume-worktree-restore / resume-queue-execution
- codex-app-server
- admit.test / approval-commit.integration.test
- spec-correctness-program.test / ready-token.test
- spec-correctness-cli.test / spec-correctness-cli
- vendor-preflight-manifest / build-runtime
- files-only / entities
- spec-correctness-admission.test / spec-correctness-admission
- posix / posix-bootstrap
- verify-runtime
- foreman-setup / foreman-setup.test
- design / ROADMAP
- server
- claude-cli / claude-headless
- N4-symbolic-verification
- run-journal
- preflight-cli.test / preflight-cli
- claude-cache
- files-only / failures
- anthropic-best-practices
- spec
- README / README.opencode
- release-policy / queue-cli
- common / wt-cleanup
- spec
- effect-domain
- round-transaction / round-live-services
- sqlite-store / failures
- ace / ace.test
- spec
- release-admission-cli / release-admission-cli.test
- release-admission.test / release-admission
- outbox.test / outbox
- R7-graphify-foundation
- evidence-rules / shell-conventions
- replay / replay.test
- tier2-shared / tier2-compare-main
- gemini-model / gemini-interactions
- 2026-08-08-tool-check-gates
- 2026-08-02-council-v030-localization
- contract-suite / contract.test
- session-sqlite-bootstrap / session-sqlite-bootstrap.test
- check-schema-structure / analyze-token-usage
- gemini-cli
- N1-neurosymbolic-foundations
- N3-llm-graph-consumption
- R5-internal-attachment-map
- spec
- spec
- graph-context / graph-context.test
- vendor-preflight / vendor-preflight-live
- review-admission / review-admission.test
- R3-vendor-adapters
- spec
- canonical-json / failures
- process-runner / process-runner.test
- gemini-text
- PM-acceptance-criteria
- spec
- attempt / failures
- lock
- run-preflight / provider-health
- spec
- spec-correctness
- canary-materializer / bundle-verifier
- memory-index / projection
- openai-sol-card
- R8-terminusdb-store
- fm-session-main.test / outbox-store.test
- project-registry / project-registry.test
- supervisor-live-services / supervisor-live-services.test
- SKILL / testing-anti-patterns
- effect-testing
- openai-cache
- openai-cache.raw
- N2-ontology-engineering
- REAUDIT-opus
- spec
- property-testing
- dependency-drift / dependency-drift.test
- spec
- openai-structured
- openai-structured.raw
- R2-anthropic-graph-infra
- 2026-07-31-v029-release-closeout-design
- RELEASE-NOTES
- suite-health
- openai-sol-card
- USAGE
- spec
- port / version-ref.test
- AUDIT-opus
- M1-lane-lifecycle
- run-journal.test / node:child_process
- gemini-background
- spec
- spec
- 2026-04-06-worktree-rototill-design
- spec-correctness
- gemini-card
- SKILL / code-reviewer
- qdrant-memory-index
- claude-structured
- gemini-structured
- REVIEW-opus
- spec
- spec
- schema / files-only
- tool-check-atomicity / tool-check-atomicity.test
- architecture-ts-inspect
- repo-hygiene / repo-hygiene.test
- test-sync-to-codex-plugin
- gemini-thinking
- openai-tools.raw
- round-cli / round-cli.test
- design
- spec
- failures / files-only-hostile.test
- gate-ground / gate-ground-checks
- SKILL
- openai-tools
- spec
- AGENT_TRAPS / foreman-qa-preflight
- migration-parity
- AUDIT-terminusdb-opus
- design
- 2025-11-22-opencode-support-implementation
- testing-skills-with-subagents
- RELEASE-NOTES
- 2026-07-28 / 2026-08-13
- plan-report
- search-report
- DECISIONS-resolved
- R4-graph-memory-sota
- R6-eval-and-workflow
- REVIEW-codex
- M4-evidence-contract
- import-remap-store.test / failures
- porting-to-a-new-harness
- 2026-06-09-visual-companion-issues
- tier1-replay
- spec
- hosted-node24-ci.test
- grok-structured
- AUDIT-L2
- watch / checkpoint
- check-architecture / eslint.config
- 2026-08-07-workflow-gates
- v0.2.8.2-v0.2.9.0-accomplishments
- AUDIT-infra-codex
- run-checks
- spec
- release-authority-cli / release-authority-cli.test
- resume-decision.test
- setup / test-priority
- security-spec-review
- security-spec-review
- foreman-pidns-degradation-2026-09-05
- PAPER-AND-COMPATIBILITY / arxiv-2505.13453v2
- spec
- spec
- bounds / queries
- 2026-05-06-lift-drill-into-evals
- RELEASE-NOTES
- provider-health.test
- final-fix-report
- 2026-07-15-durable-lanes
- five-part-spec / index
- README
- graph-evaluation / graph-evaluation.test
- evidence / vendor-multiround
- SKILL
- 2026-04-06-worktree-rototill
- branding.test
- README
- grok-cli / grok-headless
- grok-announcement / grok-model
- grok-model / grok-pricing
- codex-headless
- spec
- budget / budget.test
- task-7-report
- AUDIT-terminusdb-codex
- 2026-07-19-v029-wsl-compat
- 2026-07-15-foreman-enhancement-design
- VERIFY-quint-architect
- spec
- design
- spec
- sqlite-migration / sqlite-migration.test
- auth.test
- REPORT
- claude-headless / package
- gemini-pricing
- README
- spec
- spec
- spec
- audit-run / telemetry
- merge-gate / config
- README
- 2025-11-28-skills-improvements-from-user-feedback
- lifecycle.test
- server.test
- security-spec-review
- 2026-08-01
- node-runner
- resume-decision / ARCHITECTURE-AND-DELETION-MAP
- karpathy-llm-wiki / CAPTURE-NOTES
- claude-fable-changes
- SYNTHESIS
- 2026-07-16-v025-orchestration-hardening
- spec
- spec
- spec
- qdrant-client-port
- run / preconditions
- REPORT
- claude-opus-card / README
- claude-streaming
- gemini-pricing
- design
- spec
- design
- spec
- architecture-extensions / architecture-executable
- SKILL
- release-metrics
- 2025-11-22-opencode-support-design
- SKILL
- brokenwindows
- claude-effort
- openai-reasoning
- openai-reasoning.raw
- round-latency-fable-5-1
- PKG-graph-workplane-summary
- 2026-08-12-sessiondb-completion
- 2026-08-07-v030-node-migration-completion-design
- design
- spec
- spec
- spec
- design
- architecture-schema / architecture-delta
- lane-run / eventlog
- worktree / wt-merge
- visual-companion
- CREATION-LOG
- test-helpers / test-worktree-native-preference
- spec
- spec
- schema-file-materializer / schema-file-materializer.test
- spec-correctness.test / spec-correctness
- tier1-failure-classes
- t1-premise-check
- REPORT
- REPORT
- task-8-fix-report
- grok-responses
- architect-weight-fable-5-1
- 2026-08-12-task-6a-review
- 2026-08-12-sessiondb-completion-design
- M3-audit-gate
- spec
- spec
- open / files-only-lock-contender
- superpowers / helper.test
- CLAUDE
- polyglot-hooks
- sync-to-codex-plugin
- 2026-08-07-remaining-gates
- 2026-08-08-run-sh-gates
- AUDIT-merge-ready
- REPORT
- dogfood-lane-grok.report
- task-6-report
- 2026-08-08-regime-coverage
- 2026-07-19-empirical-workloads
- 2026-07-18-v0275-usability-design
- spec
- spec
- design
- 2026-02-19-visual-brainstorming-refactor-design
- 2026-03-23-codex-app-compatibility-design
- SKILL
- spec
- spec
- spec
- spec
- AUDIT-devlog-2026-07-30
- AUDIT-devlog-2026-07-30
- REPORT
- REWORK
- orchestration-deep-research-report
- 2026-07-18-hard-mode-launcher
- M2-concurrency
- spec
- spec
- spec
- tasks
- spec
- spec
- qdrant-memory-index.test / qdrant-memory-index
- architecture-git
- SKILL
- SKILL
- CLAUDE_MD_TESTING
- evidence-mechanism
- typescript-conventions / AGENTS
- REPORT
- REPORT
- ADAPTER-EVIDENCE / README
- openai-background.raw / openai-streaming
- 2026-07-15-foreman-enhancement
- 2026-07-19-v0281-field-fixes
- 2026-08-07-v030-w0-unblock
- 2026-07-15-durable-lanes-design
- 2026-08-11-sessiondb-port-unification-design
- spec
- design / proposal
- transformers-embedding / index
- projection-epoch.test
- round-reducer.test / round-contract
- architecture-evaluate / architecture-extensions
- eventlog / nats-bridge
- site-patterns
- 2026-06-10-visual-companion-auth-hardening-design
- 2026-06-11-visual-companion-final-hardening-fixup-design
- SKILL
- root-cause-tracing
- persuasion-principles
- RESEARCH_REPORT
- spec
- grok-tools / grok-structured
- storage-port
- AUDIT-sol-L1-r2
- REPORT
- task-1-report
- v0.3.0-stale-log
- claude-fable / claude-fable-card
- claude-tools
- 2026-08-07-v030-w1-regime
- 2026-08-17-v031-closeout
- 2026-07-19-v029-wsl-compat-design
- proposal / tasks
- design
- README
- spec
- spec
- spec
- spec
- spec
- spec
- captured-facts
- 2026-03-11-zero-dep-brainstorm-server-design
- lane-ownership-harness
- lanectl
- spec
- security-spec-review
- RESEARCH_REPORT
- 2026-08-01-council-foundation
- design
- spec
- tasks
- spec-correctness.test / spec-correctness
- grok-reasoning / grok-pricing
- session-store-ontology-links
- 2026-08-07-architecture-policy-options
- 2026-08-07-windows-suite-measurement
- claude-thinking
- gemini-interactions
- openai-astra-guide
- openai-astra-guide.raw
- codex-review
- FINAL-opus
- 2026-07-18-v0275-1-lifecycle-three-stage
- 2026-08-11-sessiondb-port-unification
- 2026-07-19-empirical-workloads-design
- tasks
- design
- spec
- tasks
- design
- design
- cli / main
- architecture-adapter
- projection-lease
- orchestration-hardening
- parallel-worktrees
- 2026-06-10-visual-companion-auth-hardening
- 2026-06-09-sdd-task-scoped-review-dispatch-design
- selftest-test-infrastructure
- openai-astra.raw / openai-sol.raw
- AUDIT-final
- REPORT
- REPORT
- v0.2.8.2-cleanup-log
- openai-sol
- research-citations
- EDIT-readme-line
- 2026-08-02-council-review-plane
- 2026-08-02-node-typescript-migration
- tasks
- design
- spec
- sprints
- tasks
- design
- spec
- projection-epoch / projection-lease
- qdrant-client-port.test
- metrics-lint
- maintenance
- PULL_REQUEST_TEMPLATE
- INSTALL
- CODE_OF_CONDUCT
- 2026-05-06-lift-drill-into-evals-design
- 2026-06-10-positive-instruction-redesign-design
- 2026-06-10-strict-cost-sdd-design
- lint-shell
- SKILL
- test-package-codex-plugin
- ci-local
- grok-implementer
- security-spec-review
- README
- grok-text
- AUDIT-sol
- AUDIT-sol-r3
- BRIEF
- v0.2.9.0-notes
- claude-opus
- gemini-pricing
- openai-astra
- openai-sol.raw
- openai-state
- openai-state.raw
- 2026-07-18-v0275-3-wsl-reliability-env-refresh
- 2026-07-18-v0275-4-worktree-hardening
- 2026-07-18-v0275-7-docs-readme-refresh
- 2026-07-31-v029-tranche-a1-recording-instruments
- 2026-08-08-v031-session-portability
- 2026-08-08-v031-release-design
- 2026-09-12-pel-release-design
- ground-truth-inventory
- spec
- design
- spec
- spec
- tasks
- r4c3-design
- durable-lanes
- lanes
- reference-environment
- vendor-concurrency-test
- SKILL
- superpowers
- 2026-05-05-platform-neutral-config-refs-design
- 2026-05-05-platform-neutral-prose-design
- defense-in-depth
- SKILL
- test-bootstrap-caching
- typescriptmigration
- RELEASE-NOTES
- SKILL
- SKILL
- COUNCIL-ACE-PROFILE
- SKILL
- lane-p1-rework.report
- AUDIT-L3
- task-4-report
- task-8-report
- AUDIT-MERGE
- v0.2.8.2-notes
- v0.2.9.0-cleanup-log
- foreman-model-routing-2026-09-04
- REPORT_B-prevention
- REPORT_C-environment
- AUDIT-gpt6-astra-round1-2026-09-05
- AUDIT-gpt6-astra-round2-2026-09-05
- AUDIT-gpt6-astra-round3-2026-09-05
- AUDIT-gpt6-astra-round4-2026-09-05
- FINAL-codex
- RECONCILE
- brief
- 2026-07-18-v0275-2-grok-lane-activation
- 2026-07-18-v0275-5-posix-cascade-parity
- 2026-09-12-pel-release-plan
- 2026-07-15-readme-deepening-design
- 2026-08-06-v030-checkpoint
- tool-check
- spec
- spec
- spec
- tasks
- design
- design
- tasks
- spec
- tasks
- spec
- spec
- architecture-cli / architecture-cli.test
- INSTALL / README
- SKILL
- security-model
- agy
- claude
- codex
- grok
- audit-call
- resume / checkpoint
- SKILL
- api-quick-ref
- troubleshooting
- 2026-02-19-visual-brainstorming-refactor
- 2026-03-23-codex-app-compatibility
- 2026-06-11-visual-companion-final-hardening-fixup
- SKILL
- test-lint-shell
- check-inventory
- files-only / port
- codex-implementer
- explore
- spec
- 2026-09-05
- gemini-headless
- AUDIT-2026-07-30-fullsuite
- BRIEF
- AUDIT-sol-L1
- BRIEF
- REPORT
- BRIEF
- REPORT
- 2026-07-29-lane-strandings
- 2026-07-17-resume-checkpoint
- REPORT_compile
- REPORT_ffi
- gemini-cache / gemini-model
- openai-sol-card
- vendor-concurrency-results
- F-uutils-mkdir-blocker
- 2026-07-18-v0275-6-t5b-concurrency-verdict
- 2026-08-05-bounded-execution-terminal-policy
- 2026-08-03-council-preflight-cli-design
- spec
- spec
- tasks
- tasks
- tasks
- design
- tasks
- design
- design
- tasks
- tasks
- tasks
- protocol
- audit-checklist
- liveness
- 2026-01-22-document-review-system
- 2026-03-11-zero-dep-brainstorm-server
- 2026-06-09-sdd-task-scoped-review-dispatch
- condition-based-waiting
- windows-lifecycle.test
- ws-protocol.test / server
- helpers
- spec
- codex-auditor
- foreman-audit
- security-spec-review
- 2026-08-02-ace-prompt-preflight
- spec
- grok-cache / grok-model
- 2026-08-02
- REPORT
- BRIEF
- BRIEF
- graph-store
- experiments
- INSTALL
- 2026-07-18-v025-sc-proof
- v0.3.0-destruction-log
- effect-concurrency
- effect-services-testing
- EDIT-readme-facts
- LANDING-ORDER
- REAUDIT-codex
- START-HERE
- 2026-07-16-foreman-launch
- 2026-08-03-council-preflight-cli
- 2026-08-04-v030-r4c-persisted-preflight
- RESUME
- design
- spec
- proposal
- design
- tasks
- spec
- design
- tasks
- design
- design
- plugin-lessons
- gate-and-ratchets
- README
- roles
- exports
- 2026-01-22-document-review-system-design
- bump-version
- SKILL
- helper
- render-graphs
- stop-server.test
- inject-regressions
- foreman-plan
- foreman-search
- checklist
- CLAUDE
- 2026-08-08-d2-path-confusion
- 2026-08-08-tool-check-ts-controls
- BRIEF
- REWORK
- REPORT
- task-3-report
- task-5-report
- REWORK
- v0.3.1-notes
- effect-errors-resources
- REPORT_D-sequencing
- EDIT-readme-structural
- PKG-workflow-summary
- VERIFY-terminusdb-schema-live
- RESIDUALS
- 2026-07-19-v0281-field-fixes-design
- 2026-09-05-v050-release-design
- bootstrap-wsl
- tasks
- tasks
- spec
- spec
- proposal
- schema-live-gate
- design
- design
- proposal
- design
- tasks
- design
- proposal
- tasks
- design
- design
- design
- proposal
- tasks
- design
- design
- proposal
- design
- design
- r4c3-implementation-plan
- design
- design
- tasks
- tasks
- SKILL
- SKILL
- bats-traps
- SKILL
- graph-project
- maintenance
- bug_report
- 2026-01-17-visual-brainstorming
- 2026-05-05-platform-neutral-readme-design
- package-codex-plugin
- architecture-ts-inspect.test / bun
- RESEARCH_REPORT
- proposal
- tasks
- proposal
- proposal
- spec
- proposal
- 2026-07-29
- 2026-08-08-predicate-1-tier2
- 2026-08-06-control-record
- 2026-08-07-baseline-platform
- README
- REWORK
- BRIEF
- REPORT
- BRIEF
- BRIEF
- BRIEF
- BRIEF
- REPORT
- task-2-report
- README
- README
- README
- README
- v0.3.0-notes
- v0.4.0-checklist
- v0.4.0-notes
- codex-app-server
- gemini-card
- grok-pricing
- openai-background
- CONSOLIDATED
- gates-and-tests-gpt-6-astra
- orchestration-ceremony-gpt-6-astra
- DECISION-audit-evidence-root
- VERIFY-opus-findings
- 2026-08-03-total-georgecall-release-truth
- 2026-08-05-v030-r7b2-endstop-packages
- 2026-08-05-v030-r7c-profile-use-leasing
- 2026-08-03-council-preflight-path-normalization-design
- 2026-08-03-v029-release-artwork-design
- auth-probes
- ROADMAP
- spec
- spec
- spec
- tasks
- design
- tasks
- tasks
- design
- tasks
- design
- design
- proposal
- tasks
- proposal
- tasks
- design
- tasks
- tasks
- tasks
- spec
- design
- spec
- spec
- ROADMAP
- SKILL
- model-routing-evidence
- stall
- security
- feature_request
- stop-server
- test-session-start
- graph-project-harness
- check-registry-compare
- spec
- spec
- 2026-08-03-xai-live-smoke
- design
- tasks
- design
- tasks
- design
- 2026-08-06
- 2026-08-08-tool-check-coverage-reconciliation
- README
- README
- BRIEF
- BRIEF
- REWORK
- REWORK
- BRIEF
- BRIEF
- 2026-07-16-resume-checkpoint
- claude-cli
- openai-streaming.raw
- research-summary
- fable
- gpt-5.6-sol
- grok-4.5
- 2026-07-15-foreman-combined-skill-design
- 2026-08-03-council-canary-nonce-binding-design
- 2026-08-05-resume-safety-services-design
- 2026-08-05-round-resume-decision-design
- tasks
- measurements
- proposal
- design
- design
- WITHDRAWN
- design
- proposal
- proposal
- design
- PARKED
- tasks
- tasks
- design
- design
- proposal
- PARKED
- proposal
- proposal
- design
- design
- design
- proposal
- proposal
- supervisor-main
- run-tests
- ownership
- query
- cookie-vault
- upstream-map
- 2026-05-07-pi-extension-and-evals
- condition-based-waiting-example
- SKILL
- start-server.test
- test-sdd-workspace
- spec
- spec
- RELEASE-NOTES
- foreman-advisor
- bugeventlog
- bugeventlog
- bugeventlog
- bugeventlog
- bugeventlog
- bugeventlog
- bugeventlog
- bugeventlog
- bugeventlog
- bugeventlog
- visual-pass
- spec
- tasks
- README
- README
- 2026-07-15-planning-fidelity
- TOOLS-AND-VAULT
- 2026-08-05-resume-safety-services
- 2026-08-05-round-resume-decision
- bootstrap-windows
- proposal
- design
- proposal
- design
- proposal
- proposal
- design
- proposal
- design
- proposal
- design
- proposal
- design
- proposal
- proposal
- design
- proposal
- proposal
- tasks
- WITHDRAWN
- proposal
- WITHDRAWN
- proposal
- design
- proposal
- proposal
- design
- tasks
- proposal
- proposal
- proposal
- proposal
- design
- proposal
- proposal
- proposal
- proposal
- proposal
- proposal
- tasks
- proposal
- proposal
- proposal
- proposal
- proposal
- proposal
- proposal
- proposal
- proposal
- proposal
- proposal
- proposal
- proposal
- proposal
- design
- proposal
- coverage-matrix
- proposal
- proposal
- proposal
- proposal
- proposal
- proposal
- tasks
- proposal
- design
- proposal
- proposal
- proposal
- proposal
- qdrant-live.test / qdrant-memory-index
- SKILL
- init-firewall
- README
- durable-preflight
- release-policy
- platform_support
- test-pressure-1
- test-pressure-2
- test-pressure-3
- run-all / run-test
- reap-stale-lanes
- spec
- spec
- spec
- RELEASE-NOTES
- SKILL
- bugeventlog
- bugeventlog
- bugeventlog
- run_known_bad
- effect-docs-url-inventory
- gemini-pricing
- gemini-pricing
- gemini-pricing
- gemini-pricing
- gemini-pricing
- gemini-pricing
- gemini-pricing
- gemini-pricing
- gemini-pricing
- REPORT_A-drift
- 2026-08-03-council-canary-nonce-binding
- 2026-08-03-council-preflight-path-normalization
- README
- wsl-clock-preflight
- tasks
- tasks
- proposal
- tasks
- tasks
- tasks
- tasks
- tasks
- tasks
- tasks
- foreman-qa-reviewer
- docs-check
- lane-review-bundle
- review-quorum
- add-watch
- hooks
- update
- testing
- codex-tools
- pi-tools
- browser-launcher.test
- test-worktree-path-policy
- positive-control
- release-metrics-harness
- spec
- spec
- spec
- RELEASE-NOTES
- RELEASE-NOTES
- RELEASE-NOTES
- SKILL
- SKILL
- bugeventlog
- bugeventlog
- bugeventlog
- codex-app-server
- run_contract
- claude--docs-claude-com-en-docs-about-claude-models-overview
- claude--docs-claude-com-en-docs-about-claude-pricing
- gemini--ai-google-dev-gemini-api-docs-models
- gemini--ai-google-dev-gemini-api-docs-pricing
- gpt-5.6--developers-openai-com-api-docs-models-gpt-5-6-luna
- gpt-5.6--developers-openai-com-api-docs-models-gpt-5-6-sol
- gpt-5.6--openai-com-index-gpt-5-6
- grok-4.5--docs-x-ai-docs-models
- grok-4.5--docs-x-ai-docs-overview
- openai-sol-card
- openai-sol-card
- REWORK-round4-2026-09-05
- install
- install
- tasks
- sprints
- release-coverage-main / release-coverage-cli
- launch
- worker-cmd
- github-and-merge
- transcribe
- parse_only
- session-start
- start-server
- antigravity-tools
- test-antigravity-tools
- spec
- spec
- spec
- spec
- spec
- spec
- spec
- RELEASE-NOTES
- RELEASE-NOTES
- RELEASE-NOTES
- RELEASE-NOTES
- SKILL
- SKILL
- bugeventlog
- bugeventlog
- vitest.config
- README
- check-drift
- README
- README
- progress
- task-1-brief
- task-2-brief
- task-3-brief
- task-4-brief
- task-5-brief
- task-6-brief
- task-7-brief
- task-8-brief
- parked-bugeventlog-entries
- gemini-pricing
- gemini-pricing
- gemini-pricing
- gemini-pricing
- gemini-pricing
- gemini-pricing
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- README
- grok-lane-readiness-2026-09-05
- REWORK-round1-2026-09-05
- REWORK-round2-2026-09-05
- REWORK-round3-2026-09-05
- baseline-2026-09-05
- foreman-env-write
- tool-check
- check-drift
- v0.4.0-release-policy-drift
- README
- tasks
- tasks
- tasks
- tasks
- tasks
- tasks
- tasks
- tasks
- tasks
- tasks
- tasks
- tasks
- tasks
- tasks
- tasks
- tasks
- tasks
- LESSONS
- foreman-qa-review
- entrypoint
- VENDORED
- foreman-setup
- lane-complete-check
- lane-queue
- lane-supervise
- extraction-spec
- spec-document-reviewer-prompt
- review-package
- sdd-workspace
- task-brief
- find-polluter
- test-academic
- plan-document-reviewer-prompt
- run-tests
- run-skill-tests
- test-marketplace-manifest
- run-extended-multiturn-test
- run-haiku-test
- run-multiturn-test
- run-tests
- test-plugin-manifest
- run-tests
- readme-structure-check
- fixture-adapter
- SKILL
- version-line-bad
- version-line-good
- council-prettier-bad
- council-prettier-good
- mkdir-atomicity
- tier2-collect
- tier2-compare
- tier2-trigger-scan
- plugin-drift
- repo-hygiene
- spec
- spec
- spec
- spec
- spec
- spec
- spec
- spec
- spec
- spec
- spec
- spec
- spec
- spec
- spec
- RELEASE-NOTES
- RELEASE-NOTES
- RELEASE-NOTES
- RELEASE-NOTES
- RELEASE-NOTES
- RELEASE-NOTES
- bugeventlog
- apply
- archive
- propose
- sync
- update
- SKILL
- SKILL
- SKILL
- SKILL
- SKILL
- SKILL
- SKILL
- SKILL
- SKILL
- SKILL
- SKILL
- SKILL
- SKILL
- SKILL
- SKILL
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- openai-sol-card
- build
- AGENTS
- GEMINI
- launcher-build-bad
- plugin
- marketplace
- .codespellrc
- .dockerignore
- config
- session
- .gitattributes
- formal
- gates-linux
- gates-windows
- maintenance
- windows-smoke
- .gitignore
- .graphifyignore
- .markdownlint-cli2
- LICENSE
- foreman-banner
- v029-total-georgecall
- v031-georges-odyssey
- apply
- archive
- explore
- propose
- sync
- update
- .gitignore
- .prettierignore
- .prettierrc
- SOURCES
- SOURCES
- SOURCES
- anthropic-architecture
- reconcile-ablation
- .openspec
- .openspec
- config
- package
- package
- tsconfig
- package
- tsconfig
- package
- tsconfig
- package
- tsconfig
- package
- anthropic-schema-rejected
- completed-insufficient-evidence
- xai-interim-then-cancelled
- tsconfig
- package
- tsconfig
- package
- tsconfig
- package
- tsconfig
- pnpm-lock
- pnpm-workspace
- tsconfig.base
- tsconfig.eslint
- tsconfig
- foreman.toml
- Dockerfile
- compose
- devcontainer
- graphify-requirements
- graphify
- containers
- foreman-engine
- foreman-engine
- foreman-engine
- foreman-engine
- storage
- lock
- package-lock
- package
- council-3domain.advisory
- council-3domain.summary
- regression-harness-tier0-deltas
- admission-identity
- admission-result
- candidate-object-delta
- preflight-receipt
- provider-response
- review-terminal
- admission-identity
- admission-result
- candidate-object-delta
- preflight-receipt
- provider-response
- review-terminal
- admission-identity
- admission-result
- candidate-object-delta
- preflight-receipt
- provider-response
- review-terminal
- attempt-01-admission-result
- attempt-01-provider-response
- attempt-02-admission-identity
- attempt-02-admission-result
- attempt-02-preflight-receipt
- attempt-02-provider-response
- attempt-02-review-terminal
- audit-approved
- anthropic
- openai
- xai
- audit-round-1-blocked
- audit-round-2-approved
- council-closure
- audit-groundedness-gate-T1T2.audit
- cross-vendor-audit-routing-T3T4.audit
- dogfood-lane-codex.audit
- freshness-and-tier2.verification
- gate-ground-T3-and-four-classify.audit
- tier2-machinery.lane-report
- graph-store-contract
- fetch-index
- ste-rules
- v0.4.0-graph-evaluation-run-set
- v0.4.0-graph-evaluation
- anthropic_multi_agent
- fetch-index
- MANIFEST
- acquisition
- approved-tests-2026-09-05
- hb-l1
- hb-node
- launcher-run-receipt
- probe-receipt
- run-events-restricted
- strace-launcher-selected
- strace-p0
- userns-cgroup-receipt
- openai_codex_exec
- SHA256SUMS
- claude-cache.raw
- claude-cli.raw
- claude-effort.raw
- claude-fable-card.raw
- claude-fable-changes.raw
- claude-fable.raw
- claude-headless.raw
- claude-opus-card.raw
- claude-opus.raw
- claude-streaming.raw
- claude-structured.raw
- claude-thinking.raw
- claude-tools.raw
- codex-app-server.raw
- codex-headless.raw
- gemini-background.raw
- gemini-cache.raw
- gemini-card.raw
- gemini-cli.raw
- gemini-headless.raw
- gemini-interactions.raw
- gemini-model.raw
- gemini-pricing.raw
- gemini-signatures.raw
- gemini-structured.raw
- gemini-text.raw
- gemini-thinking.raw
- gemini-tools.raw
- grok-announcement.raw
- grok-cache.raw
- grok-card.raw
- grok-cli.raw
- grok-headless.raw
- grok-model.raw
- grok-pricing.raw
- grok-reasoning.raw
- grok-responses.raw
- grok-structured.raw
- grok-text.raw
- grok-tools.raw
- manifest
- openai-astra-card.raw
- openai-sol-card.raw
- robots-ai.google.dev
- robots-code.claude.com
- robots-deepmind.google
- robots-deploymentsafety.openai.com
- robots-developers.openai.com
- robots-docs.x.ai
- robots-geminicli.com
- robots-media.x.ai
- robots-platform.claude.com
- robots-www.anthropic.com
- robots-x.ai
- arxiv-2505.13453v2-abs
- arxiv-2505.13453v2
- author-homepage
- github-pel-author-search
- github-pel-language-search
- github-pel-search
- karpathy-llm-wiki-gist-retry
- karpathy-llm-wiki-gist
- karpathy-llm-wiki
- manifest
- installation-receipt
- manifest
- release
- codex-review
- SOURCE-karpathy-graph-engineering
- xai_grok_headless
- reference-manifest
- wsl-clock-resync-task
- coverage
- expectations
- classifier-holding
- classifier-truncated-partial
- classifier-truncated
- classifier-violating
- known-holding
- known-violating
- success-contains-violation
- audit_gate
- eventlog_concurrency
- evidence_contract
- foreman_lifecycle
- lane_lifecycle
- vacuous-predicates
- graph
- refresh-meta
- .bun-version
- bun
- bunfig
- package
- .openspec
- .openspec
- .openspec
- .openspec
- .openspec
- release-brief
- .openspec
- .openspec
- release-brief
- .openspec
- release-brief
- .openspec
- release-brief
- .openspec
- release-brief
- .openspec
- .openspec
- .openspec
- .openspec
- release-brief
- .openspec
- .openspec
- .openspec
- .openspec
- coverage
- release-brief
- .openspec
- coverage
- .openspec
- release-brief
- .openspec
- .openspec
- schema
- schema
- package-lock
- package
- tsconfig
- package
- tsconfig
- package
- tsconfig
- package
- tsconfig
- package
- tsconfig
- package
- close-done
- close-done
- close-done
- close-unknown
- close-unknown
- close-unknown
- end-unknown
- end-unknown
- end-unknown
- end
- end
- end
- freshness-stale-only
- freshness-stale-only
- freshness-stale-only
- freshness
- freshness
- freshness
- measure-nonfinite
- measure-nonfinite
- measure-nonfinite
- recover-json
- recover-json
- recover-json
- recover
- recover
- recover
- retire-missing-by
- retire-missing-by
- retire-missing-by
- retire-missing-target
- retire-missing-target
- retire-missing-target
- retire-self
- retire-self
- retire-self
- retire
- retire
- retire
- seed
- supersede-missing
- supersede-missing
- supersede-missing
- supersede-superseded
- supersede-superseded
- supersede-superseded
- tsconfig
- package
- active-inventory
- coverage
- package-workflows
- external-memory-index
- graph-context-builder
- graph-eval-falsification
- hermetic-foreman-appliance
- knowledge-plane-refresh
- project-registry
- v040-release-program
- work-dag-projection
- tsconfig
- package
- tsconfig
- plugin
- Dockerfile
- devcontainer
- index
- style
- openai
- regression-tier-budgets
- appliance-doctor
- architecture-policy
- credential-profile-lane
- credential-profile
- dependency-drift
- destruction-guard
- execution-guard
- fm-session
- foreman-launch
- foreman-setup
- graph-context
- graph-evaluation
- graph-store
- graphify-qualification
- lane-queue
- lane-round
- lane-supervise
- release-admission
- release-authority
- release-coverage
- release-policy
- repo-hygiene
- secret-scan
- tier2-collect
- tier2-compare
- tool-check
- vendor-preflight
- manifest
- verdict.schema
- gate-ground-registry
- .graphify_version
- .gitignore
- LICENSE
- marketplace
- marketplace
- plugin
- plugin
- plugin
- .gitattributes
- FUNDING
- config
- .gitignore
- plugin
- .pre-commit-config
- .version-bump
- LICENSE
- app-icon
- superpowers-small
- gemini-extension
- hooks-cursor
- hooks
- run-hook
- package
- frame-template
- graphviz-conventions
- package-lock
- package
- action-oriented
- after-planning-flow
- claude-suggested-it
- i-know-what-sdd-means
- mid-conversation-execute-plan
- please-use-brainstorming
- skip-formalities
- subagent-driven-development-please
- use-systematic-debugging
- adapters
- audit-routing
- audit-verdict
- baseline
- checkpoint
- checks-run
- config
- council-localization
- decision-events
- docs-check
- durable-preflight
- eventlog
- evidence
- fit-report
- verdict-approved
- verdict-blocked
- G1.expected
- G1
- G2.expected
- G2
- G3.expected
- G3
- G4.expected
- G4
- G5.expected
- G5
- G6.expected
- G6
- G9a.expected
- G9a
- G9b.expected
- G9b
- G9c.expected
- G9c
- baseline.expected
- baseline
- baseline-header-bad
- baseline-header-good
- baseline-platform-bad
- baseline-platform-good
- skip-budget-header-bad
- skip-budget-header-good
- skip-budget-platform-bad
- skip-budget-platform-good
- trivial
- .gitkeep
- sample
- registry-compare-bad
- unanchored-bad
- unanchored-good
- bare-skip
- healthy-slice
- baseline-aggregate
- baseline-bare
- baseline-below
- baseline-within
- skip-aggregate
- skip-bare
- skip-over
- skip-within
- preconditions
- reasoned-skip
- regressed-slice
- collection-plan
- comparison
- budget-tier-run-records
- compare-comparison
- rate-zero-trials
- rate-zero-trials
- tier-run-records
- atomicity-strace-hidden
- atomicity-strace-normal
- .gitkeep
- .gitkeep
- fs-class-bad
- fs-class-good
- host-class-bad
- host-class-good
- manifest-bad
- manifest-good
- trace-good
- probe-flock-bad
- probe-flock-real
- probe-mkdir-decoy
- probe-mkdir-real
- sha256-bad
- sha256-good
- formal-expectations-bad
- formal-expectations-good
- foreman-cleanup
- foreman-setup
- gate-eval
- gate-ground
- git-guards
- corrected-trace
- defective-trace
- demonstration
- transcript
- corrected-trace
- defective-trace
- demonstration
- transcript
- corrected-trace
- defective-trace
- demonstration
- transcript
- corrected-trace
- defective-trace
- demonstration
- transcript
- corrected-trace
- defective-trace
- demonstration
- transcript
- corrected-trace
- defective-trace
- demonstration
- transcript
- corrected-trace
- defective-trace
- demonstration
- transcript
- corrected-trace
- defective-trace
- demonstration
- transcript
- corrected-trace
- defective-trace
- demonstration
- transcript
- corrected-trace
- defective-trace
- demonstration
- transcript
- graph-project
- grok-lane
- lane-queue
- lane-review-bundle
- lane-run
- lane-supervise
- launch-lib
- launcher
- lifecycle-gate
- line-endings
- lock
- maintenance
- merge-gate
- nats-bridge
- plugin-drift
- positive-control-registry
- positive-control-todo
- positive-control
- pr-open
- readme-structure
- release-metrics
- release-policy
- resume
- review-quorum
- round-ownership
- session
- skip-budget
- soft-mode-target
- telemetry
- test-policy
- tier1-replay
- tier2-compare
- tier2-golden
- tool-check-auth
- vendor-concurrency-test
- vendor-isolation
- vendor-multiround
- watch
- worker-cmd
- worker-run
- wsl-clock-preflight
- wsl-launcher-shipped
- wt-cleanup
- wt-merge
- wt-new
- tsconfig.all
- tsconfig.base
- tsconfig

## God Nodes (most connected - your core abstractions)
1. `File inventory: bugeventlog.md` - 200 edges
2. `File inventory: skills/superpowers/RELEASE-NOTES.md` - 171 edges
3. `canonicalize()` - 166 edges
4. `ref_effect` - 159 edges
5. `File inventory: docs/research/pel-release/sources/models/openai-sol-card.md` - 149 edges
6. `ref_node_path` - 143 edges
7. `ref_node_fs` - 133 edges
8. `ref_node_assert_strict` - 124 edges
9. `ref_node_test` - 124 edges
10. `File inventory: openspec/changes/v040-release-program/specs/release-program/spec.md` - 122 edges

## Surprising Connections (you probably didn't know these)
- `REPeL restarts` --semantically_similar_to--> `EndstopLedger`  [INFERRED] [semantically similar]
  docs/research/pel-release/sources/pel/arxiv-2505.13453v2.txt → packages/orchestration/src/execution-ledger.ts
- `Foreman Pel implementation proposal` --references--> `supervise`  [EXTRACTED]
  docs/research/pel-release/PAPER-AND-COMPATIBILITY.md → packages/launcher/src/supervise.ts
- `Foreman Pel implementation proposal` --references--> `ExecutionContractV1`  [EXTRACTED]
  docs/research/pel-release/PAPER-AND-COMPATIBILITY.md → packages/orchestration/src/execution-contract.ts
- `Foreman Pel implementation proposal` --references--> `EndstopLedger`  [EXTRACTED]
  docs/research/pel-release/PAPER-AND-COMPATIBILITY.md → packages/orchestration/src/execution-ledger.ts
- `Foreman Pel implementation proposal` --references--> `reduceRoundEvent`  [EXTRACTED]
  docs/research/pel-release/PAPER-AND-COMPATIBILITY.md → packages/orchestration/src/round-reducer.ts

## Import Cycles
- 1-file cycle: `components/council/eslint.config.mjs -> components/council/eslint.config.mjs`
- 1-file cycle: `components/council/packages/adapter-claude/src/preflight.ts -> components/council/packages/adapter-claude/src/preflight.ts`
- 1-file cycle: `components/council/packages/adapter-claude/test/preflight.test.ts -> components/council/packages/adapter-claude/test/preflight.test.ts`
- 1-file cycle: `components/council/packages/domain/test/budget.test.ts -> components/council/packages/domain/test/budget.test.ts`
- 1-file cycle: `components/council/packages/domain/test/review-admission.test.ts -> components/council/packages/domain/test/review-admission.test.ts`
- 1-file cycle: `components/council/packages/platform-node/src/canary-materializer.ts -> components/council/packages/platform-node/src/canary-materializer.ts`
- 1-file cycle: `components/council/packages/platform-node/src/process-runner.ts -> components/council/packages/platform-node/src/process-runner.ts`
- 1-file cycle: `components/council/packages/schema/src/authority.ts -> components/council/packages/schema/src/authority.ts`
- 1-file cycle: `components/council/packages/schema/src/prompt-preflight.ts -> components/council/packages/schema/src/prompt-preflight.ts`
- 1-file cycle: `components/council/scripts/build-runtime.ts -> components/council/scripts/build-runtime.ts`
- 1-file cycle: `components/council/scripts/check-architecture.mjs -> components/council/scripts/check-architecture.mjs`
- 1-file cycle: `components/council/tests/architecture/hosted-node24-ci.test.ts -> components/council/tests/architecture/hosted-node24-ci.test.ts`
- 1-file cycle: `components/council/vitest.config.ts -> components/council/vitest.config.ts`
- 1-file cycle: `docs/reference/models/fetch-model-docs.py -> docs/reference/models/fetch-model-docs.py`
- 1-file cycle: `launcher/src/posix-bootstrap.ts -> launcher/src/posix-bootstrap.ts`
- 1-file cycle: `launcher/tests/jobobject.test.ts -> launcher/tests/jobobject.test.ts`
- 1-file cycle: `packages/core/src/bounded-read.test.ts -> packages/core/src/bounded-read.test.ts`
- 1-file cycle: `packages/orchestration/src/fm-session-main.test.ts -> packages/orchestration/src/fm-session-main.test.ts`
- 1-file cycle: `packages/orchestration/src/secret-scan.test.ts -> packages/orchestration/src/secret-scan.test.ts`
- 1-file cycle: `packages/orchestration/src/tier2-compare-main.ts -> packages/orchestration/src/tier2-compare-main.ts`

## Hyperedges (group relationships)
- **Karpathy three-layer wiki architecture** — docs_research_pel_release_sources_pel_karpathy_llm_wiki_raw, docs_research_pel_release_sources_pel_karpathy_llm_wiki_synthesis, docs_research_pel_release_sources_pel_karpathy_llm_wiki_schema [EXTRACTED 1.00]
- **Six independent model profiles in one Pel host contract** — docs_research_pel_release_adapter_evidence_pel_host_adapter_contract, docs_research_pel_release_sources_models_openai_astra_gpt_6_astra_profile, docs_research_pel_release_sources_models_openai_sol_gpt_5_6_sol_profile, docs_research_pel_release_sources_models_claude_opus_claude_opus_5_profile, docs_research_pel_release_sources_models_claude_fable_claude_fable_5_1_profile, docs_research_pel_release_sources_models_grok_model_grok_4_6_profile, docs_research_pel_release_sources_models_gemini_model_gemini_3_8_flash_profile [INFERRED 0.85]

## Communities (1817 total, 723 thin omitted)

### Community 0 - "identifiers / quorum.test"
Cohesion: 0.03
Nodes (153): approvalValidationReason(), AuthorityBearingApprovalClass, authorityBearingApprovalClasses, authorizeCommitment(), Check, CommitmentContext, CommitmentDecision, CommitmentDenialReason (+145 more)

### Community 1 - "backend-boundary.test / fm-session-golden.test"
Cohesion: 0.03
Nodes (137): packageRoots, requiredFiles, runArchitectureIsolated(), File inventory: components/council/tests/architecture/workspace.test.ts, File inventory: packages/core/src/bounded-read.test.ts, File inventory: packages/graph-store/src/cli.test.ts, File inventory: packages/orchestration/src/appliance-doctor.test.ts, File inventory: packages/orchestration/src/fm-session-golden.test.ts (+129 more)

### Community 2 - "execution-terminal-policy / execution-ledger"
Cohesion: 0.04
Nodes (150): File inventory: packages/event-log/src/timestamp.ts, File inventory: packages/orchestration/src/execution-ledger.test.ts, File inventory: packages/orchestration/src/execution-ledger.ts, File inventory: packages/orchestration/src/execution-loop-closure.test.ts, File inventory: packages/orchestration/src/execution-terminal-policy.test.ts, File inventory: packages/orchestration/src/execution-terminal-policy.ts, decodeRunId(), daysInMonth() (+142 more)

### Community 3 - "preflight / preflight.test"
Cohesion: 0.04
Nodes (135): asStrictBoolean(), asStrictNonNegativeInteger(), asStrictString(), baseTerminal(), buildClaudeCanaryInvocation(), CLAUDE_FABLE_5_1_MODEL, ClaudeCanaryInvocationInput, ClaudeOuterWire (+127 more)

### Community 4 - "schema / architecture-manifest"
Cohesion: 0.05
Nodes (133): File inventory: packages/core/src/decode.test.ts, File inventory: packages/core/src/decode.ts, File inventory: packages/policy/src/admit.ts, File inventory: packages/policy/src/approval-delta.test.ts, File inventory: packages/policy/src/approval-delta.ts, File inventory: packages/policy/src/architecture-manifest.ts, File inventory: packages/policy/src/authority.ts, File inventory: packages/policy/src/cli.ts (+125 more)

### Community 5 - "services / platform"
Cohesion: 0.05
Nodes (126): File inventory: packages/launcher/src/capability.test.ts, File inventory: packages/launcher/src/capability.ts, File inventory: packages/launcher/src/cli.test.ts, File inventory: packages/launcher/src/cli.ts, File inventory: packages/launcher/src/heartbeat.test.ts, File inventory: packages/launcher/src/heartbeat.ts, File inventory: packages/launcher/src/index.ts, File inventory: packages/launcher/src/main.ts (+118 more)

### Community 6 - "effect-docs-url-inventory"
Cohesion: 0.01
Nodes (135): adoption_partners_md, blog_md, blog_the_one_weird_git_trick_that_makes_coding_agents_more_effect_ive_md, brand_assets_md, docs_md, docs_v3_additional_resources_coming_from_zio_md, docs_v3_additional_resources_effect_vs_fp_ts_md, docs_v3_additional_resources_effect_vs_neverthrow_md (+127 more)

### Community 7 - "execution-contract / execution-guard-cli"
Cohesion: 0.04
Nodes (129): File inventory: packages/orchestration/src/execution-contract.test.ts, File inventory: packages/orchestration/src/execution-contract.ts, File inventory: packages/orchestration/src/execution-guard-cli.test.ts, File inventory: packages/orchestration/src/execution-guard-cli.ts, File inventory: packages/orchestration/src/execution-guard-main.ts, canonicalFileSha256V2(), childBriefKeys, childContractKeys (+121 more)

### Community 8 - "test-helpers / r3-error-safety.test"
Cohesion: 0.05
Nodes (119): BundleVerificationError, components_council_packages_application_src_index_artifactdigestmismatch, components_council_packages_application_src_index_artifactlengthmismatch, components_council_packages_application_src_index_artifactmissing, components_council_packages_application_src_index_artifactreader, components_council_packages_application_src_index_artifactreaderror, components_council_packages_application_src_index_bundleverificationerror, components_council_packages_application_src_index_bundleverifier (+111 more)

### Community 9 - "release-coverage / release-coverage.test"
Cohesion: 0.05
Nodes (124): File inventory: packages/policy/src/release-coverage.test.ts, File inventory: packages/policy/src/release-coverage.ts, File inventory: packages/policy/src/release-program.test.ts, File inventory: packages/policy/src/release-program.ts, ALLOWED_WORKFLOWS, bootstrapKey(), bootstrapOwner(), BRIEF_KEYS (+116 more)

### Community 10 - "credential-profile / credential-profile-lane-cli"
Cohesion: 0.05
Nodes (121): File inventory: packages/orchestration/src/credential-profile-lane-cli.test.ts, File inventory: packages/orchestration/src/credential-profile-lane-cli.ts, File inventory: packages/orchestration/src/credential-profile-lane-main.ts, File inventory: packages/orchestration/src/credential-profile-main.ts, File inventory: packages/orchestration/src/credential-profile.test.ts, File inventory: packages/orchestration/src/credential-profile.ts, absoluteConfigRoot(), authorityOpenFlags() (+113 more)

### Community 11 - "release-authority / release-authority.test"
Cohesion: 0.05
Nodes (124): File inventory: packages/policy/src/release-authority.test.ts, File inventory: packages/policy/src/release-authority.ts, isSha256Hex(), ApprovedOpenSpecManifestBuildResultV1, ApprovedOpenSpecManifestV1, ApprovedOpenSpecManifestValidationResultV1, AUDIT_VERDICTS, BLOCKING_AUDIT_VERDICTS (+116 more)

### Community 12 - "install-verify.test / install-verify-fs"
Cohesion: 0.05
Nodes (110): File inventory: packages/policy/src/architecture-main.ts, File inventory: packages/policy/src/install-plugin-drift.ts, File inventory: packages/policy/src/install-verify-cli.ts, File inventory: packages/policy/src/install-verify-exports.ts, File inventory: packages/policy/src/install-verify-fs.ts, File inventory: packages/policy/src/install-verify-schema.ts, File inventory: packages/policy/src/install-verify.test.ts, File inventory: packages/policy/src/install-verify.ts (+102 more)

### Community 13 - "vendor-preflight-contract / vendor-preflight-cli"
Cohesion: 0.05
Nodes (105): File inventory: packages/orchestration/src/vendor-preflight-cli.test.ts, File inventory: packages/orchestration/src/vendor-preflight-cli.ts, File inventory: packages/orchestration/src/vendor-preflight-contract.test.ts, File inventory: packages/orchestration/src/vendor-preflight-contract.ts, File inventory: packages/orchestration/src/vendor-preflight-store.ts, File inventory: packages/orchestration/src/vendor-preflight-tool-check.test.ts, File inventory: packages/orchestration/src/vendor-preflight-tool-check.ts, PathLookup (+97 more)

### Community 14 - "bugeventlog"
Cohesion: 0.04
Nodes (108): 2026-07-16 — 4-way parallel Grok fan-out appears to serialize at the CLI, 2026-07-16 — audit wall-clock serializes every merge (27 min full, 24 min scoped), 2026-07-16 — background-and-stop is a recurring cross-model attractor, not a one-off, 2026-07-16 — file-mtime stall watchdogs false-alarm on read-heavy and completed lanes, 2026-07-16 — finisher lane's cwd silently reset to a DIFFERENT lane's worktree, 2026-07-16 — Grok CLI 600s subprocess timeout swallowed the worker's closing message, 2026-07-16 — implementer lane died to a mid-response API server error with zero progress signal, 2026-07-16 — implementer wrapper stopped while its CLI subprocess kept running (+100 more)

### Community 15 - "tracked-delete.test / tracked-delete"
Cohesion: 0.06
Nodes (97): File inventory: packages/policy/src/cli.test.ts, File inventory: packages/policy/src/git-env.test.ts, File inventory: packages/policy/src/git-env.ts, File inventory: packages/policy/src/live-services.ts, File inventory: packages/policy/src/services.ts, File inventory: packages/policy/src/tracked-delete.test.ts, File inventory: packages/policy/src/tracked-delete.ts, A_TXT (+89 more)

### Community 16 - "secret-scan / secret-scan.test"
Cohesion: 0.06
Nodes (98): File inventory: packages/orchestration/src/secret-scan-main.ts, File inventory: packages/orchestration/src/secret-scan.test.ts, File inventory: packages/orchestration/src/secret-scan.ts, BoundDir, closeDirQuiet(), closeQuiet(), Counters, DEFAULT_SECRET_SCAN_BOUNDS (+90 more)

### Community 17 - "entities / import-remap"
Cohesion: 0.07
Nodes (92): File inventory: packages/session-store/src/entities.ts, File inventory: packages/session-store/src/import-remap.test.ts, File inventory: packages/session-store/src/import-remap.ts, File inventory: packages/session-store/src/index.ts, File inventory: packages/session-store/src/integrity.ts, File inventory: packages/session-store/src/sidecar-v1.test.ts, File inventory: packages/session-store/src/sidecar-v1.ts, File inventory: packages/session-store/src/sidecar.ts (+84 more)

### Community 18 - "spec-correctness-admission.test / spec-correctness-admission"
Cohesion: 0.05
Nodes (86): components_council_packages_application_src_index_artifactlimitexceeded, components_council_packages_application_src_index_artifactreaderservice, asReviewAttemptInput(), bindEvaluation(), buildCompletedResult(), closedSuccessfulTerminalCandidate(), compareUtf8ByteOrder(), computeSpecSetSha256() (+78 more)

### Community 19 - "release-coverage-cli.test"
Cohesion: 0.05
Nodes (91): File inventory: packages/orchestration/src/release-coverage-cli.test.ts, assertCanonicalResult(), assertGitOk(), assertNoAlternatePathPathextOrPrefixedKeys(), assertNoEscapeReads(), assertSanitized(), assertUnchangedSnapshot(), assertUsageFailure() (+83 more)

### Community 20 - "appliance-lock / rootless-engine-qualification"
Cohesion: 0.06
Nodes (85): File inventory: packages/orchestration/src/appliance-doctor-main.ts, File inventory: packages/orchestration/src/appliance-doctor.ts, File inventory: packages/orchestration/src/appliance-lock.test.ts, File inventory: packages/orchestration/src/appliance-lock.ts, File inventory: packages/orchestration/src/rootless-engine-qualification.ts, File inventory: scripts/appliance-lock.ts, ApplianceDoctorCliIo, ApplianceDoctorObservationV1 (+77 more)

### Community 21 - "supervisor / resume-safety-services"
Cohesion: 0.06
Nodes (85): File inventory: packages/orchestration/src/resume-safety-services.test.ts, File inventory: packages/orchestration/src/resume-safety-services.ts, File inventory: packages/orchestration/src/supervisor-cli.test.ts, File inventory: packages/orchestration/src/supervisor-cli.ts, File inventory: packages/orchestration/src/supervisor.test.ts, File inventory: packages/orchestration/src/supervisor.ts, makeStubQueueSubmitter(), classifyResumeLock() (+77 more)

### Community 22 - "contract-suite / port"
Cohesion: 0.06
Nodes (42): File inventory: packages/session-store/src/contract-suite.ts, File inventory: packages/session-store/src/contract.test.ts, File inventory: packages/session-store/src/port.ts, ALL_CASES, assert(), assertRejects(), assertViolation(), baseWithSession() (+34 more)

### Community 23 - "queue-admission / queue-services"
Cohesion: 0.07
Nodes (81): File inventory: packages/orchestration/src/queue-admission.test.ts, File inventory: packages/orchestration/src/queue-admission.ts, File inventory: packages/orchestration/src/queue-services.ts, File inventory: packages/orchestration/src/vendor-preflight-live.test.ts, ADD_USAGE, cmdAdd(), cmdEnsure(), cmdKill() (+73 more)

### Community 24 - "tool-check-run / tool-check-cli"
Cohesion: 0.07
Nodes (79): File inventory: packages/orchestration/src/tool-check-cli.test.ts, File inventory: packages/orchestration/src/tool-check-cli.ts, File inventory: packages/orchestration/src/tool-check-platform.ts, File inventory: packages/orchestration/src/tool-check-report.test.ts, File inventory: packages/orchestration/src/tool-check-report.ts, File inventory: packages/orchestration/src/tool-check-run.test.ts, File inventory: packages/orchestration/src/tool-check-run.ts, EXIT_INVALID_ARGUMENTS (+71 more)

### Community 25 - "prompt-preflight / prompt-preflight.test"
Cohesion: 0.06
Nodes (83): components_council_packages_schema_src_index_completedabstentionv1, components_council_packages_schema_src_index_completedinvalidresponsev1, components_council_packages_schema_src_index_completedverdictv1, components_council_packages_schema_src_index_councilclosureoutcome, components_council_packages_schema_src_index_finalapprovedresponsev1, components_council_packages_schema_src_index_finalchangesrequestedresponsev1, components_council_packages_schema_src_index_readyreviewtokenv1, components_council_packages_schema_src_index_reviewattemptclassificationv1 (+75 more)

### Community 26 - "preflight-program / run-preflight.test"
Cohesion: 0.06
Nodes (81): CanaryMaterializerError, ProviderVersionProbeError, components_council_packages_application_src_index_canarymaterializer, components_council_packages_application_src_index_canarymaterializererror, components_council_packages_application_src_index_canarymaterializerservice, components_council_packages_application_src_index_preflightidentityerror, components_council_packages_application_src_index_preflightidentitysource, components_council_packages_application_src_index_preflightidentitysourceservice (+73 more)

### Community 27 - "round-contract / round-reducer"
Cohesion: 0.08
Nodes (81): File inventory: packages/orchestration/src/round-contract.test.ts, File inventory: packages/orchestration/src/round-contract.ts, File inventory: packages/orchestration/src/round-reducer.ts, isAttemptFailure(), ATTEMPT_IDENTITY_KEYS, attemptIdentitiesEqual(), Branded, CheckpointIdentityV1 (+73 more)

### Community 28 - "graphify-qualification / graphify-qualification-main"
Cohesion: 0.08
Nodes (80): File inventory: packages/orchestration/src/graphify-qualification-main.ts, File inventory: packages/orchestration/src/graphify-qualification.test.ts, File inventory: packages/orchestration/src/graphify-qualification.ts, acquireGraphifyPublicationLockV1(), canonicalCompare(), deriveRenames(), DIAGNOSTIC_KEYS, diagnosticsValid() (+72 more)

### Community 29 - "schema-lowering / r3-closed-json.test"
Cohesion: 0.08
Nodes (75): components_council_packages_application_src_index_canonicaljsonbytes, components_council_packages_application_src_index_encodeutf8, components_council_packages_application_src_index_schemaloweringerror, components_council_packages_application_src_index_sortjsonkeys, components_council_packages_application_src_index_stringifycanonicaljson, components_council_packages_application_src_index_validatecanonicalschema, components_council_packages_application_src_index_verifycombinedconstraints, components_council_packages_application_src_index_verifyloweringindependently (+67 more)

### Community 30 - "gemini-tools"
Cohesion: 0.05
Nodes (82): Best practices, Compositional function calling, Create Chart, Example, Function calling modes, Function calling with Structured output, Function calling with the Gemini API, Function calling with thinking models (+74 more)

### Community 31 - "credential-profile-preflight / credential-profile-lane"
Cohesion: 0.08
Nodes (77): File inventory: packages/orchestration/src/credential-profile-lane.test.ts, File inventory: packages/orchestration/src/credential-profile-lane.ts, File inventory: packages/orchestration/src/credential-profile-preflight.test.ts, File inventory: packages/orchestration/src/credential-profile-preflight.ts, admitCredentialProfileLane(), CREDENTIAL_PROFILE_LANE_REFUSAL_REASONS, CredentialProfileLaneRefusalReason, CredentialProfileLaneResult (+69 more)

### Community 32 - "fm-session-main / write-atomic-writer"
Cohesion: 0.07
Nodes (76): File inventory: packages/orchestration/src/fm-session-main.ts, File inventory: packages/orchestration/src/write-atomic-writer.ts, assessSidecarReplace(), BOOLEAN_ARGS, buildFreshnessFromStore(), buildRecoveryFromStore(), CliRefusal, currentGitProjectIdentity() (+68 more)

### Community 33 - "release-coverage-cli"
Cohesion: 0.07
Nodes (79): File inventory: packages/orchestration/src/release-coverage-cli.ts, baseLiveReleaseCoverageCliServices, boundedReadOpenFlagsLive(), BRIEF_SCHEMA, buildTrustedGitEnvironment(), buildTrustedOpenSpecEnvironment(), callPort(), capturedStderrText() (+71 more)

### Community 34 - "durable-runtime"
Cohesion: 0.05
Nodes (78): Adapter contract, Auth doctor and quorum, Boundary rule, Canonical event, state, and error models, Capability: `auth-and-quorum-doctor`, Capability: `budget-retry-idempotency`, Capability: `durable-run-lifecycle`, Capability: `effect-orchestration` (+70 more)

### Community 35 - "claude-fable / claude-effort"
Cohesion: 0.05
Nodes (70): docs_en_about_claude_model_deprecations_md, docs_en_about_claude_models_choosing_a_model_md, docs_en_about_claude_models_model_ids_and_versions_md, docs_en_about_claude_pricing_md, docs_en_agents_and_tools_tool_use_browser_use_tool_md, docs_en_agents_and_tools_tool_use_code_execution_tool_md, docs_en_agents_and_tools_tool_use_computer_use_tool_md, docs_en_agents_and_tools_tool_use_fine_grained_tool_streaming_md (+62 more)

### Community 36 - "errors / prompt-preflight"
Cohesion: 0.07
Nodes (73): AceParseError, AceSemanticError, ArtifactDigestMismatch, ArtifactEncodingInvalid, ArtifactLengthMismatch, ArtifactLimitExceeded, ArtifactMissing, ArtifactReadError (+65 more)

### Community 37 - "spec"
Cohesion: 0.05
Nodes (76): File inventory: openspec/changes/evidence-contracts/specs/evidence-contracts/spec.md, ADDED Requirements, Requirement: A path-level status digest is a corroborating signal with two declared blind spots, Requirement: A planted-write positive control gates every evidence verdict, Requirement: A round is never dispatched into an already-satisfied contract, Requirement: Artifact-based lane success predicate, Requirement: Audit-lane evidence contract, Requirement: Co-requisite ownership boundaries (+68 more)

### Community 38 - "resume-worktree-restore / resume-queue-execution"
Cohesion: 0.07
Nodes (72): File inventory: packages/orchestration/src/resume-queue-execution.test.ts, File inventory: packages/orchestration/src/resume-queue-execution.ts, File inventory: packages/orchestration/src/resume-worktree-restore.test.ts, File inventory: packages/orchestration/src/resume-worktree-restore.ts, ProcessExec, Branded, buildLaneRunRoundVector(), ExecBranded (+64 more)

### Community 39 - "codex-app-server"
Cohesion: 0.05
Nodes (75): 10) Workspace messages (ChatGPT), 1) Check auth state, 2) Log in with an API key, 3) Log in with ChatGPT (browser flow), 3b) Log in with ChatGPT (device-code flow), 3c) Log in with externally managed ChatGPT tokens (`chatgptAuthTokens`), 4) Cancel a ChatGPT login, 5) Logout (+67 more)

### Community 40 - "admit.test / approval-commit.integration.test"
Cohesion: 0.06
Nodes (67): File inventory: packages/policy/src/admit.test.ts, File inventory: packages/policy/src/approval-commit.integration.test.ts, File inventory: packages/policy/src/authority.test.ts, File inventory: packages/policy/src/register.test.ts, File inventory: packages/policy/src/register.ts, File inventory: packages/policy/src/relocate.test.ts, File inventory: scripts/verify-register-doc.ts, canonicalize() (+59 more)

### Community 41 - "spec-correctness-program.test / ready-token.test"
Cohesion: 0.06
Nodes (69): components_council_packages_application_src_index_issuereadyreviewtoken, components_council_packages_application_src_index_readytokenissuanceerror, artifactDigest, artifactId, baseCanary(), basePrompt(), canaryExpiresAt, canarySchemaHash (+61 more)

### Community 42 - "spec-correctness-cli.test / spec-correctness-cli"
Cohesion: 0.06
Nodes (69): encodeResultLine(), encodeUtf8Bounded(), MAX_STDERR_BYTES, MAX_STDIN_BYTES, MAX_STDOUT_BYTES, nodeIo, readStdinBounded(), runSpecCorrectnessCli() (+61 more)

### Community 43 - "vendor-preflight-manifest / build-runtime"
Cohesion: 0.07
Nodes (64): File inventory: components/council/scripts/build-runtime.ts, File inventory: packages/orchestration/src/foreman-setup-main.ts, File inventory: packages/orchestration/src/tool-check-main.ts, File inventory: packages/orchestration/src/vendor-preflight-embedded.ts, File inventory: packages/orchestration/src/vendor-preflight-main.ts, File inventory: packages/orchestration/src/vendor-preflight-manifest.ts, File inventory: scripts/build-runtime.ts, armStream() (+56 more)

### Community 44 - "files-only / entities"
Cohesion: 0.11
Nodes (36): File inventory: packages/session-store/src/files-only.ts, SessionSnapshot, acquireWriterLock(), assertReceiptCounterMintable(), claimsDir(), cloneQueue(), copyEntry(), copyRecord() (+28 more)

### Community 45 - "spec-correctness-admission.test / spec-correctness-admission"
Cohesion: 0.07
Nodes (66): admissionResultFreeTextIsSecretSafe(), adviceKindOfVerdict(), BoundSpecCorrectnessEvaluationV1, completedEvaluationBindsClassificationResponse(), containsUnsafePublicFreeText(), evaluationOutcome(), GitTreeSha, isContentAddressOrDigest() (+58 more)

### Community 46 - "posix / posix-bootstrap"
Cohesion: 0.08
Nodes (57): File inventory: launcher/src/launch.ts, File inventory: launcher/src/posix-bootstrap.ts, File inventory: launcher/src/posix.ts, File inventory: launcher/src/supervise.ts, File inventory: launcher/src/win/jobobject.ts, File inventory: launcher/tests/fixtures/subreaper-probe.ts, File inventory: launcher/tests/jobobject.test.ts, File inventory: launcher/tests/posix-bootstrap.test.ts (+49 more)

### Community 47 - "verify-runtime"
Cohesion: 0.06
Nodes (67): File inventory: scripts/verify-runtime.ts, bytesEqual(), fail(), git(), root, tmp, tmpA, tmpB (+59 more)

### Community 48 - "foreman-setup / foreman-setup.test"
Cohesion: 0.08
Nodes (65): File inventory: packages/orchestration/src/foreman-setup.test.ts, File inventory: packages/orchestration/src/foreman-setup.ts, authInstruction(), captureText(), cleanupBuild(), closeQuiet(), DirIdentity, ensureExternalStateRoot() (+57 more)

### Community 49 - "design / ROADMAP"
Cohesion: 0.06
Nodes (60): Council Roadmap, Deferred beyond v1, Phase 0 — Approved architecture, Phase 1 — Schemas and pure domain, Phase 2 — Effect application shell, Phase 3 — Durable local runtime, Phase 4 — Process ownership and first provider, Phase 5 — Four-provider participation (+52 more)

### Community 50 - "server"
Cohesion: 0.08
Nodes (63): File inventory: skills/superpowers/skills/brainstorming/scripts/server.cjs, ref_child_process, ref_http, bootstrapPage(), brandMarkup(), broadcast(), browserLauncherForPlatform(), chmodOwnerOnly() (+55 more)

### Community 51 - "claude-cli / claude-headless"
Cohesion: 0.04
Nodes (61): docs_en_advisor_md, docs_en_agent_sdk_cost_tracking_md, docs_en_agent_sdk_mcp_md, docs_en_agent_sdk_modifying_system_prompts_md, docs_en_agent_sdk_overview_md, docs_en_agent_sdk_python_md, docs_en_agent_sdk_quickstart_md, docs_en_agent_sdk_streaming_output_md (+53 more)

### Community 52 - "N4-symbolic-verification"
Cohesion: 0.06
Nodes (62): 0. The one-paragraph answer, 10. What N4 recommends, in one place, 11. Handoffs to sibling lanes, 1. Sources fetched, 2.1 The comparison, 2.2 Why SHACL wins for us specifically, 2.3 Where SHACL Core runs out, 2. Validation technology comparison (+54 more)

### Community 53 - "run-journal"
Cohesion: 0.10
Nodes (62): File inventory: packages/event-log/src/run-journal.ts, acquireLockSync(), allocateSync(), appendSync(), attemptHasDurableTerminal(), attemptLockPath(), attemptPath(), Branded (+54 more)

### Community 54 - "preflight-cli.test / preflight-cli"
Cohesion: 0.07
Nodes (56): encodeUtf8Bounded(), MAX_STDERR_BYTES, MAX_STDIN_BYTES, nodeIo, PreflightCliIo, readStdinBounded(), runPreflightCli(), STATIC_PARSE_FAILURE (+48 more)

### Community 55 - "claude-cache"
Cohesion: 0.07
Nodes (60): 1-hour cache duration, Automatic caching, Best practices for effective caching, Cache limitations, Cache storage and sharing, Caching strategies and considerations, Caching tool definitions, Caching with thinking blocks (+52 more)

### Community 56 - "files-only / failures"
Cohesion: 0.13
Nodes (55): File inventory: packages/graph-store/src/files-only.ts, graphStoreFailure, isGraphStoreFailure(), throwFailure(), acquireLockEffect(), acquireLockSync(), assertUnderRoot(), atomicWriteFile() (+47 more)

### Community 57 - "anthropic-best-practices"
Cohesion: 0.07
Nodes (59): File inventory: skills/superpowers/skills/writing-skills/anthropic-best-practices.md, Advanced: Skills with executable code, [Analysis Title], [Analysis Title], Anti-patterns to avoid, Avoid assuming tools are installed, Avoid deeply nested references, Avoid offering too many options (+51 more)

### Community 58 - "spec"
Cohesion: 0.07
Nodes (58): File inventory: openspec/changes/v050-release-program/specs/release-program/spec.md, ADDED Requirements, Requirement: Baseline identity is recorded, Requirement: Bootstrap under the root contract, Requirement: Conflicting derived data is marked, Requirement: Coverage register completeness, Requirement: Coverage register dispositions, Requirement: Deferred packages stay frozen (+50 more)

### Community 59 - "README / README.opencode"
Cohesion: 0.06
Nodes (56): File inventory: skills/superpowers/README.md, File inventory: skills/superpowers/docs/README.kimi.md, File inventory: skills/superpowers/docs/README.opencode.md, Direct GitHub install used an old release, How It Works, Installation, Plugin not loading, Skills not triggering (+48 more)

### Community 60 - "release-policy / queue-cli"
Cohesion: 0.08
Nodes (52): File inventory: packages/orchestration/src/queue-cli.test.ts, File inventory: packages/orchestration/src/queue-cli.ts, File inventory: packages/orchestration/src/queue-main.ts, File inventory: packages/orchestration/src/release-policy-main.ts, File inventory: packages/orchestration/src/release-policy.test.ts, File inventory: packages/orchestration/src/release-policy.ts, cmdAddGuarded(), ParsedCommand (+44 more)

### Community 61 - "common / wt-cleanup"
Cohesion: 0.10
Nodes (46): File inventory: skills/foreman/scripts/checks-run.sh, File inventory: skills/foreman/scripts/evidence-collect.sh, File inventory: skills/foreman/scripts/foreman-cleanup.sh, File inventory: skills/foreman/scripts/foreman-fit-report.sh, File inventory: skills/foreman/scripts/gate-eval.sh, File inventory: skills/foreman/scripts/git-guards.sh, File inventory: skills/foreman/scripts/lib/common.sh, File inventory: skills/foreman/scripts/pr-open.sh (+38 more)

### Community 62 - "spec"
Cohesion: 0.07
Nodes (56): File inventory: openspec/changes/workflow-weight-reduction/specs/workflow-weight/spec.md, ADDED Requirements, Requirement: Audit pipelined after the checks receipt, Requirement: Bound change descriptor, Requirement: Bounded automatic rework, Requirement: Doctrine core, Requirement: Full gate feasibility measured first, Requirement: Full tier before landing (+48 more)

### Community 63 - "effect-domain"
Cohesion: 0.07
Nodes (55): Acceptance tests for the future implementation, Adapter conformance tests, Aggregate state, Approval and capability lifecycle, Authoritative and observational streams, Branded values and versioned contracts, Budget lifecycle, Capability: `bounded-deliberation` (+47 more)

### Community 64 - "round-transaction / round-live-services"
Cohesion: 0.10
Nodes (50): File inventory: packages/orchestration/src/report-freshness.ts, File inventory: packages/orchestration/src/round-live-services.ts, File inventory: packages/orchestration/src/round-transaction.test.ts, File inventory: packages/orchestration/src/round-transaction.ts, decideRoundOutcome(), incomplete(), isPresentNonempty(), isReportFresh() (+42 more)

### Community 65 - "sqlite-store / failures"
Cohesion: 0.13
Nodes (11): File inventory: packages/session-store/src/sqlite-store.ts, raise(), isCurrentOutboxSchema(), isLegacyOutboxSchema(), maxInternalNumericReceipt(), OutboxColumnInfo, outboxColumnNames(), parseCanonicalNextReceipt() (+3 more)

### Community 66 - "ace / ace.test"
Cohesion: 0.10
Nodes (52): AceDeterminedObject, AceDeterminer, AceDiagnostic, AceDocument, AceLexicon, AceLexiconVerb, AceParseResult, AceSentence (+44 more)

### Community 67 - "spec"
Cohesion: 0.07
Nodes (52): File inventory: openspec/changes/three-outcome-verdicts/specs/audit-verdict/spec.md, ADDED Requirements, MODIFIED Requirements, Requirement: a gate decision cannot be invalidated between evaluation and merge, Requirement: an audit that produces no judgment is recorded as UNVERIFIED, Requirement: every audit writes a verdict artifact, Requirement: every gate input is bound to the diff and to the evaluated tree, Requirement: every verdict carries provenance and an evidence reference (+44 more)

### Community 68 - "release-admission-cli / release-admission-cli.test"
Cohesion: 0.09
Nodes (50): File inventory: packages/policy/src/release-admission-cli.test.ts, File inventory: packages/policy/src/release-admission-cli.ts, File inventory: packages/policy/src/release-admission-main.ts, ACTIONS, closedGitEnvironment(), commandTail(), compareUtf8(), encoder (+42 more)

### Community 69 - "release-admission.test / release-admission"
Cohesion: 0.09
Nodes (51): File inventory: packages/policy/src/release-admission.test.ts, File inventory: packages/policy/src/release-admission.ts, canonicalFileSha256(), CheckedEvidence, checkEvidence(), compareUtf8(), designReceipt(), encoder (+43 more)

### Community 70 - "outbox.test / outbox"
Cohesion: 0.08
Nodes (27): File inventory: packages/session-store/src/outbox.test.ts, File inventory: packages/session-store/src/outbox.ts, defensiveRecords(), DrainOptions, drainOutbox(), DrainResult, isPositiveSafeIntInRange(), outboxDrainFailure (+19 more)

### Community 71 - "R7-graphify-foundation"
Cohesion: 0.08
Nodes (51): 0. Executive summary, 10. Extension points, 11. Verdict for Foreman v0.2.9, 12. Open questions / unreachable pages, 13. Appendix — full graphify.net crawl manifest (153/153 OK), 1.1 Local installation (VERIFIED-code), 1.2 Upstream (VERIFIED-docs), 1.3 graphify.net — full crawl (+43 more)

### Community 72 - "evidence-rules / shell-conventions"
Cohesion: 0.07
Nodes (47): home_charl_fm_wt_foreman_dsl_release_plugins_foreman_qa_skills_foreman_qa_references_durable_enabled_disabled_for_independent_proof_md, File inventory: plugins/foreman-qa/skills/foreman-code-quality/references/shell-conventions.md, File inventory: plugins/foreman-qa/skills/foreman-qa/SKILL.md, File inventory: plugins/foreman-qa/skills/foreman-qa/references/evidence-rules.md, File inventory: plugins/foreman-qa/skills/foreman-qa/references/failure-catalogue.md, A missing tool on a hosted runner may be a PATH gap, not an absent package, Check the index, not only the working tree, Disable scoping (+39 more)

### Community 73 - "replay / replay.test"
Cohesion: 0.10
Nodes (45): File inventory: packages/event-log/src/bounds.ts, File inventory: packages/event-log/src/replay.test.ts, File inventory: packages/event-log/src/replay.ts, File inventory: packages/event-log/src/stored-event.test.ts, File inventory: packages/event-log/src/stored-event.ts, File inventory: packages/event-log/src/structure.ts, EVENT_LOG_SCHEMA_VERSION, MAX_EVENT_JSON_NODES (+37 more)

### Community 74 - "tier2-shared / tier2-compare-main"
Cohesion: 0.15
Nodes (40): File inventory: packages/orchestration/src/tier2-collect-main.ts, File inventory: packages/orchestration/src/tier2-compare-main.ts, File inventory: packages/orchestration/src/tier2-shared.ts, collect(), invoke_adapter(), main(), pinned_identity(), bootstrap_ci() (+32 more)

### Community 75 - "gemini-model / gemini-interactions"
Cohesion: 0.06
Nodes (43): api_interactions_api_md, api_rest_v1beta_cachedcontents_md, Thought signatures, gemini_api_docs_audio_md, gemini_api_docs_background_execution_md, gemini_api_docs_batch_api_md, gemini_api_docs_caching_md, gemini_api_docs_code_execution_md (+35 more)

### Community 76 - "2026-08-08-tool-check-gates"
Cohesion: 0.08
Nodes (49): Fixture pair, Fixture pair, Fixture pair, Fixture pair, Fixture pair, Fixture pair, Fixture pair, Fixture pair (+41 more)

### Community 77 - "2026-08-02-council-v030-localization"
Cohesion: 0.08
Nodes (49): Confirmed Baseline, Constraints, Constraints, Constraints, Constraints, Constraints, Constraints, Constraints (+41 more)

### Community 78 - "contract-suite / contract.test"
Cohesion: 0.15
Nodes (37): File inventory: packages/graph-store/src/contract-suite.ts, File inventory: packages/graph-store/src/contract.test.ts, ALL_CASES, assert(), CASE_CATEGORY, caseDependsOnCycleRejected(), caseExpectedEmptyTrueNegative(), caseLineageAttemptsFromRound() (+29 more)

### Community 79 - "session-sqlite-bootstrap / session-sqlite-bootstrap.test"
Cohesion: 0.11
Nodes (44): File inventory: packages/orchestration/src/session-paths.ts, File inventory: packages/orchestration/src/session-sqlite-bootstrap.test.ts, File inventory: packages/orchestration/src/session-sqlite-bootstrap.ts, File inventory: packages/session-store/src/sqlite-rebuild.ts, pathsAlias(), sidecarPathFor(), allocateCorruptBackupPath(), BACKUP_SIDECARS (+36 more)

### Community 80 - "check-schema-structure / analyze-token-usage"
Cohesion: 0.09
Nodes (41): argparse, collections, Pin vendor model documentation locally via Scrapling. Output:…, File inventory: docs/reference/models/fetch-model-docs.py, File inventory: openspec/changes/archive/2026-07-30-terminusdb-withdrawn-schema/scripts/check-schema-structure.py, File inventory: skills/scrapling/templates/basic_fetch.py, File inventory: skills/scrapling/templates/session_login.py, File inventory: skills/scrapling/templates/stealth_cloudflare.py (+33 more)

### Community 81 - "gemini-cli"
Cohesion: 0.08
Nodes (47): docs_cli_enterprise_md, docs_cli_session_management_md, docs_cli_system_prompt_md, docs_cli_telemetry_md, docs_get_started_authentication_md, docs_reference_commands_md, docs_reference_memport_md, `admin` (+39 more)

### Community 82 - "N1-neurosymbolic-foundations"
Cohesion: 0.08
Nodes (47): 10. Bottom line, 1.1 Taxonomy and framing, 1.2 Surveys and reviews, 1.3 Integration patterns (LLM → solver), 1.4 Grounding, canonicalisation, entity resolution, 1.5 Negative results and critiques, 1. Sources fetched, 2.1 Kautz's six types (+39 more)

### Community 83 - "N3-llm-graph-consumption"
Cohesion: 0.08
Nodes (47): 0. Executive answer, 10.1 Against "structured graph context always beats plain text", 10.2 Against "LLMs can reason over graphs", 10.3 Against "more prompting technique is better", 10.4 Against "graph retrieval machinery pays for itself", 10.5 Against "long context solves the budget problem", 10.6 Against "citations mean the model used the evidence", 10.7 Against format dogma (+39 more)

### Community 84 - "R5-internal-attachment-map"
Cohesion: 0.08
Nodes (47): 1.1 Repo top level, 1.2 `skills/foreman/scripts/lib/` — 7 shared libraries, 1.3 `skills/foreman/scripts/` — 25 executables, 1.4 The real call graph of a lane round, 1. Full surface inventory + real call graph, 2.1 Storage layout, 2.2 Frozen top-level record shape, 2.3 The complete event-type vocabulary (every `el_emit` call site) (+39 more)

### Community 85 - "spec"
Cohesion: 0.08
Nodes (47): File inventory: openspec/changes/test-infrastructure-hardening/specs/test-harness/spec.md, ADDED Requirements, MODIFIED Requirements, Requirement: a check is trusted only after it has been observed failing, Requirement: a rate the harness reports with a zero denominator is uncomputable, never zero and never a pass, Requirement: a result that would change a release decision is corroborated independently, Requirement: a slice regression fails the run regardless of the aggregate, Requirement: a success predicate binds to an artifact and its content (+39 more)

### Community 86 - "spec"
Cohesion: 0.08
Nodes (47): File inventory: openspec/changes/v030-release-program/specs/release-program/spec.md, ADDED Requirements, Requirement: actionable dissent cannot be overridden, Requirement: all new implementation uses Node.js TypeScript, Requirement: cleanup is logged before destruction, Requirement: Effect owns fallible runtime behavior, Requirement: graph-project belongs to knowledge, Requirement: release evidence uses one exact candidate (+39 more)

### Community 87 - "graph-context / graph-context.test"
Cohesion: 0.10
Nodes (43): File inventory: packages/core/src/sha256.test.ts, File inventory: packages/core/src/sha256.ts, File inventory: packages/orchestration/src/graph-context-main.ts, File inventory: packages/orchestration/src/graph-context.test.ts, File inventory: packages/orchestration/src/graph-context.ts, sha256Hex(), AUDITOR_RELATIONS, boundedString() (+35 more)

### Community 88 - "vendor-preflight / vendor-preflight-live"
Cohesion: 0.11
Nodes (44): File inventory: packages/orchestration/src/vendor-preflight-live.ts, File inventory: packages/orchestration/src/vendor-preflight.test.ts, File inventory: packages/orchestration/src/vendor-preflight.ts, AuthClassification, buildDiscoveredRecord(), buildMissingRecord(), classifyAuthForVendor(), classifyClaudeAuth() (+36 more)

### Community 89 - "review-admission / review-admission.test"
Cohesion: 0.10
Nodes (44): attemptFailure(), classifyReviewAttempt(), completedInvalidResponse(), evidenceGapsValid(), expectedArtifactSet(), findingsValid(), hostArtifactPreconditionsHold(), InvalidReviewResponseReason (+36 more)

### Community 90 - "R3-vendor-adapters"
Cohesion: 0.08
Nodes (46): 0. Headline: the recommended adapter interface (read this first), 1.10 Auth modes and this host's state, 1.11 Models, 1.12 MCP, skills, hooks, extensions, ACP, 1.13 Concurrency behaviour, 1.1 Non-interactive invocation, 1.2 Output formats and structured output, 1.3 Exit codes — documented set is incomplete and partly wrong (+38 more)

### Community 91 - "spec"
Cohesion: 0.08
Nodes (46): File inventory: openspec/changes/lock-primitive-hardening/specs/locking/spec.md, ADDED Requirements, MODIFIED Requirements, Requirement: a mechanism is selected only on a trusted, current verdict for that mechanism and that filesystem class, Requirement: a non-atomic mkdir is detected, never assumed away, Requirement: an untrusted mechanism is a stated platform consequence, not a silent lockout, Requirement: compaction never discards a concurrently appended event, Requirement: every foreman lock has a named, owner-aware reclamation path (+38 more)

### Community 92 - "canonical-json / failures"
Cohesion: 0.14
Nodes (37): File inventory: packages/core/src/bounded-read.ts, File inventory: packages/core/src/canonical-json.test.ts, File inventory: packages/core/src/canonical-json.ts, File inventory: packages/core/src/failures.ts, File inventory: packages/core/src/index.ts, File inventory: packages/core/src/utf8.test.ts, File inventory: packages/core/src/utf8.ts, File inventory: packages/policy/src/architecture-delta.test.ts (+29 more)

### Community 93 - "process-runner / process-runner.test"
Cohesion: 0.10
Nodes (39): ProviderProcessError, components_council_packages_application_src_index_boundedspool, components_council_packages_application_src_index_providerprocessrunnerservice, BoundedSpool, ProviderProcessRunnerService, BoundedStreamCollector, closeStdin(), collectHomePaths() (+31 more)

### Community 94 - "gemini-text"
Cohesion: 0.09
Nodes (46): Java, Java, Java, Java, Java, Java, Java, Java (+38 more)

### Community 95 - "PM-acceptance-criteria"
Cohesion: 0.09
Nodes (45): 1.1 The floor — these are blockers, and none of them is about the graph, 1.2 The telemetry precondition — this is the criterion the release turns on, 1.3 Multi-vendor, 1.4 Workflow, 1.5 Graph plane — conditional criteria, 1.6 Honesty criteria, 1. Release-level acceptance criteria, 2. Anti-criteria — things that must NOT be true (+37 more)

### Community 96 - "spec"
Cohesion: 0.09
Nodes (45): File inventory: openspec/changes/audit-groundedness-gate/specs/gate/spec.md, ADDED Requirements, Requirement: a check with a missing input is silent and counted, Requirement: audit output is checked for internal coherence, Requirement: cross-vendor separation is asserted against what actually ran, Requirement: every check ships non-blocking and is promoted by measurement, Requirement: evidence sufficiency is advisory in this release, Requirement: findings that cite impossible lines are rejected (+37 more)

### Community 97 - "attempt / failures"
Cohesion: 0.14
Nodes (39): File inventory: packages/event-log/src/attempt.test.ts, File inventory: packages/event-log/src/attempt.ts, File inventory: packages/event-log/src/cursor.test.ts, File inventory: packages/event-log/src/cursor.ts, File inventory: packages/event-log/src/failures.ts, File inventory: packages/event-log/src/index.ts, File inventory: packages/orchestration/src/report-freshness.test.ts, AttemptId (+31 more)

### Community 98 - "lock"
Cohesion: 0.15
Nodes (45): File inventory: skills/foreman/scripts/lib/lock.sh, fm_lock_acquire(), fm_lock__acquire_flock(), fm_lock__acquire_flock_command_holder(), fm_lock__acquire_mkdir(), fm_lock__available_mechanisms(), fm_lock__bin_mtime(), fm_lock__currency_ok() (+37 more)

### Community 99 - "run-preflight / provider-health"
Cohesion: 0.13
Nodes (41): ProviderHealthError, ReadyTokenIssuanceError, mapAdapterError(), mapProcessError(), runProviderHealthCanary(), RunProviderHealthCanaryInput, tryDecodeReceipt(), tryDecodeResponse() (+33 more)

### Community 100 - "spec"
Cohesion: 0.09
Nodes (44): File inventory: openspec/changes/lane-runtime-typescript/specs/lane-runtime/spec.md, ADDED Requirements, Lane runtime specification, Requirement: Bats parity, Requirement: Capability record reading, Requirement: Containment decision table, Requirement: Containment probe execution, Requirement: Event parity (+36 more)

### Community 101 - "spec-correctness"
Cohesion: 0.13
Nodes (43): asciiBytes(), buildCanonicalBaselineIds(), buildMetrics(), bytesEqual(), callDecodeUtf8(), callSha256(), CANONICAL_BASELINE_IDS, CANONICAL_HEADER_CELLS (+35 more)

### Community 102 - "canary-materializer / bundle-verifier"
Cohesion: 0.11
Nodes (39): components_council_packages_application_src_index_bundleverifierservice, components_council_packages_application_src_index_digestservice, acceptingBundleVerifierLayer, createIdentityBundleVerifier(), identityBundleVerifierLayer(), ObservedBundleIdentity, buildCanaryMaterial(), CANARY_TRUSTED_RULES (+31 more)

### Community 103 - "memory-index / projection"
Cohesion: 0.12
Nodes (22): File inventory: packages/session-store/src/memory-index.ts, File inventory: packages/session-store/src/project-binding.test.ts, File inventory: packages/session-store/src/projection.ts, faultInjectionIndexes(), HangingMemoryIndex, NullMemoryIndex, PoisonMemoryIndex, ThrowingMemoryIndex (+14 more)

### Community 104 - "openai-sol-card"
Cohesion: 0.05
Nodes (42): 10. References, 1. Introduction, 2. Model Data and Training, 3.1 Disallowed Content, 3. Model Safety, 4. Robustness Evaluations, 5. Health, 6. Hallucinations (+34 more)

### Community 105 - "R8-terminusdb-store"
Cohesion: 0.09
Nodes (41): 0. TL;DR, 10. graphify → TerminusDB ingest path, 11. Comparison vs alternatives, 12. Recommendation — **ADOPT-WITH-GUARDRAILS**, 13. Risks, 14. Open questions / unreachable pages, 1. Sources fetched, 2.1 The old company is gone — `terminusdb.com` is a decommissioned host `VERIFIED-live` (+33 more)

### Community 106 - "fm-session-main.test / outbox-store.test"
Cohesion: 0.10
Nodes (37): File inventory: packages/orchestration/src/fm-session-main.test.ts, File inventory: packages/session-store/src/busy-timeout-lock-holder.ts, File inventory: packages/session-store/src/outbox-store.test.ts, captureStderr(), countNotes(), directoryModesAreEnforced(), ENTRY, factStatements() (+29 more)

### Community 107 - "project-registry / project-registry.test"
Cohesion: 0.14
Nodes (40): File inventory: packages/orchestration/src/project-registry.test.ts, File inventory: packages/orchestration/src/project-registry.ts, compareUtf8(), decodeProjectRegistryFileV1(), emptyProjectRegistryV1(), hasExactOwnKeys(), isEnoent(), isPlainObject() (+32 more)

### Community 108 - "supervisor-live-services / supervisor-live-services.test"
Cohesion: 0.18
Nodes (40): File inventory: packages/orchestration/src/supervisor-live-services.test.ts, File inventory: packages/orchestration/src/supervisor-live-services.ts, BoundDir, childPathUnder(), closeQuiet(), defaultSupervisorPaths(), directoryIdentityAnchorSupported(), DirectoryIdentityRaceHook (+32 more)

### Community 109 - "SKILL / testing-anti-patterns"
Cohesion: 0.09
Nodes (40): File inventory: skills/superpowers/skills/test-driven-development/SKILL.md, File inventory: skills/superpowers/skills/test-driven-development/testing-anti-patterns.md, Common Rationalizations, Debugging Integration, Example: Bug Fix, Final Rule, Good Tests, GREEN - Minimal Code (+32 more)

### Community 110 - "effect-testing"
Cohesion: 0.10
Nodes (40): 0. What Foreman actually does today, 1. Pure core / effectful shell — how far, and the rule, 2. Test layers that stay honest, 3. Race hooks: `setCredentialProfileRaceHook` et al., 4. Typed failure paths: making exhaustiveness mechanical, 5. Effect-specific traps, 6. The TDD loop, end to end, 7. Gate summary — one script, ordered by value/cost (+32 more)

### Community 111 - "openai-cache"
Cohesion: 0.10
Nodes (40): A shared prefix is not always a cached prefix, Cache lifetime, Cache location, Can I manually clear the cache?, Change reasoning effort without rewriting the prefix, Choose a caching mode, Compaction can reduce cache reuse, Configure cache retention (+32 more)

### Community 112 - "openai-cache.raw"
Cohesion: 0.10
Nodes (40): A shared prefix is not always a cached prefix, Cache lifetime, Cache location, Can I manually clear the cache?, Change reasoning effort without rewriting the prefix, Choose a caching mode, Compaction can reduce cache reuse, Configure cache retention (+32 more)

### Community 113 - "N2-ontology-engineering"
Cohesion: 0.10
Nodes (40): 0. Bottom line up front, 10.1 Design rules this sketch obeys, 10.2 Node types, 10.3 Edge types, 10.4 What I think is wrong, missing, or over-modelled in the proposed type set, 10.5 Required provenance block `P` — on every LLM-written node and edge, 10. DRAFT ontology sketch, 11. Open questions (+32 more)

### Community 114 - "REAUDIT-opus"
Cohesion: 0.10
Nodes (40): Findings closed — with evidence, Findings NOT closed — what remains, N10 — three of the nineteen kill criteria are unregistrable under the register's own rule, N11 — `release-metrics`' "valid reduced report" scenario is rejected by its own gating rule, N12 — the M5 removal, the MENTIONS fix and the directed fix each stopped at one file, N13 — the four lock refusal codes are neither uniform nor disjoint, N14 — lock currency is defined against the wrong identity, N15 — three consumers land ahead of their declared owners (+32 more)

### Community 115 - "spec"
Cohesion: 0.10
Nodes (40): File inventory: openspec/changes/graph-store-port/specs/store/spec.md, ADDED Requirements, Requirement: a files-only implementation satisfies the port with no database, Requirement: an empty result is never silently accepted, Requirement: concurrent writes follow the measured three-way concurrency rule, Requirement: edge attributes are reified because the store has no edge properties, Requirement: every graph read and write goes through the GraphStore port, Requirement: ingest reads graph.json through a schema-first, two-pass, idempotent path (+32 more)

### Community 116 - "property-testing"
Cohesion: 0.10
Nodes (39): 0. Ground truth: how much is fast-check actually used?, 1. Highest-value targets, 2. Round-trips and invariants — which hold, and which only look like they do, 3. A shared generator library for hostile input, 4.1 Anything whose assertion is a specific failure tag, 4.2 Exact-boundary acceptance, 4.3 Exhaustive enumeration where the space is small, 4.4 Filesystem and platform semantics (+31 more)

### Community 117 - "dependency-drift / dependency-drift.test"
Cohesion: 0.17
Nodes (37): File inventory: packages/orchestration/src/dependency-drift.test.ts, File inventory: packages/orchestration/src/dependency-drift.ts, File inventory: packages/orchestration/src/index.ts, buildCheckerAuthority(), CheckerAuthority, collectCheckerAuthority(), DriftIo, DriftRunOptions (+29 more)

### Community 118 - "spec"
Cohesion: 0.10
Nodes (38): ADDED Requirements, Purpose, Requirement: Actionable dissent uses one correction without a second Council, Requirement: Automatic quorum uses independent failure domains, Requirement: Ballots remain private, Requirement: Candidate identity is blinded without rewriting substance, Requirement: Completed advice, completed invalid response, infrastructure failure, and closure are separate outcomes, Requirement: Completed review quorum counts substantive verdicts only (+30 more)

### Community 119 - "openai-structured"
Cohesion: 0.10
Nodes (39): `additionalProperties: false` must always be set in objects, All fields must be `required`, Avoid JSON schema divergence, Chain of thought, Definitions are supported, Example response, Example response, Example response (+31 more)

### Community 120 - "openai-structured.raw"
Cohesion: 0.10
Nodes (38): `additionalProperties: false` must always be set in objects, All fields must be `required`, Avoid JSON schema divergence, Chain of thought, Definitions are supported, Example response, Example response, Example response (+30 more)

### Community 121 - "R2-anthropic-graph-infra"
Cohesion: 0.10
Nodes (38): 1. Sources fetched, 2.1 Model split (VERIFIED, cell 3), 2.2 Extraction schemas + prompt (VERIFIED, cell 8 — exact), 2.3 Entity resolution (VERIFIED, cell 13 — exact), 2.4 NetworkX assembly (VERIFIED, cell 17 — exact), 2.5 Node enrichment (VERIFIED, cell 21), 2.6 Querying / serialization (VERIFIED, cell 24 — exact), 2.7 Evaluation (VERIFIED — `evaluation/eval_extraction.py` + cell 28) (+30 more)

### Community 122 - "2026-07-31-v029-release-closeout-design"
Cohesion: 0.10
Nodes (38): 0. Decisions taken, 10. Open item carried into the plan, 1. Starting state, measured, 2. Landing order, 3. CI/CD, 4. QA by negative control, 5. Execution, 6. The session store, the ontology, and checkpointing (+30 more)

### Community 123 - "RELEASE-NOTES"
Cohesion: 0.09
Nodes (39): File inventory: skills/superpowers/RELEASE-NOTES.md, Brainstorming Visual Companion, Breaking Changes, Bug Fixes, Bug Fixes, Codex, Codex, Contributors (+31 more)

### Community 124 - "suite-health"
Cohesion: 0.10
Host semantic extraction token usage: unknown (not metered). Deterministic extraction requires no model calls.

### Community 125 - "openai-sol-card"
Cohesion: 0.09
Nodes (38): 3.3 Avoiding Accidental Data-Destructive Actions, 3.4 User Confirmations During Computer Use, 7.3.1 CoT Monitorability, 9.1.1.1 Multimodal Troubleshooting Virology, 9.1.1.2 ProtocolQA Open-Ended, 9.1.1.3 Tacit Knowledge and Troubleshooting, 9.1.1.6 Hard-negative protein binding prediction, 9.1.2.4.1 ExploitBench (+30 more)

### Community 126 - "USAGE"
Cohesion: 0.10
Nodes (38): 1.1 Windows, 1.2 WSL / Linux, 1.3 Boot the architect, 1. Running Setup, 2.1 Create parallel recon worktrees, 2.2 Spawn search and plan, 2.3 Consolidate recon, 2.4 Write the five-part spec and implement (+30 more)

### Community 127 - "spec"
Cohesion: 0.10
Nodes (37): File inventory: openspec/changes/archive/2026-07-30-terminusdb-withdrawn-schema/specs/store-schema/spec.md, ADDED Requirements, Requirement: Claim, Evaluation, Finding, and Source are top-level document classes, Requirement: EVALUATES and Finding targets use a tagged union with exactly one member, Requirement: every GraphNode-derived document carries a producer-version stamp, Requirement: every LLM-populated field is an enum or a reference, Requirement: MENTIONS is not a stored edge, Requirement: PARENT_OF does not exist; four named relations replace it (+29 more)

### Community 128 - "port / version-ref.test"
Cohesion: 0.11
Nodes (24): File inventory: packages/graph-store/src/port.ts, File inventory: packages/graph-store/src/version-ref.test.ts, CAP_BRANCH_MERGE, CAP_CROSS_RUN_QUERY, CAP_TIME_TRAVEL, checkHasCapability(), checkRequireCapability(), defaultAsOf() (+16 more)

### Community 129 - "AUDIT-opus"
Cohesion: 0.11
Nodes (36): a) F1 fix — is the sweep complete? (fourth uncovered family?), AUDIT-opus.md — independent Opus audit of bfc8af4..bbb8ad8, b) New tests 4 and 5 — non-vacuous?, bytes, c) Test 2's widened condition, carve-out it exists to protect, covered by no sweep at all: repo-root and `env/`, d) gitattributes precedence, empirical (+28 more)

### Community 130 - "M1-lane-lifecycle"
Cohesion: 0.11
Nodes (36): Abstractions and their limits, Architect verification of the corrected (post-round-2) artifact, Commands executed by the round-2 agent, Counterexample trace, `eventually_terminal`, H1 — run-scoped resume budget, H2 — dirty-refusal retry loop, H3 — live-but-unproductive lane (+28 more)

### Community 131 - "run-journal.test / node:child_process"
Cohesion: 0.11
Nodes (35): File inventory: packages/event-log/src/run-journal.test.ts, allocateEffect(), appendEffect(), assertClosedFailure(), assertResumeFailure(), ChildCapture, dirnameSafe(), draft() (+27 more)

### Community 132 - "gemini-background"
Cohesion: 0.10
Nodes (35): Background execution, Cancellation and deletion, Create a background interaction, Gemini background cancellation, How background execution works, Java, Java, Java (+27 more)

### Community 133 - "spec"
Cohesion: 0.11
Nodes (35): File inventory: openspec/changes/agy-lane-activation/specs/agy-lane/spec.md, ADDED Requirements, MODIFIED Requirements, Requirement: agy audit lanes run in plan mode and are asserted not to have mutated the tree, Requirement: agy implement lanes run in accept-edits mode with write evidence, Requirement: agy readiness is probed at zero model cost and fails closed, Requirement: an isolated agy home is credential-less until Setup seeds it, Requirement: Foreman's round timeout is authoritative over the vendor print timeout (+27 more)

### Community 134 - "spec"
Cohesion: 0.11
Nodes (35): File inventory: openspec/changes/openspec-superpowers-convergence/specs/release-authority-convergence/spec.md, ADDED Requirements, Purpose, Requirement: Child-bounded action admission, Requirement: Closed OpenSpec workflows, Requirement: Complete release coverage, Requirement: Digest-bound action-specific release admission, Requirement: Exact installed runtime inventory (+27 more)

### Community 135 - "2026-04-06-worktree-rototill-design"
Cohesion: 0.11
Nodes (35): File inventory: skills/superpowers/docs/superpowers/specs/2026-04-06-worktree-rototill-design.md, 1. `using-git-worktrees` SKILL.md Rewrite, 2. `finishing-a-development-branch` SKILL.md Rewrite, 3. Integration Updates, 4. Platform-Neutral Instruction File References, Bug Fixes (bundled), Declarative intent, prescriptive fallback, Design (+27 more)

### Community 136 - "spec-correctness"
Cohesion: 0.13
Nodes (34): CoverageNumerator, coverageNumeratorMatches(), dispositionSum(), hasMetricDefectOrInvention(), isAcceptMetrics(), itemIdentity, metricsBaseConsistent(), NonNegativeSafeInteger (+26 more)

### Community 137 - "gemini-card"
Cohesion: 0.11
Nodes (35): Acceptable Usage, Approach, Architecture, Benefit and Intended Usage, Description, Distribution, Ethics and Content Safety, Evaluation (+27 more)

### Community 138 - "SKILL / code-reviewer"
Cohesion: 0.10
Nodes (30): File inventory: skills/superpowers/skills/requesting-code-review/SKILL.md, File inventory: skills/superpowers/skills/requesting-code-review/code-reviewer.md, File inventory: skills/superpowers/skills/subagent-driven-development/SKILL.md, File inventory: skills/superpowers/skills/subagent-driven-development/implementer-prompt.md, File inventory: skills/superpowers/skills/subagent-driven-development/task-reviewer-prompt.md, Code Reviewer Prompt Template, Example Output, Example (+22 more)

### Community 139 - "qdrant-memory-index"
Cohesion: 0.16
Nodes (17): RFC-9562, File inventory: packages/memory/src/qdrant-memory-index.ts, collectionStem(), KINDS, QdrantMemoryIndex, QdrantMemoryIndexOptions, qdrantPointIdV1(), QdrantPointPayloadV1 (+9 more)

### Community 140 - "claude-structured"
Cohesion: 0.12
Nodes (34): Additional internal limits, API response formatting, Classification, Claude schema constraints, Common use cases, Compatibility, Data extraction, Data retention (+26 more)

### Community 141 - "gemini-structured"
Cohesion: 0.12
Nodes (34): Best practices, Content Moderation, Gemini schema subset, Java, Java, Java, Java, Java (+26 more)

### Community 142 - "REVIEW-opus"
Cohesion: 0.12
Nodes (33): BL-1 — `knowledge-plane-refresh`: the `--directed` mandate is unimplementable, and a PM-declared blocker was dropped, BL-2 — `cross-vendor-audit-routing` and `audit-groundedness-gate` give opposite instructions for `audit-run.sh:31-33`, BL-3 — `doctrine-reality-drift` at S4 fails the docs gate on claims owned by S5, S6 and S9, and the merge gate fails closed behind it, BL-4 — `graph-eval-falsification`: six of ten kill criteria have no threshold, and the thresholds the PM already fixed are not imported, BL-5 — the census cannot gate the store, because both are staged S8 and the census needs a full release of data, BL-6 — the landing order accounts for 24 packages when 26 are live, and two live packages appear in no stage, Blocking findings, Evidence-fidelity audit (+25 more)

### Community 143 - "spec"
Cohesion: 0.12
Nodes (33): File inventory: openspec/changes/archive/2026-07-30-terminusdb-withdrawn-operations/specs/store-operations/spec.md, ADDED Requirements, Requirement: backup is rehearsed on a cadence, not merely documented, Requirement: Docker deployment pins version and image digest, Requirement: drop-and-rebuild is timed and run on a schedule, Requirement: schema migration follows a dry-run-then-backup-then-apply runbook, with rebuild-from-source for inheritance changes, Requirement: the exit path to files-only is rehearsed and gated by named numeric tripwires, Requirement: the query layer answers every N2 competency question as a named, regression-tested query (+25 more)

### Community 144 - "spec"
Cohesion: 0.12
Nodes (33): File inventory: openspec/changes/regression-harness-tiers/specs/regression-harness/spec.md, ADDED Requirements, Requirement: a harness figure with a zero denominator is uncomputable, never zero and never a passing budget, Requirement: each active tier carries an explicit cost/runtime budget and cadence, Requirement: each Tier 1 golden round is demonstrated to fail against its own seeded defect, Requirement: every bugeventlog.md failure class earns a golden round, Requirement: orchestration-gating tiers are Tier 0 and Tier 1; Tier 2 is on-demand vendor research; Tier 3 is cut from this release, Requirement: Tier 0 slice gates catch subsystem regressions the aggregate hides, and the claim is falsifiable (+25 more)

### Community 145 - "schema / files-only"
Cohesion: 0.16
Nodes (29): File inventory: packages/graph-store/src/schema.test.ts, File inventory: packages/graph-store/src/schema.ts, SchemaValidationError, cloneDocMap(), mergePublication(), allowedFieldsFor(), asIdSet(), asIdSetStrict() (+21 more)

### Community 146 - "tool-check-atomicity / tool-check-atomicity.test"
Cohesion: 0.18
Nodes (32): File inventory: packages/orchestration/src/tool-check-atomicity.test.ts, File inventory: packages/orchestration/src/tool-check-atomicity.ts, AtomicityProbeResult, captureText(), checkPinnedVerdict(), countMkdirContentionViolations(), firstLine(), isExistingWritableDir() (+24 more)

### Community 147 - "architecture-ts-inspect"
Cohesion: 0.20
Nodes (33): File inventory: packages/policy/src/architecture-ts-inspect.ts, addBinding(), BabelNode, bindPattern(), BUN_MODULES, childFieldIsTypeOnly(), classifyTsNode(), collectHoistedBindings() (+25 more)

### Community 148 - "repo-hygiene / repo-hygiene.test"
Cohesion: 0.16
Nodes (31): File inventory: packages/policy/src/repo-hygiene.test.ts, File inventory: packages/policy/src/repo-hygiene.ts, ALLOWED_MODE_CHANGES, ALLOWED_ROOT_MD, captureRepoHygieneSnapshot(), checkEvidenceDuplicates(), checkModeRegression(), checkRootDuplicatesDocs() (+23 more)

### Community 149 - "test-sync-to-codex-plugin"
Cohesion: 0.20
Nodes (33): File inventory: skills/superpowers/tests/codex-plugin-sync/test-sync-to-codex-plugin.sh, add_openai_agent_metadata_fixture(), assert_branch_absent(), assert_contains(), assert_current_branch(), assert_equals(), assert_file_equals(), assert_matches() (+25 more)

### Community 150 - "gemini-thinking"
Cohesion: 0.12
Nodes (33): Best practices, Controlling thinking, Gemini thinking, Interactions thought signatures, Interactions with thinking, Java, Java, Java (+25 more)

### Community 151 - "openai-tools.raw"
Cohesion: 0.12
Nodes (32): Additional configurations, Best practices for defining functions, Context-free grammars, Correct versus incorrect patterns, Custom tools, Defining functions, Defining namespaces, Formatting results (+24 more)

### Community 152 - "round-cli / round-cli.test"
Cohesion: 0.14
Nodes (29): File inventory: packages/orchestration/src/round-cli.test.ts, File inventory: packages/orchestration/src/round-cli.ts, File inventory: packages/orchestration/src/round-main.ts, EXIT_BOUNDARY_FAILURE, EXIT_COMPLETED, EXIT_INCOMPLETE_OR_DEFECT, EXIT_INVALID_ARGUMENTS, isEqualOrDescendant() (+21 more)

### Community 153 - "design"
Cohesion: 0.12
Nodes (32): File inventory: openspec/changes/archive/2026-07-30-terminusdb-withdrawn-adapter/design.md, Adopt `terminusdb-client` (v10.2.6), Adopt `@terminusdb/terminusdb-client` (JS/TS), Adopt the official `terminusdb` Python client, Alternatives Considered, Blanket CAS on every write, Context, D10 — Reification classifier (+24 more)

### Community 154 - "spec"
Cohesion: 0.12
Nodes (32): File inventory: openspec/changes/round-ownership-default/specs/round-ownership/spec.md, ADDED Requirements, MODIFIED Requirements, Requirement: a round requires an explicit gate command, Requirement: auto-resume refuses to downgrade a round-owned round to plain mode, Requirement: completion is defined by artifacts, never by an agent's turn, Requirement: `durable.enabled` has a consumer in code, Requirement: round-owned dispatch is the default, and it is enforced in code (+24 more)

### Community 155 - "failures / files-only-hostile.test"
Cohesion: 0.15
Nodes (21): File inventory: packages/graph-store/src/failures.ts, File inventory: packages/graph-store/src/files-only-hostile.test.ts, Branded, capabilityUnavailable(), CapabilityUnavailableError, DocumentNotFoundError, GRAPH_STORE_FAILURE_BRAND, GraphStoreError (+13 more)

### Community 156 - "gate-ground / gate-ground-checks"
Cohesion: 0.13
Nodes (31): File inventory: skills/foreman/scripts/lib/gate-ground-checks.sh, File inventory: skills/foreman/scripts/lib/gate-ground.sh, gg_canary_evaluate_fixture(), gg_check_G1(), gg_check_G2(), gg_check_G3(), gg_check_G4(), gg_check_G5() (+23 more)

### Community 157 - "SKILL"
Cohesion: 0.12
Nodes (32): File inventory: skills/superpowers/skills/writing-skills/SKILL.md, Address "Spirit vs Letter" Arguments, Build Rationalization Table, Bulletproofing Skills Against Rationalization, Close Every Loophole Explicitly, Code Examples, Common Rationalizations for Skipping Testing, Create Red Flags List (+24 more)

### Community 158 - "openai-tools"
Cohesion: 0.12
Nodes (32): Additional configurations, Best practices for defining functions, Context-free grammars, Correct versus incorrect patterns, Custom tools, Defining functions, Defining namespaces, Formatting results (+24 more)

### Community 159 - "spec"
Cohesion: 0.12
Nodes (31): File inventory: openspec/changes/vendor-adapter-contract/specs/vendor-adapters/spec.md, ADDED Requirements, MODIFIED Requirements, Requirement: a non-conforming verdict is a failure, not a verdict, Requirement: a plumbed vendor lane is either functional or absent, Requirement: adapters publish capabilities and unavailability signals, Requirement: audit invocations are not duplicated in prose, Requirement: every vendor invocation is built by a per-vendor adapter (+23 more)

### Community 160 - "AGENT_TRAPS / foreman-qa-preflight"
Cohesion: 0.12
Nodes (29): 10. The suite's verdict depends on how it was launched (2026-07-30), 11. Verification commands that read ambient state need a baseline (2026-07-30), 12. A verification result has an implicit timestamp and tree state (2026-07-30), 13. Escalate a blocker to three DIFFERENT lenses, not three votes (2026-07-30), 14. Three ways a lane round dies silently (observed 2026-08-01), 15. A verification that cannot see the failure it checks for (observed 2026-08-01), 16. Re-express by editing, never by regenerating (observed 2026-08-01), 17. Three ways a green signal lies (observed 2026-08-01) (+21 more)

### Community 161 - "migration-parity"
Cohesion: 0.12
Nodes (30): 0. What the ground actually says, 1. Characterization / golden-master: record reality before you touch it, 2. Differential testing: same input, both binaries, diff, 3. What "faithful" must NOT mean, 4. The lane-queue rule: what must be true before a file becomes an adapter, 5. Shrinking the surface honestly, 6. Recommendation, ordered by value per day of effort, Arm the trigger, first (+22 more)

### Community 162 - "AUDIT-terminusdb-opus"
Cohesion: 0.13
Nodes (30): AUDIT — TerminusDB change packages (Opus lane), B1 — The frozen schema was never loaded into TerminusDB, and nothing loads it before the freeze, B2 — `SUBTASK_OF` is missing; `depends_on` merges two of N2's three relations — the exact defect the requirement claims to prevent, B3 — The `GraphUpdate` journal is still ownerless, and the non-waivable drop-and-rebuild depends on it, B4 — The ingest path cannot write a single document, B5 — `normalize_data_version` silently produces an invalid ref for the real data-version token, B6 — The `/api/log` ban is declared by two packages and implemented by none, B7 — Three new capabilities contradict an unamended sibling; no package carries a MODIFIED delta (+22 more)

### Community 163 - "design"
Cohesion: 0.13
Nodes (30): File inventory: openspec/changes/v040-release-program/design.md, Authority model, Build graph, Context packs, Deferred work, Design: Foreman v0.4 release program, Design objective, Evaluation and rollout (+22 more)

### Community 164 - "2025-11-22-opencode-support-implementation"
Cohesion: 0.13
Nodes (30): File inventory: skills/superpowers/docs/plans/2025-11-22-opencode-support-implementation.md, Clone superpowers skills to OpenCode config directory, In your OpenCode project, My Skill, OpenCode Support Implementation Plan, Phase 1: Create Shared Core Module, Phase 2: Refactor Codex to Use Shared Core, Phase 3: Build OpenCode Plugin (+22 more)

### Community 165 - "testing-skills-with-subagents"
Cohesion: 0.13
Nodes (30): File inventory: skills/superpowers/skills/writing-skills/testing-skills-with-subagents.md, 1. Explicit Negation in Rules, 2. Entry in Rationalization Table, 3. Red Flag Entry, 4. Update description, Common Mistakes (Same as TDD), Example: TDD Skill Bulletproofing, GREEN Phase: Write Minimal Skill (Make It Pass) (+22 more)

### Community 166 - "RELEASE-NOTES"
Cohesion: 0.06
Nodes (31): Bug Fixes, Bug Fixes, Bug Fixes, Changed, Changes, Codex Fixes, Fixed, Fixes (+23 more)

### Community 167 - "2026-07-28 / 2026-08-13"
Cohesion: 0.12
Nodes (27): 1. What actually happened, in order, 2026-07-28 — v0.2.9 Total GeorgeCall, planned end to end, 2. What went right — with evidence, 3. What went wrong, 4. Standing rules that came out of today, 5. Where things stand, 6. Resume instructions, First commands, and what green looks like (+19 more)

### Community 168 - "plan-report"
Cohesion: 0.13
Nodes (29): Architecture, Chosen combination, Config keys (new, under `[audit]` in `.foreman/config.toml`), File-ownership conflicts (flag to the architect before routing to implementers), FOREMAN_REPORT, Goals and non-goals, Metrics, Open questions (+21 more)

### Community 169 - "search-report"
Cohesion: 0.13
Nodes (29): Audit Pipeline Entry Points, Effort Pinning (Model Reasoning), Evidence, Evidence Collection, F10: Graphify Not Injected, F11: Dev-v1 MCP Transport, F12: Model-Family Decorrelation in MCP, F1: Cold-Context Only (No Repo Exploration) (+21 more)

### Community 170 - "DECISIONS-resolved"
Cohesion: 0.13
Nodes (29): A1 — "Four roles, four producers" (`README.md:50-51`), A2 — `v0.2.5` at `:266-270` — **stale, not deliberate**, A3 — `CMD` and `GATE` (`README.md:311-315`), A4 — "host identity" (`README.md:293`), D10 — The remaining work is scheduled by contention, not by stage number, D11 correction — a wildcard in an exclusion pattern is an unverified claim about every directory it matches, D11 — The exec-bit exclusion list, and why it is by pattern, D12 — Premises cite behaviour and carry their check command; never a line number or an unverified count (+21 more)

### Community 171 - "R4-graph-memory-sota"
Cohesion: 0.13
Nodes (29): 10.1 Shape, 10.2 What to store, 10.3 What NOT to store, 10.4 Foreman-side substrate for the layer over graphify (if the store decision slips), 10.5 Evaluation gates (do not ship the plane without these), 10. Recommendation: minimal viable graph plane for Foreman, 11. Open questions, 1. Sources fetched (+21 more)

### Community 172 - "R6-eval-and-workflow"
Cohesion: 0.13
Nodes (29): 1. Sources fetched, 2.1 Benchmarks that actually measure agentic SE, 2.2 Multi-agent vs single-agent: cost/quality, including the strongest counter-evidence, 2.3 LLM-as-judge reliability for code review, 2.4 Cost/latency telemetry practice — the "evaluation plane", 2. Half A — how do we know it's working?, 3.1 Spec-driven development tooling, 3.2 Ratchet / evaluator-optimizer loops applied to code (+21 more)

### Community 173 - "REVIEW-codex"
Cohesion: 0.13
Nodes (29): B10. The work-DAG’s purity claim contradicts its inputs and its symbol join loses edits, B1. The graph plane cannot currently be killed by its stated criteria, B2. The GraphStore boundary and default contradict the adopted architecture, B3. The mandatory directed refresh is not buildable against the cited CLI, B4. The blocking groundedness gate is not structurally zero-false-positive, B5. The landing order reverses declared dependencies and schedules evidence too late, B6. The package inventory and contention analysis are not authoritative, B7. The vendor contract has unresolved and contradictory acceptance contracts (+21 more)

### Community 174 - "M4-evidence-contract"
Cohesion: 0.13
Nodes (29): Atomic filesystem and validator observations, Counterexample, Counterexample, Counterexample, Current `-uall` counterexample, D1 — pre-existing artifact credits a no-op lane, D2 — one audit evidence root cannot meet both roles, D3 — deletion has no total tree identity (+21 more)

### Community 175 - "import-remap-store.test / failures"
Cohesion: 0.14
Nodes (24): File inventory: packages/session-store/src/failures.ts, File inventory: packages/session-store/src/files-only.test.ts, File inventory: packages/session-store/src/import-remap-store.test.ts, Branded, isSessionStoreFailure(), reasonOf(), SESSION_STORE_FAILURE_BRAND, SessionStoreError (+16 more)

### Community 176 - "porting-to-a-new-harness"
Cohesion: 0.13
Nodes (29): File inventory: skills/superpowers/docs/porting-to-a-new-harness.md, Appendix A — Reference integrations (current), Appendix B — Gotchas that have bitten porters, Before you start, Hard requirement: automatic session-start injection, How to tell which shape you have, Part 1 — How Superpowers works across harnesses, Part 2 — Can this harness be supported? (+21 more)

### Community 177 - "2026-06-09-visual-companion-issues"
Cohesion: 0.13
Nodes (29): File inventory: skills/superpowers/docs/superpowers/plans/2026-06-09-visual-companion-issues.md, A1 — Per-session secret key (chosen approach), A2 — Host allowlist dropped; browser WS Origin retained, A3 — Server crashes on `null` / primitive WS payload, A4 — Frame-length bound in `decodeFrame` (adjacent), A. Server security hardening (`server.cjs`), B1 — macOS resource-fork dotfiles served as screen content, B2 — `stop-server.sh` can kill a reused PID (+21 more)

### Community 178 - "tier1-replay"
Cohesion: 0.19
Nodes (29): File inventory: tests/tier1-replay.sh, assert_audit_watchdog_defect(), assert_audit_watchdog_trace(), assert_crlf_worktree_defect(), assert_crlf_worktree_trace(), assert_decision_trace(), assert_formal_setsid_defect(), assert_formal_setsid_trace() (+21 more)

### Community 179 - "spec"
Cohesion: 0.14
Nodes (28): ADDED Requirements, Purpose, Requirement: Abstention is completed advice but not quorum, Requirement: Attempt diagnostics retain terminal evidence, Requirement: Completed advice binds every review identity, Requirement: Council instructions use a versioned ACE profile, Requirement: Every selected model passes a live canary, Requirement: Evidence cannot widen authority (+20 more)

### Community 180 - "hosted-node24-ci.test"
Cohesion: 0.17
Nodes (28): checkParsedCouncilGateContract(), commentOutCouncilGateStep(), councilRoot, executableRunLines(), EXPECTED_ENV, EXPECTED_JOB, EXPECTED_RUN_LINES, fail() (+20 more)

### Community 181 - "grok-structured"
Cohesion: 0.13
Nodes (28): developers_model_capabilities_text_structured_outputs_md, developers_tools_overview_md, [Alternative: Using `response_format` with `sample()` or `stream()`](#alternative-using-response_format-with-sample-or-stream), [Best-effort keywords](#best-effort-keywords), [Constraint limits](#constraint-limits), [Example: Agentic Tools with Structured Output](#example-agentic-tools-with-structured-output), [Example: Client-side Tools with Structured Output](#example-client-side-tools-with-structured-output), [Example: Invoice Parsing](#example-invoice-parsing) (+20 more)

### Community 182 - "AUDIT-L2"
Cohesion: 0.14
Nodes (28): Audit boundary established, Criteria disposition, Empty-register honesty, Evidence-class licensing, F10 — MEDIUM — licensed `non-atomic/contention` evidence is discarded, F11 — MEDIUM — unknown probe evidence is serialized under the wrong class, F12 — MEDIUM — flock evidence never proves that the holder proceeded, F1 — HIGH — inventory can forge `pinned-mechanism` trust and bypass the empty register (+20 more)

### Community 183 - "watch / checkpoint"
Cohesion: 0.23
Nodes (28): File inventory: skills/foreman/scripts/watch.sh, ckpt_latest(), main(), watch.sh script, wd_baseline_ts(), wd_classify_v2(), wd_containment_note(), wd_grace_clamp() (+20 more)

### Community 184 - "check-architecture / eslint.config"
Cohesion: 0.16
Nodes (26): bareBuiltinRoots, councilPackage(), executableExtensions, inspectSource(), isDeclarationOrPropertyName(), isEffectModule(), isForbiddenAdapterLayer(), isForbiddenApplicationLayer() (+18 more)

### Community 185 - "2026-08-07-workflow-gates"
Cohesion: 0.14
Nodes (27): Fixture pair, Fixture pair, Fixture pair, Fixture pair, Gate 1: `formal.yml::Classifier self-test (no models)`, Gate 2: `formal.yml::Run formal suite`, Gate 3: `gates-linux.yml::Run Council Node 24 gate`, Gate 4: `gates-linux.yml::Build POSIX launcher` (+19 more)

### Community 186 - "v0.2.8.2-v0.2.9.0-accomplishments"
Cohesion: 0.14
Nodes (27): ACE Profile 1 preflight, Authority graph and cleanup, Cleanup and post-release ledger closure, CLI and security bounds, Council shadow status, Exact-candidate knowledge graph, Exact release verification, External Council dogfood (+19 more)

### Community 187 - "AUDIT-infra-codex"
Cohesion: 0.14
Nodes (27): 10. Tier budgets and statistical gates are not executable, 11. The formal manifest cannot encode its own required rows, 12. The checker-soundness mechanism does not mechanically cover its claim, 13. Reconciliation-mandated removals and evidence corrections were not applied, 14. R14 and R15 remain open, 1. Audit freshness is not bound to the current audit attempt or evaluated tree, 2. The shared write-evidence predicate is unsound and has two owners, 3. `evidence-contracts` would reject correct audits and accept partial packages (+19 more)

### Community 188 - "run-checks"
Cohesion: 0.26
Nodes (27): assert_toolchain(), build_quint_cmd(), check_coverage_registry(), check_vacuous_registry(), classify_output(), cleanup_owned(), demonstrate_wrong_grep(), die() (+19 more)

### Community 189 - "spec"
Cohesion: 0.14
Nodes (27): File inventory: openspec/changes/formal-model-suite/specs/formal-models/spec.md, ADDED Requirements, Requirement: a model that has drifted from its subsystem is a defect, Requirement: a predicate observed to be vacuous is registered and cannot be reused, Requirement: a verdict is read from the checker's outcome line, never from a substring, Requirement: every modelled defect is asserted to violate before the fix and to hold after it, Requirement: lanes terminate processes by handle, never by pattern, Requirement: results state their method and bound, and are never described as proofs (+19 more)

### Community 190 - "release-authority-cli / release-authority-cli.test"
Cohesion: 0.16
Nodes (25): File inventory: packages/orchestration/src/release-authority-cli.test.ts, File inventory: packages/orchestration/src/release-authority-cli.ts, File inventory: packages/orchestration/src/release-authority-main.ts, actions, authorityRegistration(), commonArgs(), CommonRegistrationArgs, decodeFile() (+17 more)

### Community 191 - "resume-decision.test"
Cohesion: 0.20
Nodes (27): File inventory: packages/orchestration/src/resume-decision.test.ts, attemptId, baseInput(), checkpointEvent(), checkpointIdentity, completedEvents(), completedInput(), completedOutcome() (+19 more)

### Community 192 - "setup / test-priority"
Cohesion: 0.14
Nodes (23): File inventory: skills/superpowers/tests/opencode/setup.sh, File inventory: skills/superpowers/tests/opencode/test-bootstrap-caching.sh, File inventory: skills/superpowers/tests/opencode/test-plugin-loading.sh, File inventory: skills/superpowers/tests/opencode/test-priority.sh, File inventory: skills/superpowers/tests/opencode/test-tools.sh, cleanup_test_env(), HOME, OPENCODE_CONFIG_DIR (+15 more)

### Community 193 - "security-spec-review"
Cohesion: 0.07
Nodes (27): 3. Security requirements and scenarios, Requirement: Authority labels are mandatory (SEC-01), Requirement: Authorization is checked at every call (SEC-05), Requirement: Capabilities are narrow and short-lived (SEC-04), Requirement: Contract amendments require new approval (SEC-03), Requirement: Egress blocks SSRF targets (SEC-10), Requirement: Every outbound boundary scans for secrets (SEC-13), Requirement: Evidence remains quarantined (SEC-08) (+19 more)

### Community 194 - "security-spec-review"
Cohesion: 0.07
Nodes (27): 5. Deliberation requirements and scenarios, Requirement: Abstention and escalation are typed outcomes (DEL-15), Requirement: Ballots remain private (DEL-10), Requirement: Blinding does not rewrite substance (DEL-03), Requirement: Candidate identity is blinded (DEL-02), Requirement: Confidence is calibrated before weighting (DEL-07), Requirement: Deliberation is selective and capped (DEL-08), Requirement: Deterministic checks precede debate (DEL-04) (+19 more)

### Community 195 - "foreman-pidns-degradation-2026-09-05"
Cohesion: 0.15
Nodes (26): Acquisition, Admission rules, Approved experiments (run later the same day), Coverage ledger, D1. Executive diagnosis, D2. Runtime path map, D3. Grok 4.6 model card coverage and threat-model synthesis, D4. Claim versus evidence (+18 more)

### Community 196 - "PAPER-AND-COMPATIBILITY / arxiv-2505.13453v2"
Cohesion: 0.15
Nodes (27): Adopt Pel and extend its execution contract, Foreman Pel implementation proposal, Runtime capability enforcement, Compatibility and release experiments, Corrections and limits that the language profile must record, Effect conflict analysis, Pel compatibility profile and errata, Karpathy's durable wiki pattern (+19 more)

### Community 197 - "spec"
Cohesion: 0.15
Nodes (26): File inventory: openspec/changes/grok-secret-scan-typescript/specs/grok-secret-scan/spec.md, ADDED Requirements, Requirement: bounds fail closed, Requirement: filename and PEM refusal classes are preserved, Requirement: fixture exemptions use exact identity, Requirement: lane-run uses a thin Node adapter, Requirement: secret scan uses a closed typed result, Requirement: the CLI is secret-safe and fail-closed (+18 more)

### Community 198 - "spec"
Cohesion: 0.15
Nodes (26): File inventory: openspec/changes/knowledge-plane-refresh/specs/graphify-integration/spec.md, ADDED Requirements, Graphify integration specification, MODIFIED Requirements, Requirement: Freshness is Graphify-free, Requirement: Graph health checks are discriminating, Requirement: Graphify is qualified before adoption, Requirement: Lossy export is outside the release path (+18 more)

### Community 199 - "bounds / queries"
Cohesion: 0.23
Nodes (24): File inventory: packages/graph-store/src/bounds.ts, File inventory: packages/graph-store/src/index.ts, File inventory: packages/graph-store/src/queries.ts, GENERATION_ID_WIDTH, GRAPH_STORE_SCHEMA_VERSION, MAX_FILE_BYTES, MAX_JSON_DEPTH, MAX_JSON_NODES (+16 more)

### Community 200 - "2026-05-06-lift-drill-into-evals"
Cohesion: 0.15
Nodes (26): File inventory: skills/superpowers/docs/superpowers/plans/2026-05-06-lift-drill-into-evals.md, Lift drill into superpowers as `evals/` — implementation plan, Task 10: Bash test deletion phase — per-file with subagent gate, Task 10a: Skill-triggering prompts (6 files), Task 10b: explicit-skill-requests (selective deletion), Task 10c: subagent-driven-dev real-project tests, Task 10d: tests/claude-code/test-document-review-system.sh, Task 10e: tests/claude-code/test-requesting-code-review.sh (+18 more)

### Community 201 - "RELEASE-NOTES"
Cohesion: 0.07
Nodes (26): Breaking Changes, Bug Fixes, Commit History, Credits, Documentation, File Changes, For Contributors, For Users (+18 more)

### Community 202 - "provider-health.test"
Cohesion: 0.18
Nodes (25): components_council_packages_application_src_index_providerhealtherror, components_council_packages_application_src_index_providerprocesserror, components_council_packages_application_src_index_providerprocessrunner, components_council_packages_application_src_index_runproviderhealthcanary, components_council_packages_application_src_index_runproviderhealthcanaryinput, AdapterConfig, baseInput(), challenge (+17 more)

### Community 203 - "final-fix-report"
Cohesion: 0.15
Nodes (25): BLOCKER B1 — retire reported success for a measurement that does not exist, BLOCKER B2 — the ontology projector exported retired measurements as live, BLOCKER B3 — retire permitted chains and cycles into already-retired rows, BLOCKER B4 — ar_reap_watchdog signalled a PID the script no longer owned, ci-local, Commits, Concerns, Constraint checks (+17 more)

### Community 204 - "2026-07-15-durable-lanes"
Cohesion: 0.15
Nodes (25): Additional findings not folded into the blocks above (completeness), Cross-cutting, durable-lanes Implementation Plan, Execution through Foreman, Global Constraints, Note on shipped `ckpt_snapshot` (T2, already merged), Portability & correctness checklist (apply to EVERY task's code), Pre-implementation audit — Tasks 3–4 (2026-07-15, Codex GPT-5.6 Sol, high) (+17 more)

### Community 205 - "five-part-spec / index"
Cohesion: 0.14
Nodes (18): home_charl_fm_wt_foreman_dsl_release_license_md, home_charl_fm_wt_foreman_dsl_release_openspec_changes_archive_2026_07_18_t5b_concurrency_verdict_md, File inventory: skills/foreman/references/five-part-spec.md, File inventory: skills/foreman/references/index.md, File inventory: skills/foreman/references/regression-tier-budgets.md, Discovery-derived specs, EARS phrasing (required for Grok-bound specs), Exact command(s) the orchestrator will re-run (+10 more)

### Community 206 - "README"
Cohesion: 0.15
Nodes (26): File inventory: README.md, 10. Hard mode — status, 11. Honest capabilities and limits, 12. Further reading, security, layout, license, lineage, 1. What Foreman is and the problem it solves, 2. The mental model, 3. The five-part spec, 4. Lanes and vendor routing (+18 more)

### Community 207 - "graph-evaluation / graph-evaluation.test"
Cohesion: 0.16
Nodes (23): File inventory: packages/orchestration/src/graph-evaluation-main.ts, File inventory: packages/orchestration/src/graph-evaluation.test.ts, File inventory: packages/orchestration/src/graph-evaluation.ts, buildGraphEvaluationReportV1(), encoder, GraphEvaluationArmV1, GraphEvaluationBuildResultV1, GraphEvaluationObservationV1 (+15 more)

### Community 208 - "evidence / vendor-multiround"
Cohesion: 0.23
Nodes (24): File inventory: skills/foreman/scripts/lib/evidence.sh, File inventory: skills/foreman/scripts/vendor-multiround.sh, evidence_canonical_record_to(), evidence_collect_paths_to(), evidence_content_digest(), _evidence_git(), evidence_git_status_to(), evidence_is_git_worktree() (+16 more)

### Community 209 - "SKILL"
Cohesion: 0.15
Nodes (25): File inventory: skills/graphify/SKILL.md, For /graphify add and --watch, For /graphify query, For the commit hook and native AGENTS.md integration, For --update and --cluster-only, /graphify, Honesty Rules, Interpreter guard for subcommands (+17 more)

### Community 210 - "2026-04-06-worktree-rototill"
Cohesion: 0.15
Nodes (25): File inventory: skills/superpowers/docs/superpowers/plans/2026-04-06-worktree-rototill.md, Create PR, Determine path based on chosen location, Get main repo root for CWD safety, Go, If this returns a path, you're in a submodule, not a worktree — proceed to Step 1, Merge first — verify success before removing anything, Node.js (+17 more)

### Community 211 - "branding.test"
Cohesion: 0.25
Nodes (25): File inventory: skills/superpowers/tests/brainstorm-server/branding.test.js, assert, assertBrandedFallbackText(), assertBrandedWithLogo(), assertFramedLogoSupportsDarkTheme(), assertFramedScreenUsesBrandHeader(), assertHeaderAvoidsNarrowOverlap(), assertLogoKeepsTransparentBackground() (+17 more)

### Community 212 - "README"
Cohesion: 0.15
Nodes (25): File inventory: skills/superpowers/tests/claude-code/README.md, Adding New Tests, CI/CD Integration, Claude Code Skills Tests, Current Tests, Debugging Failed Tests, Example Test, Fast Tests (run by default) (+17 more)

### Community 213 - "grok-cli / grok-headless"
Cohesion: 0.12
Nodes (23): build_cli_headless_scripting_md, build_cli_reference_md, build_cli_terminal_support_md, build_features_dashboard_md, build_features_mcp_servers_md, build_features_permissions_md, build_features_sandbox_md, build_features_sessions_md (+15 more)

### Community 214 - "grok-announcement / grok-model"
Cohesion: 0.14
Nodes (24): build_md, API Docs, Create an API Key, [Evals](#evals), [Get started with Grok 4.6](#get-started-with-grok-46), Introducing Grok 4.6, [Safety and capabilities](#safety-and-capabilities), [Training Grok 4.6](#training-grok-46) (+16 more)

### Community 215 - "grok-model / grok-pricing"
Cohesion: 0.11
Nodes (23): build_overview_md, developers_advanced_api_usage_batch_api_md, developers_advanced_api_usage_context_compaction_md, developers_grok_4_6_md, developers_model_capabilities_audio_voice_md, developers_model_capabilities_imagine_md, developers_models_md, developers_pricing_md (+15 more)

### Community 216 - "codex-headless"
Cohesion: 0.14
Nodes (24): codex_auth_ci_cd_auth_md, codex_developer_commands_md, codex_enterprise_workload_identity_md, codex_github_action_md, Advanced stdin piping, Authenticate in automation, Basic usage, Common automation patterns (+16 more)

### Community 217 - "spec"
Cohesion: 0.16
Nodes (24): ADDED Requirements, Purpose, Requirement: Capabilities carry evidence, Requirement: Completed invalid response is not infrastructure failure, Requirement: Failure-domain metadata controls diversity, Requirement: Invocation is shell-free and reproducible, Requirement: Provider readiness is verified before admission, Requirement: Provider wire formats remain private (+16 more)

### Community 218 - "budget / budget.test"
Cohesion: 0.17
Nodes (23): BudgetDimension, budgetDimensions, BudgetReconciliationDecision, BudgetReservationDecision, BudgetState, emptyBudgetVector, initialBudgetState(), mapVector() (+15 more)

### Community 219 - "task-7-report"
Cohesion: 0.16
Nodes (24): 10. git ls-tree, 11. Commit, 12. Not verified / concerns, 1. Step 1 evidence — the orphaned sleep, before any change, 2. Root cause — the real code, not the brief's assumed shape, 3. The fix, 4. Step 4 — failing-test evidence (pre-fix), 5. Step 6 — passing-test evidence (post-fix), full per-test list (+16 more)

### Community 220 - "AUDIT-terminusdb-codex"
Cohesion: 0.16
Nodes (24): B10 — The exact final schema is not live-tested, B1 — No package defines an end-to-end, regenerable materialization, B2 — The adapter conflates CAS tokens with diff references and cannot specify a safe CAS retry, B3 — The schema's external-invariant story is honest but not sufficient, and `RESOLVED_TO` is not actually human-reviewable/provenanced, B4 — N2's relation split and per-edge provenance corrections are not implemented, B5 — `graph.json` cannot be ingested against the frozen schema as specified, B6 — The operations package promises an impossible 24-query green gate, B7 — The fail-closed canaries contradict the normalization contract and are not proven mutations (+16 more)

### Community 221 - "2026-07-19-v029-wsl-compat"
Cohesion: 0.16
Nodes (24): Acceptance, File structure, Global constraints, Ground-truth interfaces (verified 2026-07-19 by the research lanes), P1 — wsl-launcher-shipped, P2 — crlf-extensionless-hardening, P3 — wsl-preflight, P4 — wsl-tool-path-persistence (+16 more)

### Community 222 - "2026-07-15-foreman-enhancement-design"
Cohesion: 0.16
Nodes (24): Agent contracts (`agents/grok-implementer.md`, `agents/codex-implementer.md`), Context — lessons from the first dogfood run, Decisions log, Definition of done, Doctrine (SKILL.md, `references/parallel-worktrees.md`), Execution plan (approach A — the enhancement ships via the enhanced loop), Foreman skill enhancement — design, Goals (+16 more)

### Community 223 - "VERIFY-quint-architect"
Cohesion: 0.16
Nodes (24): ADDENDUM 2 — M3 final results, and a correction to my own termination claim, ADDENDUM 3 — M2 final results: a race that survives the lock fix, ADDENDUM — M1 re-verified against its final artifact (correction), Architect verification of the Quint models — 2026-07-28, Consequence for the release, Correcting my own assessment above, Correction: UNVERIFIED non-termination is REAL. I reported the opposite, Limits of this verification (+16 more)

### Community 224 - "spec"
Cohesion: 0.16
Nodes (24): File inventory: openspec/changes/build-determinism/specs/runtime-build/spec.md, ADDED Requirements, Requirement: Bound violation report, Requirement: Drift cause is measured before it is fixed, Requirement: Expected installed set, Requirement: Installed tree matches the expected set, Requirement: node_modules is a real directory, Requirement: Path-independent bundles (+16 more)

### Community 225 - "design"
Cohesion: 0.16
Nodes (24): File inventory: openspec/changes/evidence-contracts/design.md, Alternatives Rejected, Approach, Declared-set timing: already-satisfied, empty, and forged sets, Deletion had no encoding, so a correct removal looked like an empty round, Demonstrated rejection — what each predicate here is shown to reject, Evidence loop (content digest + lane-type contract + termination reason + bounded re-prompt), Exit-code-only success for non-implement lanes (+16 more)

### Community 226 - "spec"
Cohesion: 0.16
Nodes (24): File inventory: openspec/changes/v030-release-program/specs/orchestration-round-transaction/spec.md, ADDED Requirements, Requirement: Effect owns transaction boundaries, Requirement: one round plan binds one attempt, Requirement: R2 is a pure transaction core, Requirement: recovery preserves exact round identity, Requirement: report freshness uses content identity only, Requirement: round inputs are byte-bounded and preserve arguments (+16 more)

### Community 227 - "sqlite-migration / sqlite-migration.test"
Cohesion: 0.19
Nodes (22): File inventory: packages/session-store/src/sqlite-migration.test.ts, File inventory: packages/session-store/src/sqlite-migration.ts, packages_session_store_src_sidecar_sidecar_format, asJsonValue(), classifySqliteStore(), dumpLegacySqliteAsV1(), DumpLegacySqliteAsV1Result, jsonDumps() (+14 more)

### Community 228 - "auth.test"
Cohesion: 0.21
Nodes (24): File inventory: skills/superpowers/tests/brainstorm-server/auth.test.js, ref_assert, ref_ws, assert, assertSecurityHeaders(), assertStartedOnExpectedPort(), cleanup(), CONTENT_DIR (+16 more)

### Community 229 - "REPORT"
Cohesion: 0.16
Nodes (23): D7/D9 — shadow/enforce switch and dogfood, decision-events.bats, `el_emit` call sites (were "zero" in original T1 — now non-zero), Fields needed by metric defs that are NOT emitted / incomplete, Fields that are `unavailable`-capable (must not be treated as zero), Fields verified present (name and shape), No existing metric computer (half of original T1 that still stands), Other (+15 more)

### Community 230 - "claude-headless / package"
Cohesion: 0.16
Nodes (24): [​](#add-claude-to-a-build-script) Add Claude to a build script, [​](#auto-approve-tools) Auto-approve tools, [​](#background-tasks-at-exit) Background tasks at exit, [​](#basic-usage) Basic usage, Claude SIGTERM continuation, [​](#continue-conversations) Continue conversations, [​](#create-a-commit) Create a commit, [​](#customize-the-system-prompt) Customize the system prompt (+16 more)

### Community 231 - "gemini-pricing"
Cohesion: 0.15
Nodes (24): Batch, Batch, Batch, Batch, Batch, Flex, Flex, Flex (+16 more)

### Community 232 - "README"
Cohesion: 0.16
Nodes (23): ACP Mode (Agent Client Protocol), Architecture Notes, Build from Source, Chat Panel, Configuration, Credits, Development, E2E Testing (+15 more)

### Community 233 - "spec"
Cohesion: 0.16
Nodes (23): File inventory: openspec/changes/bounded-execution-terminal-policy/specs/execution-terminal-policy/spec.md, ADDED Requirements, Requirement: a frozen package blocks only its dependents, Requirement: Foreman Endstop is a persistent required control, Requirement: Foreman persists admission before external work, Requirement: one contract bounds the complete feedback path, Requirement: only product-state changes reset the stall deadline, Requirement: only the user can authorize a replacement contract (+15 more)

### Community 234 - "spec"
Cohesion: 0.16
Nodes (23): File inventory: openspec/changes/node-typescript-runtime/specs/runtime/spec.md, ADDED Requirements, Requirement: compatibility adapters contain no product logic, Requirement: destruction guard command has a closed interface, Requirement: destructive actions require typed admission and execution, Requirement: Effect has a bounded role, Requirement: installed modules are self-contained, Requirement: migrated legacy source is deleted (+15 more)

### Community 235 - "spec"
Cohesion: 0.15
Nodes (24): File inventory: openspec/changes/v040-release-program/specs/release-program/spec.md, Requirement: Bounded Foreman execution loop, Requirement: Deterministic work-DAG projection, Requirement: Durable milestone state, Requirement: Locked evaluation corpus and arms, Scenario: A child or action is not listed, Scenario: A diagnostic contrast looks favorable, Scenario: A failed attempt exists (+16 more)

### Community 236 - "audit-run / telemetry"
Cohesion: 0.24
Nodes (22): File inventory: skills/foreman/scripts/audit-run.sh, File inventory: skills/foreman/scripts/lib/telemetry.sh, ar_atomic_integer(), ar_cleanup_processes(), ar_emit_lineage(), ar_end_timing(), ar_fail(), ar_reap_watchdog() (+14 more)

### Community 237 - "merge-gate / config"
Cohesion: 0.20
Nodes (21): File inventory: skills/foreman/scripts/lib/config.sh, File inventory: skills/foreman/scripts/merge-gate.sh, File inventory: skills/foreman/scripts/nats/setup.sh, _CFG_ENV_VAR, cfg_get(), cfg_load(), _cfg_parse_toml(), _CFG_VALUES (+13 more)

### Community 238 - "README"
Cohesion: 0.16
Nodes (23): File inventory: skills/scrapling/README.md, 1. Install scrapling, 1. 安装 scrapling, 2. Install this skill, 2. 安装此技能, Claude Code Skill: Scrapling, Cookie Vault, Cookie 保险库 (+15 more)

### Community 239 - "2025-11-28-skills-improvements-from-user-feedback"
Cohesion: 0.16
Nodes (23): File inventory: skills/superpowers/docs/plans/2025-11-28-skills-improvements-from-user-feedback.md, 1. verification-before-completion: Add Configuration Change Verification, Anti-Pattern 6: Mocks Derived from Implementation, Context Approaches, Example, Executive Summary, Files to Review, Gate Function (+15 more)

### Community 240 - "lifecycle.test"
Cohesion: 0.23
Nodes (23): File inventory: skills/superpowers/tests/brainstorm-server/lifecycle.test.js, assert, firstServerStarted(), fs, httpStatus(), isWindowsLikeShell(), killAndWait(), makeShellTempDir() (+15 more)

### Community 241 - "server.test"
Cohesion: 0.22
Nodes (22): File inventory: skills/superpowers/tests/brainstorm-server/server.test.js, assert, assertStartedOnExpectedPort(), cleanup(), CONTENT_DIR, ensureSymlinkWorks(), fetch(), fs (+14 more)

### Community 242 - "security-spec-review"
Cohesion: 0.15
Nodes (23): 10.10 Exact replay has a limited meaning, 10.1 Detection is not enforcement, 10.2 Immutable contracts need controlled amendment, 10.3 Broad research conflicts with strict allowlists, 10.4 Complete audit conflicts with data minimization, 10.5 Provenance does not establish truth, 10.6 Blinding conflicts with faithful presentation, 10.7 Model diversity is not automatically independent (+15 more)

### Community 243 - "2026-08-01"
Cohesion: 0.17
Nodes (22): 1. What actually happened, in order, 1. What actually happened, in order, 1. What actually happened, in order, 2. What went right, 2. What went right, 2. What went right, 3. What went wrong, 3. What went wrong (+14 more)

### Community 244 - "node-runner"
Cohesion: 0.17
Nodes (22): 0. Ground truth I measured before advising, 1.1 The four scopes, exactly, 1.2 Watch mode, 1.3 The RED phase has a hole you must plug, 1.4 Do not enable `--test-isolation=none`, 1. The red-green-refactor loop, 2. Placement and naming, 3.1 The runner has three buckets. Use all three, and mean them. (+14 more)

### Community 245 - "resume-decision / ARCHITECTURE-AND-DELETION-MAP"
Cohesion: 0.19
Nodes (22): Graph coverage and limits, Observed architecture, Pel adoption: architecture and deletion map, Proposed target, Replacement and retention map, Simplification acceptance criteria, File inventory: docs/research/pel-release/ARCHITECTURE-AND-DELETION-MAP.md, File inventory: packages/orchestration/src/resume-decision.ts (+14 more)

### Community 246 - "karpathy-llm-wiki / CAPTURE-NOTES"
Cohesion: 0.15
Nodes (21): Paper-derived conformance corpus, Source capture notes, Unverified official Pel implementation, Architecture, Content index, Indexing and logging, Ingest query and lint operations, LLM Wiki (+13 more)

### Community 247 - "claude-fable-changes"
Cohesion: 0.17
Nodes (23): Availability, Behavior differences, Breaking changes, Capability improvements, Change effort mid-conversation (beta), Changed from Claude Fable 5, Content provenance, Earlier models can't read Claude Fable 5.1 thinking blocks (+15 more)

### Community 248 - "SYNTHESIS"
Cohesion: 0.17
Nodes (22): 0. The decision, in one page, 1.1 Layering, 1.2 What is extracted, by whom, 1.3 What is stored where, 1.4 What is queried, and by whom, 1.5 Context construction (the consumption contract), 1.6 The gate (two-speed rule), 1. The architecture (+14 more)

### Community 249 - "2026-07-16-v025-orchestration-hardening"
Cohesion: 0.17
Nodes (22): Bun adoption (stack decision, user-directed 2026-07-16), Environment status (2026-07-18, HOMEOFFICE), foreman-launch contract delta (applies to 2026-07-16-foreman-launch.md), Gate policy (standing, all lanes), NEW Task 8: auto-resume supervisor (bounded), NEW Task T-INFRA: gate-speed foundation (runs FIRST), Ordering & parallelism (REVISED 2026-07-18 — see audit section), Plan audit — 2026-07-18 (4-lens, pre-implementation) (+14 more)

### Community 250 - "spec"
Cohesion: 0.17
Nodes (22): File inventory: openspec/changes/doctrine-reality-drift/specs/doctrine-integrity/spec.md, ADDED Requirements, Requirement: a deterministic checker fails on any claim the code contradicts, Requirement: a package's stated progress may not contradict the roadmap, Requirement: a probe that matches nothing is a failure, Requirement: every change registers the claims its documentation makes, Requirement: load-bearing documentation claims are registered against a deterministic probe, Requirement: the checker's own probes are proven able to fail (+14 more)

### Community 251 - "spec"
Cohesion: 0.17
Nodes (22): File inventory: openspec/changes/v030-release-program/specs/round-live-runtime/spec.md, ADDED Requirements, Requirement: attempt allocation is concurrent and monotonic, Requirement: event append is concurrent, canonical, and replayable, Requirement: live services bind every R2 transaction boundary, Requirement: one explicit external state root owns live round state, Requirement: R3 proves interruption recovery without implementing resume, Requirement: the direct Node runtime executes one exact R2 transaction (+14 more)

### Community 252 - "spec"
Cohesion: 0.17
Nodes (22): File inventory: openspec/changes/vendor-preflight/specs/vendor-preflight/spec.md, ADDED Requirements, Requirement: each vendor's auth evidence class is declared, and no vendor is trusted on an absence of evidence, Requirement: every preflight state is demonstrated reachable before the checker is trusted, Requirement: lane admission uses only the persisted record, Requirement: Setup persists one bounded record for each supported lane, Requirement: the auth result is three-state and an unknown is never rendered as a login instruction, Requirement: the preflight never mutates the toolchain it is inspecting (+14 more)

### Community 253 - "qdrant-client-port"
Cohesion: 0.26
Nodes (12): File inventory: packages/memory/src/qdrant-client-port.ts, aliases(), aliasName(), collectionStem(), epochMetadata(), INDEXES, nodeCount(), object() (+4 more)

### Community 254 - "run / preconditions"
Cohesion: 0.20
Nodes (21): File inventory: tests/lib/preconditions.bash, File inventory: tests/run.sh, preconditions.bash script, preconditions_platform(), require_built(), require_no_live_vendor(), require_non_root(), require_platform() (+13 more)

### Community 255 - "REPORT"
Cohesion: 0.18
Nodes (21): 1. Indeterminate mechanism — no rmdir, nothing deleted, condition reported, 2. flock path — no reclamation attempted, 3. mkdir + live holder — lock NOT removed; refusal on stderr, 4. mkdir + dead holder — reclaimed; record naming lock + dead holder, 5. Reclaim refusal — exit 1, reason surfaced, lock left alone, 6. wt-new refused index lock — index byte-identical AND retry succeeds, 7. No inline spin-loops; separate locks; `el_emit` signature unchanged, 8. shellcheck clean on every modified file (+13 more)

### Community 256 - "claude-opus-card / README"
Cohesion: 0.11
Nodes (13): docs_research_pel_release_graph_coverage, Foreman Pel release research, claude-opus-card, grok-card, openai-astra-card, home_charl_fm_wt_foreman_dsl_release_docs_research_pel_release_sources_models_looking_md, home_charl_fm_wt_foreman_dsl_release_docs_research_pel_release_sources_models_md, home_charl_fm_wt_foreman_dsl_release_docs_research_pel_release_sources_models_score_md (+5 more)

### Community 257 - "claude-streaming"
Cohesion: 0.18
Nodes (22): Basic streaming request, Claude 4.5 and earlier, Claude 4.6 and later, Content block delta types, Error events, Error recovery, Error recovery best practices, Event types (+14 more)

### Community 258 - "gemini-pricing"
Cohesion: 0.09
Nodes (22): Enterprise, Free, Gemini 2.5 Computer Use Preview, Gemini 2.5 Flash Native Audio (Live API), Gemini 3.1 Flash Live Preview, Gemini 3.5 Live Translate, Gemini 3.5 Transcribe, Gemini 3.5 Transcribe Live (+14 more)

### Community 259 - "design"
Cohesion: 0.18
Nodes (21): File inventory: openspec/changes/bounded-execution-terminal-policy/design.md, Action model, Add an autonomous watchdog, Add counters to each shell script, Add one typed execution contract, Alternatives, Contract identity, Council behavior (+13 more)

### Community 260 - "spec"
Cohesion: 0.18
Nodes (21): File inventory: openspec/changes/credential-profile-authority/specs/credential-profile-authority/spec.md, ADDED Requirements, Requirement: closed record and identity, Requirement: credential profile uses a closed typed result, Requirement: exclusive idempotent provisioning, Requirement: linked paths and identity changes fail closed, Requirement: no vendor credential file access, Requirement: profile authority lives outside the worktree (+13 more)

### Community 261 - "design"
Cohesion: 0.18
Nodes (21): File inventory: openspec/changes/lock-primitive-hardening/design.md, Design — lock-primitive-hardening, Every predicate in this package, and the known-bad input it rejects, Flat locking, chosen over ordered nesting (audit finding 6), Formal verification, 2026-07-28: a race the primitive swap does not fix, Lock ordering: today's code is clean, and the point is to keep it so, Ordering, Reclamation is per-lock, owner-aware, and refuses when unsure (+13 more)

### Community 262 - "spec"
Cohesion: 0.18
Nodes (21): File inventory: openspec/changes/vendor-concurrency-and-quota/specs/vendor-concurrency/spec.md, ADDED Requirements, MODIFIED Requirements, Requirement: a new vendor's concurrency cap is 1 until a GREEN row exists, Requirement: a silent model downgrade is detected and reported, Requirement: quota exhaustion is unavailability, never a model failure, Requirement: readiness reports entitlement, not only authentication, Requirement: the concurrency harness covers every vendor and its real isolation lever (+13 more)

### Community 263 - "architecture-extensions / architecture-executable"
Cohesion: 0.25
Nodes (19): File inventory: packages/policy/src/architecture-executable.test.ts, File inventory: packages/policy/src/architecture-executable.ts, File inventory: packages/policy/src/architecture-extensions.ts, classifyExecutableSource(), FileIdentity, parseLsTreeLine(), readShebangInterpreter(), shebangReason() (+11 more)

### Community 264 - "SKILL"
Cohesion: 0.18
Nodes (21): File inventory: skills/foreman/SKILL.md, Commitment boundaries, Configurable Council profile, Cost discipline (prime directive), Durable lanes, Durable rounds (v0.2.5), External target repositories, Five-part spec contract (+13 more)

### Community 265 - "release-metrics"
Cohesion: 0.18
Nodes (21): File inventory: skills/foreman/references/release-metrics.md, Claim discipline (standing rules), Conventions, M10 — auditor–architect agreement (Cohen's κ) (deferred), M11 — flake rate (deferred), M12 — budget consumed vs declared (deferred), M13 — prediction-hold rate (deferred), M1 — first-pass gate rate (+13 more)

### Community 266 - "2025-11-22-opencode-support-design"
Cohesion: 0.18
Nodes (21): File inventory: skills/superpowers/docs/plans/2025-11-22-opencode-support-design.md, Architecture, Background, Benefits, Code Reuse Strategy, Custom Tools, File Structure, High-Level Structure (+13 more)

### Community 267 - "SKILL"
Cohesion: 0.18
Nodes (21): File inventory: skills/superpowers/skills/using-git-worktrees/SKILL.md, 1a. Native Worktree Tools (preferred), 1b. Git Worktree Fallback, Assuming directory location, Common Mistakes, Create the Worktree, Directory Selection, Fighting the harness (+13 more)

### Community 268 - "brokenwindows"
Cohesion: 0.18
Nodes (20): brokenwindows.md — small breakages that are still in the tree, BW-003 — the `sqlite3` manifest contradiction, BW-005 — two `maintenance.yml` gates have no positive control, BW-006 — `RESUME.md` names a trunk that no longer exists, BW-007 — no mechanism keeps a derived plugin copy fresh, BW-008 — the session store is stale and points at another host, BW-010 — secret-scan cannot scan its own worktree clean, BW-011 — three separate path normalizers must be kept in agreement (+12 more)

### Community 269 - "claude-effort"
Cohesion: 0.19
Nodes (21): Best practices, Change effort mid-conversation, Compatibility, Effort, Effort levels, Effort with thinking, Effort with tool use, How effort works (+13 more)

### Community 270 - "openai-reasoning"
Cohesion: 0.19
Nodes (20): Advice on prompting, Allocating space for reasoning, Change reasoning mid-conversation, Continue reasoning with stored responses, Controlling costs, Get started with reasoning, How reasoning works, Keeping reasoning items in context (+12 more)

### Community 271 - "openai-reasoning.raw"
Cohesion: 0.19
Nodes (20): Advice on prompting, Allocating space for reasoning, Change reasoning mid-conversation, Continue reasoning with stored responses, Controlling costs, Get started with reasoning, How reasoning works, Keeping reasoning items in context (+12 more)

### Community 272 - "round-latency-fable-5-1"
Cohesion: 0.19
Nodes (20): 10. Make the docs gate discriminate, 1. Verify once per tree: the in-round gate becomes the pristine check, 2. Make the watcher survive the gate phase and block until terminal, 3. One command per round: `lane-round dispatch` and `lane-round wait`, 4. Bounded automatic rework on a failed gate, 5. Tier the in-round gate; run the full suite once at merge, 6. Run the audit beside the gate, not after it, 7. Stop verifying inside the model turn (+12 more)

### Community 273 - "PKG-graph-workplane-summary"
Cohesion: 0.19
Nodes (20): 1. `audit-groundedness-gate`, 2. `work-dag-projection`, 3. Landing notes, Blocking versus warning, per check, Boundary notes, Divergence from R1, deliberate, PKG — graph plane: the gate and the work plane, R7's two amendments, both load-bearing (+12 more)

### Community 274 - "2026-08-12-sessiondb-completion"
Cohesion: 0.19
Nodes (20): File Structure, Global Constraints, Rebuild the runtime bundle, on every task that changes orchestration source, Seed facts every task depends on, Self-review, SessionDB Completion Implementation Plan, Task 10: Record the traps and the obligations, Task 1: Re-review Task 6a (+12 more)

### Community 275 - "2026-08-07-v030-node-migration-completion-design"
Cohesion: 0.19
Nodes (20): 1.1 Python inventory, 1.2 Exit proof, 1. Release definition, 2. Settled decisions, 3. Workstreams, 4.1 Per-change bar, 4.2 Property testing, 4. Verification (+12 more)

### Community 276 - "design"
Cohesion: 0.19
Nodes (20): File inventory: openspec/changes/archive/2026-07-17-test-harness-fork-tax/design.md, Coverage-neutrality, Coverage-neutrality, Coverage-neutrality (isolation), Coverage-neutrality (kill-bound contract preserved), Current (lines 19-34), Current (lines 9-13), Design — test-harness fork-tax reduction (+12 more)

### Community 277 - "spec"
Cohesion: 0.19
Nodes (20): File inventory: openspec/changes/council-review-plane/specs/council-review/spec.md, ADDED Requirements, Requirement: a review reads one round, never a worktree, Requirement: candidate identity is blinded before judging, Requirement: deterministic checks precede deliberation, Requirement: judges are non-authors and comparisons are order-checked, Requirement: outcomes are typed and name the unmet condition, Requirement: reviewer count never substitutes for domain diversity (+12 more)

### Community 278 - "spec"
Cohesion: 0.19
Nodes (20): File inventory: openspec/changes/council-v029-preflight-release/specs/release/spec.md, ADDED Requirements, Requirement: Council shadow outcomes stay advisory, Requirement: External dogfood precedes release, Requirement: The canary schema binds the challenge nonce, Requirement: The release has one product boundary, Requirement: The release makes no broad Council claim, Requirement: The release uses exact-candidate evidence (+12 more)

### Community 279 - "spec"
Cohesion: 0.19
Nodes (20): File inventory: openspec/changes/session-store-recovery/specs/session-store/spec.md, ADDED Requirements, Requirement: No source refusal, Requirement: Recover from the sidecar, Requirement: Recovery prints the summary, Requirement: Refusal names the remedy, Requirement: Repair failure is explicit, Requirement: Repair is idempotent on a healthy store (+12 more)

### Community 280 - "design"
Cohesion: 0.19
Nodes (20): File inventory: openspec/changes/three-outcome-verdicts/design.md, A note on what the formal model can and cannot say here, Alternatives considered and REJECTED, Deletions, symlinks and type changes in `tree_sha256`, Demonstrated rejection — what each gate predicate here is shown to reject, Design — three-outcome-verdicts, Every audit writes a verdict, including the ones that fail, Evidence binding: the attempt and the tree, not the diff hash alone (+12 more)

### Community 281 - "architecture-schema / architecture-delta"
Cohesion: 0.19
Nodes (19): File inventory: packages/policy/src/architecture-delta.ts, File inventory: packages/policy/src/architecture-schema.ts, DeltaRecord, ParseDeltaFail, ParseDeltaOk, ParseDeltaResult, parseNameStatusDelta(), parseNulPathList() (+11 more)

### Community 282 - "lane-run / eventlog"
Cohesion: 0.27
Nodes (20): File inventory: skills/foreman/scripts/lane-run.sh, cleanup(), emit_kill_alert(), GIT_ASK_YESNO, kill_cmd_bounded(), kill_launcher_bounded(), lane_default_credential_profile(), lane_emit_ownership() (+12 more)

### Community 283 - "worktree / wt-merge"
Cohesion: 0.21
Nodes (18): File inventory: skills/foreman/scripts/lib/worktree.sh, File inventory: skills/foreman/scripts/wt-merge.sh, File inventory: skills/foreman/scripts/wt-new.sh, git_retry(), worktree.sh script, wt_branch(), wt_parent_dir(), wt_path() (+10 more)

### Community 284 - "visual-companion"
Cohesion: 0.19
Nodes (20): File inventory: skills/superpowers/skills/brainstorming/visual-companion.md, Browser Events Format, Cards (visual designs), Cleaning Up, CSS Classes Available, Design Tips, File Naming, How It Works (+12 more)

### Community 285 - "CREATION-LOG"
Cohesion: 0.19
Nodes (20): File inventory: skills/superpowers/skills/systematic-debugging/CREATION-LOG.md, Bulletproofing Elements, Creation Log: Systematic Debugging Skill, Enhancement 1: TDD Reference, Extraction Decisions, Final Outcome, Initial Version, Iterations (+12 more)

### Community 286 - "test-helpers / test-worktree-native-preference"
Cohesion: 0.20
Nodes (17): File inventory: skills/superpowers/tests/claude-code/test-helpers.sh, File inventory: skills/superpowers/tests/claude-code/test-subagent-driven-development-integration.sh, File inventory: skills/superpowers/tests/claude-code/test-subagent-driven-development.sh, File inventory: skills/superpowers/tests/claude-code/test-worktree-native-preference.sh, assert_contains(), assert_count(), assert_not_contains(), assert_order() (+9 more)

### Community 287 - "spec"
Cohesion: 0.19
Nodes (19): ADDED Requirements, Purpose, Requirement: Capabilities are narrow and expiring, Requirement: Every direct and transitive call is authorized, Requirement: Models do not construct arbitrary transport URLs, Requirement: Outbound boundaries scan for protected data, Requirement: Redirects require full reauthorization, Requirement: Secrets are injected at the final trusted hop (+11 more)

### Community 288 - "spec"
Cohesion: 0.19
Nodes (19): ADDED Requirements, Purpose, Requirement: Ambiguous side effects are not replayed, Requirement: Budgets are reserved before work starts, Requirement: Cancellation owns the complete process tree, Requirement: Required checkpoints are durable, Requirement: Retry ownership is singular and bounded, Requirement: Run replay is deterministic (+11 more)

### Community 289 - "schema-file-materializer / schema-file-materializer.test"
Cohesion: 0.27
Nodes (18): SchemaFileMaterializationError, components_council_packages_application_src_index_schemafilematerializationerror, cleanupFailed(), createFailed(), defaultSchemaFileMaterializerOps, delay(), ensureRemoved(), materializeCanarySchemaFile() (+10 more)

### Community 290 - "spec-correctness.test / spec-correctness"
Cohesion: 0.24
Nodes (19): acceptBody(), allMappedItems(), BASELINE_IDS, buildMatrix(), changesBody(), changesBodyNoFindings(), decodeResponse(), decodeUtf8() (+11 more)

### Community 291 - "tier1-failure-classes"
Cohesion: 0.19
Nodes (19): Closure rule and actors, Coverage arithmetic, Failure classes, FC-01 — Monitor predicate cannot fire or measures the wrong signal, FC-02 — Checker reports a verdict without establishing the claim, FC-03 — Lane reaches a terminal state without its deliverable, FC-04 — Child process or lock outlives its owning round, FC-05 — Environment capability gap is treated as a product failure (+11 more)

### Community 292 - "t1-premise-check"
Cohesion: 0.19
Nodes (19): Current operator guidance and reference consumers, Evidence and note records, Formal reports and generated graph records, OpenSpec records, Premise 1: stale-verdict hazard, Premise 2: config seam, Premise 3: consumers of the three literals, Recorded data and root records (+11 more)

### Community 293 - "REPORT"
Cohesion: 0.19
Nodes (19): 0. Order of work, 1. Fixes, 2. Full harness, 3. Unsatisfied / blockers (stated honestly), 4. Files touched, F10 / F11 — evidence classes, F1 — `pinned-mechanism` inventory cannot forge trust, F2 — no cross-class inheritance of atomic (+11 more)

### Community 294 - "REPORT"
Cohesion: 0.19
Nodes (19): 1. Bare skip without a reason is a failure, 2. Reasoned skip within budget passes and is reported, 3. Skip budget excess fails and names the file and budget, 4. Per-file pass regression fails and names actual and baseline, 5. Aggregate blindness is fixed, 6. Shadow reports; enforce gates, 7. The evidence harness itself exits non-zero, 8. Shellcheck (+11 more)

### Community 295 - "task-8-fix-report"
Cohesion: 0.19
Nodes (19): 1. What the guard actually did, 2. The fix, 3. `tests/lock.bats` after the fix, 4. Triage of the three unexplained failures, 5. Obligations recorded, 6. Commit, 7. What I could not verify, A related finding, not fixed (+11 more)

### Community 296 - "grok-responses"
Cohesion: 0.19
Nodes (19): [Compact a conversation](#compact-a-conversation), [Create new response](#create-new-response), [Delete previous response](#delete-previous-response), [Inference API](#inference-api), [List input items](#list-input-items), Path parameters, Path parameters, Path parameters (+11 more)

### Community 297 - "architect-weight-fable-5-1"
Cohesion: 0.19
Nodes (19): 10. Close-out proportional to the session, 1. Small-change mode: a tiered fast path with mechanical entry criteria, 2. Doctrine compression: a 150-line operating core, one statement per rule, grammar owned by `--help`, 3. Retire "read `AGENT_TRAPS.md` in full": classify every trap as enforced, checkable, or manual, 4. Right-size the per-round check to the tier; run the full verify once at merge, 5. Provision worktree dependencies at `wt-new`, from a per-lockfile store, 6. Make the docs gate green on a clean tree and scoped to changed files, 7. Derive the Endstop contract and the queue block from the spec (+11 more)

### Community 298 - "2026-08-12-task-6a-review"
Cohesion: 0.19
Nodes (19): 10. The new bats assertion is redundant with its own hunk and matches on row content, 11. The golden seed contains no supersession fan-in, so the goldens never exercise the relaxed invariant, 12. A v1 `blocked` obligation with a null blocker is silently indistinguishable from an open one, 1. The sidecar writer can still emit a tracked record the reader refuses, and the CLI calls it success, 2. `classifyStore` reads the exact corrupted intermediate this commit exists to fix as healthy, 3. `mintId` replaces an atomic insert with a read-modify-write that has no lock, 4. `recover`, `freshness` and `sidecar` now write to the store, 5. The CLI never closes its connection, leaving an un-checkpointed WAL after every write (+11 more)

### Community 299 - "2026-08-12-sessiondb-completion-design"
Cohesion: 0.19
Nodes (19): 1. `retire` has no port equivalent, 2. The seam variable name is already taken, 3. The plan's line references predate Task 6a, 4. Predicate 1 is unprovable as written, Authority, Design, Four defects in the existing plan, Out of scope (+11 more)

### Community 300 - "M3-audit-gate"
Cohesion: 0.19
Nodes (19): 1. Content binding has a gate-to-merge TOCTOU unless the diff is frozen, 2. Merge freshness has the same check-to-use race, 3. CLI/vendor-name routing permits same-family authorization, 4. Verdict-only binding leaves stale checks/docs merge-authorizing, 5. `WARNING` is merge-authorizing policy, not merely informational, Any new defect the model exposes, Apalache bounded checking, Cross-vendor / agy-gateway result (+11 more)

### Community 301 - "spec"
Cohesion: 0.17
Nodes (20): File inventory: openspec/changes/archive/2026-07-30-terminusdb-withdrawn-adapter/specs/store-adapter/spec.md, Requirement: CAS wrapper refuses RMW without precondition and retries mismatch, Requirement: Error taxonomy and retry policy, Requirement: Non-empty query wrapper with expect parameter, Requirement: normalize_data_version validates against the live branch list, never trusts a bare prefix-strip, Requirement: Schema writes always pass full_replace=true, Scenario: a hand-written branch ref normalizes cleanly, Scenario: an opaque response-header token is rejected, not silently accepted (+12 more)

### Community 302 - "spec"
Cohesion: 0.19
Nodes (19): File inventory: openspec/changes/graph-eval-falsification/specs/evaluation/spec.md, ADDED Requirements, Requirement: a complete measurement has a deterministic verdict, Requirement: absent evidence is never a pass, Requirement: run-set decoding is strict and bounded, Requirement: the release publishes the negative result, Requirement: the report is canonical and replayable, Requirement: the run set accounts for 2,000 paired slots (+11 more)

### Community 303 - "open / files-only-lock-contender"
Cohesion: 0.22
Nodes (18): File inventory: packages/session-store/src/files-only-lock-contender.ts, File inventory: packages/session-store/src/open.ts, main(), send, waitForRelease(), openFilesOnlyStore(), CANONICAL_BACKENDS, CanonicalBackend (+10 more)

### Community 304 - "superpowers / helper.test"
Cohesion: 0.20
Nodes (18): File inventory: skills/superpowers/.opencode/plugins/superpowers.js, File inventory: skills/superpowers/tests/brainstorm-server/helper.test.js, ref_fs, ref_os, ref_path, ref_url, __dirname, extractAndStripFrontmatter() (+10 more)

### Community 305 - "CLAUDE"
Cohesion: 0.19
Nodes (19): File inventory: skills/superpowers/CLAUDE.md, Bulk or spray-and-pray PRs, Bundled unrelated changes, "Compliance" changes to skills, Domain-specific skills, Eval harness, Fabricated content, Fork-specific changes (+11 more)

### Community 306 - "polyglot-hooks"
Cohesion: 0.19
Nodes (19): File inventory: skills/superpowers/docs/windows/polyglot-hooks.md, Avoid, "bash is not recognized", Cross-Platform Polyglot Hooks for Claude Code, Do, Example: JSON escaping without external tools, File Structure, Hook doesn't fire at all (+11 more)

### Community 307 - "sync-to-codex-plugin"
Cohesion: 0.29
Nodes (19): File inventory: skills/superpowers/scripts/sync-to-codex-plugin.sh, append_git_ignored_directory_excludes(), append_git_ignored_file_excludes(), apply_to_preview_checkout(), cleanup(), confirm(), copy_local_destination_overlay(), copy_preserved_destination_metadata() (+11 more)

### Community 308 - "2026-08-07-remaining-gates"
Cohesion: 0.20
Nodes (18): Fixture pair, Fixture pair, Fixture pair, Gate 1: `tests/lib/positive-control.bash::assert_positive_control_token`, Gate 2: `tests/lib/check-registry-compare.sh::check-registry-compare`, Gate 3: `skills/foreman/scripts/gate-eval.sh::gate-eval`, Known-bad arm, Known-bad arm (+10 more)

### Community 309 - "2026-08-08-run-sh-gates"
Cohesion: 0.20
Nodes (18): Fixture pair, Fixture pair, Fixture pair, Gate 1: `validate_baseline_file`, Gate 2: `validate_skip_budget_file`, Gate 3: `lookup_skip_budget`, Known-bad arm, Known-bad arm (+10 more)

### Community 310 - "AUDIT-merge-ready"
Cohesion: 0.20
Nodes (18): B1 — D11 exclusion swallows the directly-executed SDD family (sixth relocation), B2 — Round 6 removed D1's deliberate non-bash hooks sweep, Evidence, Final Pre-Merge Audit, Findings, H1 — Package test cleanup preserves repository status on success-path execution and induced failure, H2 — PNG cleanup trap composes with Bats failure reporting, M1 — Existing required executable modes are correct in the commit (+10 more)

### Community 311 - "REPORT"
Cohesion: 0.20
Nodes (18): ARCHITECT ADDENDUM (lane killed by its 30-minute timeout mid-write), ARCHITECT ADDENDUM (lane was killed by its 30-minute timeout mid-write), Coverage-gap analysis, Duplicate historical finding — L4-F1, Eleven-Requirement Coverage Audit, FINDING L4-F1 (HIGH) — `FM_LOCK_FS_UNSUPPORTED` names nothing, Fix the suite-caught finding, Lock Primitive Hardening Report (+10 more)

### Community 312 - "dogfood-lane-grok.report"
Cohesion: 0.20
Nodes (18): ARCHITECT_ACTIONS, Commands run to verify each claim, Files touched, Finding 1 — suite is 50 files / 635 tests (not 56 / 685), Finding 2 — Windows is not bats-free (precision, not deletion), Finding 3 — `gates-linux` is not every push, Finding 4 — live `wsl-ci-parity` coordination (missed occurrence), Finding 5 — stale present-tense 373/9 beside corrected count (+10 more)

### Community 313 - "task-6-report"
Cohesion: 0.20
Nodes (18): 10. Commit SHA, 11. What could not be verified, 1. Failing test output (Step 2), 2. Passing test output (Step 4), 3. New rows in tests/baseline.tsv and tests/skip-budget.tsv, 4. `bash tools/ci-local.sh --quick` result line, 5. shellcheck output for tools/plugin-drift.sh, 6. Real-install drift run (Step 6) (+10 more)

### Community 314 - "2026-08-08-regime-coverage"
Cohesion: 0.20
Nodes (18): 1. Measured coverage, 26 capability guards were silent, 2. What is not enforced at all, 3. Deferred gates, grouped by reason, 4. Gates that cannot fail by construction, 5. Beyond the registry: what W1's lanes found and fixed, 6. Task-by-task context, Cannot fail by construction (+10 more)

### Community 315 - "2026-07-19-empirical-workloads"
Cohesion: 0.19
Nodes (18): Acceptance, File structure, foreman Empirical-Workload Support Implementation Plan, Global constraints, Ground-truth interfaces (verified 2026-07-19), Package A — spec-triage gate (capability `spec-triage`; C1 + C4), Package B — foreman-discover lane (capability `discover-lane`; C2), Package C — captured-facts convergence (capability `captured-facts`; C3) (+10 more)

### Community 316 - "2026-07-18-v0275-usability-design"
Cohesion: 0.20
Nodes (18): 1. lifecycle-three-stage (implement, foundational), 2. grok-lane-activation (implement), 3. t5b-concurrency-verdict (implement), 4. posix-cascade-parity (implement), 5. worktree-hardening (implement), 6. wsl-reliability-env-refresh (implement, full WSL setup), 7. docs-readme-refresh (implement, sequenced last), 8. hard-mode-launcher (approved spec, next release) (+10 more)

### Community 317 - "spec"
Cohesion: 0.20
Nodes (18): File inventory: openspec/changes/launcher-node-port/specs/launcher/spec.md, ADDED Requirements, Requirement: Node launcher package surface, Requirement: Platform containment capabilities, Requirement: Runtime artifact, Requirement: Stream and heartbeat contracts, Requirement: Supervision safety, Scenario: Copied bundle version (+10 more)

### Community 318 - "spec"
Cohesion: 0.20
Nodes (18): File inventory: openspec/changes/profile-bound-setup-preflight/specs/profile-bound-setup-preflight/spec.md, ADDED Requirements, Requirement: child environment isolation for vendor probes, Requirement: profile-bound preflight persistence, Requirement: profile-scoped store fails closed and keeps secrets out, Requirement: R7B1 scope boundary, Requirement: Setup grammar accepts optional credential profile, Scenario: authority refusal before probes (+10 more)

### Community 319 - "design"
Cohesion: 0.20
Nodes (18): File inventory: openspec/changes/test-infrastructure-hardening/design.md, Artifacts over exit codes, substrings and self-report, Boundaries with the rest of the release, Cross-checking, and its honest limitation, Design — test-infrastructure-hardening, Determinism over sleeps, Per-slice baselines, because aggregates lie at this size, Proportionality (2026-07-28 fix round) (+10 more)

### Community 320 - "2026-02-19-visual-brainstorming-refactor-design"
Cohesion: 0.20
Nodes (18): File inventory: skills/superpowers/docs/superpowers/specs/2026-02-19-visual-brainstorming-refactor-design.md, Changes by File, Core Model, Design, `frame-template.html` (UI frame), `helper.js` (client-side script), `index.js` (server), Key Addition: `.events` File (Per-Screen Event Stream) (+10 more)

### Community 321 - "2026-03-23-codex-app-compatibility-design"
Cohesion: 0.20
Nodes (18): File inventory: skills/superpowers/docs/superpowers/specs/2026-03-23-codex-app-compatibility-design.md, 1. `using-git-worktrees/SKILL.md` — Add Step 0 (~12 lines), 2. `finishing-a-development-branch/SKILL.md` — Add Step 1.5 + cleanup guard (~20 lines), 3. `subagent-driven-development/SKILL.md` and `executing-plans/SKILL.md` — 1 line edit each, 4. `codex-tools.md` — Add environment detection docs (~15 lines), Automated (run in Claude Code after implementation), Changes, Codex App Compatibility: Worktree and Finishing Skill Adaptation (+10 more)

### Community 322 - "SKILL"
Cohesion: 0.20
Nodes (18): File inventory: skills/superpowers/skills/receiving-code-review/SKILL.md, Acknowledging Correct Feedback, Code Review Reception, Common Mistakes, Forbidden Responses, From External Reviewers, From your human partner, GitHub Thread Replies (+10 more)

### Community 323 - "spec"
Cohesion: 0.22
Nodes (17): ADDED Requirements, Purpose, Requirement: Audit events use a canonical envelope, Requirement: Audit failure cannot become success, Requirement: Audit integrity is independently verifiable, Requirement: Audit storage minimizes sensitive content, Requirement: Recorded-input replay verifies decision determinism, Requirement: Replay modes are explicit (+9 more)

### Community 324 - "spec"
Cohesion: 0.22
Nodes (17): ADDED Requirements, Purpose, Requirement: Citation support is verified separately, Requirement: Every artifact has content-bound identity, Requirement: Lineage is PROV-compatible, Requirement: Material claims use exact evidence locators, Requirement: Provenance, truth, quality, support, and authority are separate, Requirement: Synthesis preserves candidate lineage (+9 more)

### Community 325 - "spec"
Cohesion: 0.22
Nodes (17): ADDED Requirements, Purpose, Requirement: Graph mutations require separate authority, Requirement: Graphify is queried before broad graph-corpus reads, Requirement: PixelRAG capture is visually verified, Requirement: Raw and derived evidence remains quarantined, Requirement: Research tools run through one gateway, Requirement: Scrapling collection is scoped and sanitized (+9 more)

### Community 326 - "spec"
Cohesion: 0.22
Nodes (17): ADDED Requirements, Purpose, Requirement: Host lifecycle differences are conformance-tested, Requirement: Hosts receive one stable Council API, Requirement: Installation does not grant authority, Requirement: MCP transport preserves protocol hygiene, Requirement: Native wrappers remain thin, Requirement: Paths are portable (+9 more)

### Community 327 - "AUDIT-devlog-2026-07-30"
Cohesion: 0.22
Nodes (17): 0. A process finding, before the audit proper, 1. Scope and method, 2.1 Provenance and headline counts, 2.2 The S1 narrative (§1), 2.3 "What went right" (§2), 2.4 "What went wrong" (§3), 2.5 Standing rules (§4), 2.6 "Where things stand" (§5) (+9 more)

### Community 328 - "AUDIT-devlog-2026-07-30"
Cohesion: 0.22
Nodes (17): 0. A process finding, before the audit proper, 1. Scope and method, 2.1 Provenance and headline counts, 2.2 The S1 narrative (§1), 2.3 "What went right" (§2), 2.4 "What went wrong" (§3), 2.5 Standing rules (§4), 2.6 "Where things stand" (§5) (+9 more)

### Community 329 - "REPORT"
Cohesion: 0.22
Nodes (17): 1. Pre-fix validate errors (five packages), 2. Header transform (content-preserving), 3. Post-fix validate (five packages — all valid strict), 4. Regression validate (other 28 packages), 5. openspec/README.md claim update, 6. Content-preservation proof (diff touches only headings), 7. Aggregate before/after validate (all 33 packages), After (full) (+9 more)

### Community 330 - "REWORK"
Cohesion: 0.22
Nodes (17): F10 — MEDIUM. Licensed `non-atomic` contention evidence is discarded, F11 — MEDIUM. Unknown probe evidence is serialized under the wrong class, F12 — HIGH-adjacent. flock evidence never proves the holder proceeded, F1 — HIGH, the blocker. `pinned-mechanism` trust is forged from the inventory row, F2 — HIGH. Aggregation inherits an atomic verdict across filesystem classes, F3 — HIGH. flock syscall evidence does not require `LOCK_EX|LOCK_NB`, F4 — HIGH. mkdir syscall evidence is not bound to the probed lock target, F5 — HIGH. The Git-Bash path stays locked out even after a real pin (+9 more)

### Community 331 - "orchestration-deep-research-report"
Cohesion: 0.22
Nodes (17): Candidate assessments, Claude Code primitives, Executive summary, Failure-mode coverage matrix, Foreman orchestration options for a Windows-hosted multi-agent coding harness, Hardened Foreman with Windows Job Objects and pueue, Hatchet, LangGraph (+9 more)

### Community 332 - "2026-07-18-hard-mode-launcher"
Cohesion: 0.20
Nodes (17): Acceptance, File structure, Global constraints, Ground-truth interfaces (verified against code 2026-07-18; two audits), hard-mode-launcher Implementation Plan (next release · container profile shipped), Self-review, Task 1: shared launcher resolver (`lib/launch.sh`), Task 2: per-vendor worker command builder (`lib/worker-cmd.sh`) (+9 more)

### Community 333 - "M2-concurrency"
Cohesion: 0.22
Nodes (17): 10. Bounded symbolic (Apalache) results — orchestrator-run, 1. What is modelled and how to run the checks, 2. Invariants in plain English, 3. Method, honestly, 4. The check-then-act counterexample, 5. Confirmation the atomic primitive holds, 6. Lock-ordering analysis and discipline, 7. Abstractions (+9 more)

### Community 334 - "spec"
Cohesion: 0.22
Nodes (17): File inventory: openspec/changes/decision-lineage-and-telemetry/specs/decision-lineage/spec.md, ADDED Requirements, Requirement: audit decisions enter the event log, Requirement: decision events extend the vocabulary additively, Requirement: findings are individually recorded and their outcome is recorded later, Requirement: gate decisions enter the event log, Requirement: recorded payloads carry references, never contents, Scenario: a diff is identified without being copied (+9 more)

### Community 335 - "spec"
Cohesion: 0.22
Nodes (17): File inventory: openspec/changes/decision-lineage-and-telemetry/specs/run-telemetry/spec.md, ADDED Requirements, Requirement: a per-run metrics rollup is derived from the event log, Requirement: an unmeasured cost is recorded as unmeasured, never as zero, Requirement: every recorded metric ships with its companion number, Requirement: phase timing is recorded per round, Requirement: telemetry failure never changes an outcome, Requirement: token counts, cost and model identity are recorded per round (+9 more)

### Community 336 - "spec"
Cohesion: 0.22
Nodes (17): File inventory: openspec/changes/graph-context-builder/specs/consumption/spec.md, ADDED Requirements, Graph-context consumption specification, Requirement: citation verification is closed and model-free, Requirement: context output is replayable, Requirement: context selection is deterministic and bounded, Requirement: every served edge has stable citation identity, Requirement: Foreman builds context from qualified graph authority (+9 more)

### Community 337 - "tasks"
Cohesion: 0.22
Nodes (17): File inventory: openspec/changes/lock-primitive-hardening/tasks.md, T10 -- the compaction race, T11 -- per-lock, owner-aware reclamation (audit finding 6), T12 -- flat locking, chosen over ordered nesting (audit finding 6), T13 -- operational note carried from the formal work, T14 -- wire the mechanism to the verdict, and make Git-Bash reachable (RECONCILE R4, re-audit N3), T15 -- one refusal shape, six ordered causes, T1 — the shared lock helper (+9 more)

### Community 338 - "spec"
Cohesion: 0.22
Nodes (17): File inventory: openspec/changes/profile-bound-lane-admission/specs/profile-bound-lane-admission/spec.md, ADDED Requirements, Requirement: lane admission binds to one external credential profile, Requirement: lane admission performs no live vendor probe, Requirement: live lane exports only the verified vendor home, Requirement: live lane uses profile admission before side effects, Requirement: R7B2 keeps leasing out of scope, Requirement: worktree creation does not provision credential homes (+9 more)

### Community 339 - "spec"
Cohesion: 0.22
Nodes (17): File inventory: openspec/changes/profile-use-leasing/specs/profile-use-leasing/spec.md, ADDED Requirements, Requirement: holder is a tracked Node.js runtime, Requirement: lease authority is external and fail closed, Requirement: lease binds admission to use, Requirement: lease refusal precedes existing durable lane effects, Requirement: profile use is exclusive across worktrees, Requirement: scoped holder spans the complete lane lifecycle (+9 more)

### Community 340 - "qdrant-memory-index.test / qdrant-memory-index"
Cohesion: 0.24
Nodes (9): File inventory: packages/memory/src/qdrant-memory-index.test.ts, QdrantApplyV1, QdrantQualificationV1, QdrantQueryV1, FixedEmbedding, qualification(), RecordingPort, retract() (+1 more)

### Community 341 - "architecture-git"
Cohesion: 0.30
Nodes (16): File inventory: packages/policy/src/architecture-git.ts, ArchitectureGitError, bindGitCommandForTest(), cancelOwnedGitChild(), currentGitCommandBinding(), gitBytesEffect(), GitCommandBinding, GitRunOk (+8 more)

### Community 342 - "SKILL"
Cohesion: 0.22
Nodes (17): File inventory: skills/superpowers/skills/finishing-a-development-branch/SKILL.md, Common Mistakes, Finishing a Development Branch, Option 1: Merge Locally, Option 2: Push and Create PR, Option 3: Keep As-Is, Option 4: Discard, Overview (+9 more)

### Community 343 - "SKILL"
Cohesion: 0.22
Nodes (17): File inventory: skills/superpowers/skills/systematic-debugging/SKILL.md, Common Rationalizations, Overview, Phase 1: Root Cause Investigation, Phase 2: Pattern Analysis, Phase 3: Hypothesis and Testing, Phase 4: Implementation, Quick Reference (+9 more)

### Community 344 - "CLAUDE_MD_TESTING"
Cohesion: 0.22
Nodes (17): File inventory: skills/superpowers/skills/writing-skills/examples/CLAUDE_MD_TESTING.md, Documentation Variants to Test, Expected Results, Next Steps, NULL (Baseline - no skills doc), Scenario 1: Time Pressure + Confidence, Scenario 2: Sunk Cost + Works Already, Scenario 3: Authority + Speed Bias (+9 more)

### Community 345 - "evidence-mechanism"
Cohesion: 0.55
Nodes (17): File inventory: tests/probes/evidence-mechanism.sh, case_content_blindspot(), case_deletion(), case_flags(), case_harness_nonzero(), case_rename(), case_roots(), case_shellcheck() (+9 more)

### Community 346 - "typescript-conventions / AGENTS"
Cohesion: 0.21
Nodes (12): Foreman repository instructions, Iron Rule: Node.js and TypeScript, Node.js 24 TypeScript runtime, File inventory: AGENTS.md, File inventory: plugins/foreman-qa/skills/foreman-code-quality/references/typescript-conventions.md, Compatibility adapters, Effect ownership, Failures at API boundaries (+4 more)

### Community 347 - "REPORT"
Cohesion: 0.23
Nodes (16): 1. Apply three editorial reports' findings, 2. Fix every factual claim the fact-check pass flagged, 3. Add tests/readme-structure.bats, 4. Verify every command in the README actually runs, 5. Unverifiable claims (marked, not left asserted), 6. Docs gate clean (markdownlint-cli2, codespell, lychee), 7. Deferred editorial work, Checker soundness (observed fail before trust) (+8 more)

### Community 348 - "REPORT"
Cohesion: 0.23
Nodes (16): Audit verdict + finding recorded, Captured live output, Emission safety (D7 / D9 dogfood), Gate decision recorded (PASS), Gate still passes when emission fails, Known-bad falsification (standing rule 2), Modified, New (+8 more)

### Community 349 - "ADAPTER-EVIDENCE / README"
Cohesion: 0.20
Nodes (16): Adopt Pel; keep model differences in profiles, Anthropic: Messages API and Claude Code/Agent SDK, Exact model profiles, Four transport designs, Google: Interactions API and Gemini CLI, Model adapter evidence for the Pel release, OpenAI: Responses API and Codex protocol, Pel host adapter contract (+8 more)

### Community 350 - "openai-background.raw / openai-streaming"
Cohesion: 0.19
Nodes (13): Background mode, Cancelling a background response, Limits, Polling background responses, Streaming a background response, Advanced use cases, Enable streaming, Moderation risk (+5 more)

### Community 351 - "2026-07-15-foreman-enhancement"
Cohesion: 0.22
Nodes (16): Execution through foreman (approach A), Foreman Skill Enhancement Implementation Plan, Global Constraints, ... run grok ..., Self-review notes, Task 1 (CS1): Harden implementer agent contracts, Task 2 (CS1): Standing constraints in spec template + lane known-limits table, Task 3 (CS2): bats harness bootstrap + wt-new suite (+8 more)

### Community 352 - "2026-07-19-v0281-field-fixes"
Cohesion: 0.23
Nodes (16): Acceptance, File structure, Global constraints, Ground-truth interfaces (verified 2026-07-19), Self-review, Task 1: bugeventlog.md lint cleanup (unblocks docs-check), Task 2: install.ps1 — native junction (no cmd-shelling), Task 3: windows-latest CI smoke test (+8 more)

### Community 353 - "2026-08-07-v030-w0-unblock"
Cohesion: 0.23
Nodes (16): Corrections recorded during execution, 2026-08-07, Execution order, Exit criteria for W0, fix, test, PR, merge, Global Constraints, Task 0: Produce Windows full-suite evidence, Task 1: Make the pass baseline platform-keyed, Task 2: Correct the TEST_GATE_MODE default comment (+8 more)

### Community 354 - "2026-07-15-durable-lanes-design"
Cohesion: 0.23
Nodes (16): 1. Durable event log (on-disk source of truth), 2. Continuous worktree checkpoints (git plumbing), 3. Reasoning-stream persistence, 4. Transport — NATS / JetStream (primary), 5. Stall watchdog + alerts, 6. Resume, Architecture, Components (files) (+8 more)

### Community 355 - "2026-08-11-sessiondb-port-unification-design"
Cohesion: 0.23
Nodes (16): 1. v1 format reader, 2. Model reconciliation, 2a. Supersession is one-to-many, 3. Durability, 4. Recovery payload, 5. Write-path validation, Cutover, Design (+8 more)

### Community 356 - "spec"
Cohesion: 0.21
Nodes (16): home_charl_fm_wt_foreman_dsl_release_openspec_changes_archive_2026_07_17_el_emit_spawn_reduction_specs_eventlog_d_rd_md, home_charl_fm_wt_foreman_dsl_release_openspec_changes_archive_2026_07_17_el_emit_spawn_reduction_specs_eventlog_f_md, home_charl_fm_wt_foreman_dsl_release_openspec_changes_archive_2026_07_17_el_emit_spawn_reduction_specs_eventlog_f_seqf_md, File inventory: openspec/changes/archive/2026-07-17-el-emit-spawn-reduction/specs/eventlog/spec.md, MODIFIED Requirement: el_emit assigns monotonic non-duplicate sequence numbers, MODIFIED Requirement: el_emit emits one byte-identical JSON event line, MODIFIED Requirement: el_emit ensures the run directory without a redundant spawn, Scenario: append failure leaves a gap, never a duplicate (eventlog.bats:146) (+8 more)

### Community 357 - "design / proposal"
Cohesion: 0.19
Nodes (14): home_charl_fm_wt_foreman_dsl_release_openspec_changes_archive_2026_08_01_wsl_seam_doctrine_withdrawn_x_md, File inventory: openspec/changes/archive/2026-08-01-wsl-seam-doctrine-withdrawn/design.md, File inventory: openspec/changes/archive/2026-08-01-wsl-seam-doctrine-withdrawn/proposal.md, File inventory: openspec/changes/archive/2026-08-01-wsl-seam-doctrine-withdrawn/tasks.md, Approach, Citations (load-bearing), Design — wsl-seam-doctrine, Key decision (+6 more)

### Community 358 - "transformers-embedding / index"
Cohesion: 0.30
Nodes (13): File inventory: packages/memory/src/index.ts, File inventory: packages/memory/src/transformers-embedding.test.ts, File inventory: packages/memory/src/transformers-embedding.ts, createTransformersEmbeddingV1(), isContained(), normalizeTransformersEmbeddingOutputV1(), PINNED_TRANSFORMERS_MODEL_V1, pinnedTransformersPipelinePlanV1 (+5 more)

### Community 359 - "projection-epoch.test"
Cohesion: 0.24
Nodes (8): File inventory: packages/memory/src/projection-epoch.test.ts, catchUp(), Embedding, index(), lease(), Port, QUALIFICATION, record()

### Community 360 - "round-reducer.test / round-contract"
Cohesion: 0.29
Nodes (16): File inventory: packages/orchestration/src/round-reducer.test.ts, absentReportSnapshot(), attemptId, completedOutcome(), digest, ev(), identity, incompleteOutcome() (+8 more)

### Community 361 - "architecture-evaluate / architecture-extensions"
Cohesion: 0.37
Nodes (16): File inventory: packages/policy/src/architecture-evaluate.ts, blobKey(), checkGeneratedJs(), checkPath(), checkTypeScript(), DEFAULT_IDENTITY, evaluateArchitecturePolicy(), EvaluateInput (+8 more)

### Community 362 - "eventlog / nats-bridge"
Cohesion: 0.28
Nodes (15): File inventory: skills/foreman/scripts/lib/eventlog.sh, File inventory: skills/foreman/scripts/lib/nats-bridge.sh, el_attempt_new(), el_compact(), el_cursor_commit(), el_cursor_get(), el_init(), el_read() (+7 more)

### Community 363 - "site-patterns"
Cohesion: 0.23
Nodes (16): File inventory: skills/scrapling/references/site-patterns.md, Angular institutional SPA (ich.org, iprp.global), API 端点 (REST/GraphQL), arXiv 摘要页 (arxiv.org/abs/*), Discourse 论坛 (linux.do, meta.discourse.org 等), GitHub Issue/PR 正文 vs 评论（重要区分）, GitHub Raw 源码端点 (raw.githubusercontent.com), Justia case pages and embedded opinions (law.justia.com) (+8 more)

### Community 364 - "2026-06-10-visual-companion-auth-hardening-design"
Cohesion: 0.23
Nodes (16): File inventory: skills/superpowers/docs/superpowers/specs/2026-06-10-visual-companion-auth-hardening-design.md, 1. Bootstrap Keyed Loads, 2. WebSocket Same-Origin Enforcement, 3. Helper Reconnect Credential, 4. `/files/*` Containment, 5. Leak-Reduction Headers, 6. Gitignore Durable Session State, 7. Test Stability And Lint (+8 more)

### Community 365 - "2026-06-11-visual-companion-final-hardening-fixup-design"
Cohesion: 0.23
Nodes (16): File inventory: skills/superpowers/docs/superpowers/specs/2026-06-11-visual-companion-final-hardening-fixup-design.md, 1. Rebase Onto Current `dev`, 2. Root Screen Containment, 3. Fallback Token Isolation, 4. Stop-Server Ownership Proof, 5. Test Hardening, 6. Docs And PR Consistency, Acceptance Criteria (+8 more)

### Community 366 - "SKILL"
Cohesion: 0.23
Nodes (16): File inventory: skills/superpowers/skills/dispatching-parallel-agents/SKILL.md, 1. Identify Independent Domains, 2. Create Focused Agent Tasks, 3. Dispatch in Parallel, 4. Review and Integrate, Agent Prompt Structure, Common Mistakes, Dispatching Parallel Agents (+8 more)

### Community 367 - "root-cause-tracing"
Cohesion: 0.23
Nodes (16): File inventory: skills/superpowers/skills/systematic-debugging/root-cause-tracing.md, 1. Observe the Symptom, 2. Find Immediate Cause, 3. Ask: What Called This?, 4. Keep Tracing Up, 5. Find Original Trigger, Adding Stack Traces, Finding Which Test Causes Pollution (+8 more)

### Community 368 - "persuasion-principles"
Cohesion: 0.23
Nodes (16): File inventory: skills/superpowers/skills/writing-skills/persuasion-principles.md, 1. Authority, 2. Commitment, 3. Scarcity, 4. Social Proof, 5. Unity, 6. Reciprocity, 7. Liking (+8 more)

### Community 369 - "RESEARCH_REPORT"
Cohesion: 0.24
Nodes (15): Budgets, observability, and evaluation, CLI compatibility matrix, Cross-CLI Council: compatibility and production best practices, Evidence artifacts, Human-in-the-loop, Key risks and open compatibility tests, Orchestration and state, Plugin and MCP packaging (+7 more)

### Community 370 - "spec"
Cohesion: 0.24
Nodes (15): ADDED Requirements, Purpose, Requirement: Approval binds exact normalized action data, Requirement: Authority changes create approved amendments, Requirement: Commitment decisions fail closed, Requirement: Every model-bound field has an authority class, Requirement: Side-effect states are explicit, Requirement: Task contracts are immutable and complete (+7 more)

### Community 371 - "grok-tools / grok-structured"
Cohesion: 0.23
Nodes (15): developers_tools_advanced_usage_md, developers_tools_function_calling_md, [Combining with Built-in Tools](#combining-with-built-in-tools), [Complete Vercel AI SDK Example](#complete-vercel-ai-sdk-example), [Defining Tools with Pydantic](#defining-tools-with-pydantic), [Function Calling](#function-calling), [Handling Tool Calls](#handling-tool-calls), [How It Works](#how-it-works) (+7 more)

### Community 372 - "storage-port"
Cohesion: 0.24
Nodes (15): Canonical encoding, Conformance, Port 1 — `SessionStore` (system of record), Port 2 — `MemoryIndex` (derived projection), Redaction is subtractive, Review, Snapshot import, Storage implementations (+7 more)

### Community 373 - "AUDIT-sol-L1-r2"
Cohesion: 0.24
Nodes (15): Final disposition, H1 — Guard totality and exclusivity, H2 — Aggregate filesystem support, H3 — Operation failures versus timeout, H4 — Cleanup traps and exactly-one release, H5 — Re-source state preservation, HIGH — flock acquisition destroys caller-owned file descriptor 3, HIGH — wrapper overwrites caller/command traps instead of composing or restoring them (+7 more)

### Community 374 - "REPORT"
Cohesion: 0.24
Nodes (15): 1. Implement `skills/foreman/scripts/lib/evidence.sh`, 2. Untracked-directory collapse (central claim), 3. Deletion changes the digest, 4. Rename decomposes into absent + present, 5. Unreadable path yields UNCOMPUTABLE, not absent, 6. Non-git work root INCONCLUSIVE vs non-git artifact root OK, 7. Content change with unchanged status string, 8. shellcheck clean (+7 more)

### Community 375 - "task-1-report"
Cohesion: 0.24
Nodes (15): 1. Step 1 numbers — observed against expected, 2. Step 2 output, 3. Step 3 — how the union was built, 4. Step 4 output — the acceptance test, 5. Step 5 — install and commit, 6. Step 6 — clear the damaged index, 7. Step 7 — close the obligation, 8. Items not verified (+7 more)

### Community 376 - "v0.3.0-stale-log"
Cohesion: 0.24
Nodes (15): A. Authority documents that contradict shipped reality, B. Stale migration ledger, C. OpenSpec package sprawl, Cross-cutting root cause, D1 — Merged, zero unique commits, safe to delete once recovery owner is recorded, D2 — Unmerged, carry unique commits, need a keep/kill decision, D3 — Branch naming, D. Branch sprawl (+7 more)

### Community 377 - "claude-fable / claude-fable-card"
Cohesion: 0.22
Nodes (15): Availability, Capabilities, claude-fable-card, Claude Fable 5.1 and Claude Mythos 5.1, Claude Fable 5.1 profile, Claude Fable 5.1Latest, How it compares, Model IDs (+7 more)

### Community 378 - "claude-tools"
Cohesion: 0.24
Nodes (16): Basic usage, Best practices for tool definitions, Controlling Claude's output, Define tools, Example of a good tool description, Example poor tool description, Example simple tool definition, Forcing tool use (+8 more)

### Community 379 - "2026-08-07-v030-w1-regime"
Cohesion: 0.24
Nodes (15): Branch placement, Exit criteria for W1, Global Constraints, Starting state, measured 2026-08-07, Task 1: Controls for the `tests/run.sh` gates, Task 2: Controls for the `env/tool-check.sh` gates, Task 3: Controls for the CI workflow gates, Task 4: Controls for the remaining single gates (+7 more)

### Community 380 - "2026-08-17-v031-closeout"
Cohesion: 0.24
Nodes (15): Completion record, File Structure, Global Constraints, Measured starting state, Self-review notes, Task 1: Negative control for the conformance suite, Task 2: FilesOnlySessionStore, Task 3: Backend factory (+7 more)

### Community 381 - "2026-07-19-v029-wsl-compat-design"
Cohesion: 0.23
Nodes (15): Acceptance, Evidence base (per theme, with the load-bearing citations), foreman v0.2.9 — WSL compatibility (design), P1 — wsl-launcher-shipped (BLOCKER; capability `launcher-dist`), P2 — crlf-extensionless-hardening (BLOCKER; capability `line-endings`), P3 — wsl-preflight (BLOCKER/MAJOR; capability `wsl-preflight`), P4 — wsl-tool-path-persistence (MAJOR; capability `environment`), P5 — wsl-ci-parity (MAJOR; capability `ci`) (+7 more)

### Community 382 - "proposal / tasks"
Cohesion: 0.21
Nodes (14): home_charl_fm_wt_foreman_dsl_release_openspec_changes_archive_2026_07_17_el_emit_spawn_reduction_d_rd_md, home_charl_fm_wt_foreman_dsl_release_openspec_changes_archive_2026_07_17_el_emit_spawn_reduction_f_md, File inventory: openspec/changes/archive/2026-07-17-el-emit-spawn-reduction/proposal.md, File inventory: openspec/changes/archive/2026-07-17-el-emit-spawn-reduction/tasks.md, Change: el_emit spawn reduction, Impact, Out of scope (deferred to v0.2.5), What changes (+6 more)

### Community 383 - "design"
Cohesion: 0.23
Nodes (15): home_charl_fm_wt_foreman_dsl_release_openspec_changes_archive_2026_07_17_el_emit_spawn_reduction_f_seqf_md, home_charl_fm_wt_foreman_dsl_release_openspec_changes_archive_2026_07_17_el_emit_spawn_reduction_z_line_md, File inventory: openspec/changes/archive/2026-07-17-el-emit-spawn-reduction/design.md, Combined result (the full new L20–22 region + L40–41 + L50), Current `el_emit` (relevant lines, eventlog.sh), Design — el_emit spawn reduction, Errexit context (why the F2 guard shape is load-bearing), F1 — CR strip (L50) (+7 more)

### Community 384 - "README"
Cohesion: 0.24
Nodes (15): File inventory: launcher/README.md, Build, CLI contract (frozen), Containment flags (Node only), `--detach`, Exit codes at a glance, foreman-launch, Graded stop (binding contract — no cooperative phase) (+7 more)

### Community 385 - "spec"
Cohesion: 0.24
Nodes (15): File inventory: openspec/changes/external-memory-index/specs/external-memory-index/spec.md, ADDED Requirements, External MemoryIndex specification, Requirement: Deterministic project-bound points, Requirement: Isolated projection epochs, Requirement: Optional external projection, Requirement: Qualified Qdrant boundary, Requirement: Strong completed operations (+7 more)

### Community 386 - "spec"
Cohesion: 0.24
Nodes (15): File inventory: openspec/changes/lane-ownership-and-reaping/specs/lane-ownership/spec.md, ADDED Requirements, Requirement: a lane that never launched its vendor is a stall, not a silence, Requirement: a liveness predicate is demonstrated against both a wedged and a healthy lane, Requirement: every lane and watchdog carries an owner tag, Requirement: headless vendor rounds detach stdin, Requirement: lane liveness is judged on process state and CPU, never on existence, Scenario: a candidate predicate that flags a healthy lane is rejected (+7 more)

### Community 387 - "spec"
Cohesion: 0.24
Nodes (15): File inventory: openspec/changes/project-registry/specs/project-registry/spec.md, ADDED Requirements, Project registry specification, Requirement: Backward-compatible registration, Requirement: Closed registry storage, Requirement: Honest freshness, Requirement: No custom signing protocol, Requirement: Project-bound projections (+7 more)

### Community 388 - "spec"
Cohesion: 0.24
Nodes (15): File inventory: openspec/changes/resume-count-events-typescript/specs/resume-count-events/spec.md, ADDED Requirements, Requirement: failures are typed and non-leaking, Requirement: R5C stays inside the TypeScript event-log boundary, Requirement: reservation enforces the bounded budget, Requirement: reservation is one atomic journal transaction, Requirement: resume count history is closed and consecutive, Requirement: resume count reservation is attempt-bound (+7 more)

### Community 389 - "spec"
Cohesion: 0.24
Nodes (15): File inventory: openspec/changes/resume-supervisor-typescript/specs/resume-supervisor/spec.md, ADDED Requirements, Requirement: queue execution preserves the stored round, Requirement: restore binds the selected checkpoint and reservation, Requirement: resume-budget inspection uses one validator, Requirement: supervisor decisions are fail-safe, Requirement: the supervisor runtime is Node.js TypeScript, Scenario: a dirty worktree is selected (+7 more)

### Community 390 - "spec"
Cohesion: 0.24
Nodes (15): File inventory: openspec/changes/work-dag-projection/specs/work-plane/spec.md, ADDED Requirements, Requirement: Foreman projects durable events without model authorship, Requirement: invalid input fails without publication, Requirement: publication and checking are explicit, Requirement: the projection is deterministic, Requirement: the work record is closed and honest, Scenario: a hand edit is detected (+7 more)

### Community 391 - "captured-facts"
Cohesion: 0.23
Nodes (14): File inventory: skills/foreman/references/captured-facts.md, File inventory: skills/foreman/templates/captured-facts.md, Artifact contract, Captured-facts convergence, Inline facts into implementation specs, Worked discovery-derived sub-spec, BH-001 — Behavior name, Captured facts (+6 more)

### Community 392 - "2026-03-11-zero-dep-brainstorm-server-design"
Cohesion: 0.24
Nodes (15): File inventory: skills/superpowers/docs/superpowers/specs/2026-03-11-zero-dep-brainstorm-server-design.md, Application-Level WebSocket Messages, Architecture, Configuration, Error Handling, File Watching, HTTP Server, Motivation (+7 more)

### Community 393 - "lane-ownership-harness"
Cohesion: 0.46
Nodes (15): File inventory: tests/lane-ownership-harness.sh, assert_contains(), case_claim_survives_reexec(), case_foreign_safety(), case_harness_nonzero(), case_healthy_negatives(), case_never_launched(), case_no_output_hash() (+7 more)

### Community 394 - "lanectl"
Cohesion: 0.35
Nodes (15): File inventory: tools/lanectl.sh, cmd_adopt(), cmd_claim(), cmd_launch(), cmd_progress(), cmd_ps(), cmd_reap(), cmd_sweep() (+7 more)

### Community 395 - "spec"
Cohesion: 0.12
Nodes (15): ADDED Requirements, Requirement: Explicit deferrals, Requirement: Graph-independent operation, Requirement: Release baseline and authority, Requirement: Reproducible and attestable appliance, Requirement: Staged rollout and rollback, Scenario: A deferred feature appears in an implementation proposal, Scenario: A post-release regression occurs (+7 more)

### Community 396 - "security-spec-review"
Cohesion: 0.13
Nodes (15): 4. Provenance requirements and scenarios, Requirement: Claim support is verified independently (PROV-06), Requirement: Derived claims preserve candidate attribution (PROV-07), Requirement: Every artifact has a stable identity (PROV-01), Requirement: Lineage uses PROV-compatible relations (PROV-02), Requirement: Material claims map to exact evidence (PROV-05), Requirement: Provenance status is not truth status (PROV-04), Requirement: Transformations are reproducible (PROV-03) (+7 more)

### Community 397 - "RESEARCH_REPORT"
Cohesion: 0.26
Nodes (14): 1. Diversity helps, but model-family diversity matters more than role-play, 2. Debate can help, but its marginal value is conditional and often overstated, 3. Long debate is unsafe as a default, 4. A chairman or judge is a biased sensor, not ground truth, 5. Rank before fusion, 6. Confidence is useful only after calibration, 7. Majority is not quorum when errors are correlated, Bottom line (+6 more)

### Community 398 - "2026-08-01-council-foundation"
Cohesion: 0.26
Nodes (14): Cold-review API corrections, Council Foundation Implementation Plan, File map, Global Constraints, Self-review coverage, Task 1: Bootstrap the strict workspace through a failing workspace test, Task 2: Add branded identifiers and authority schemas, Task 3: Add versioned lifecycle commands, events, and envelopes (+6 more)

### Community 399 - "design"
Cohesion: 0.26
Nodes (14): 1. Define Council ACE Profile 1 as a strict ACE subset, 2. Keep instructions separate from data and evidence, 3. Use one deterministic preprocessing pipeline, 4. Use a separate tool-free model canary, 5. Separate attempt transport state from deliberation outcome, 6. Keep retry and provider ownership in Foreman, Context, Decisions (+6 more)

### Community 400 - "spec"
Cohesion: 0.26
Nodes (14): MODIFIED Requirements, Requirement: Invocation is shell-free and reproducible, Requirement: Terminal classification uses compound evidence, Scenario: An interim abstention precedes cancellation, Scenario: Claude canary uses stdin transport, Scenario: Claude schema output reports tool_use without tools, Scenario: Codex canary uses stdin and schema-file transport, Scenario: Codex four-event success stream (+6 more)

### Community 401 - "tasks"
Cohesion: 0.26
Nodes (14): 10. Council Deliberation, 11. Audit, Replay, and Incidents, 12. MCP Control Plane and Native Plugins, 13. Evaluation and Release, 1. Workspace and Architecture Guardrails, 2. Versioned Contracts and Pure Domain, 3. Effect Application Shell, 4. Durable Storage, Artifacts, and Recovery (+6 more)

### Community 402 - "spec-correctness.test / spec-correctness"
Cohesion: 0.22
Nodes (14): InventedCompletionV1, SpecCorrectnessEvaluationResultV1, SpecCorrectnessItemResultV1, SpecCorrectnessProviderResponseV1, acceptResponse(), changesResponse(), cleanMetrics, defectItem() (+6 more)

### Community 403 - "grok-reasoning / grok-pricing"
Cohesion: 0.24
Nodes (14): developers_model_capabilities_text_multi_agent_md, developers_model_capabilities_text_reasoning_md, [Effort levels](#effort-levels), [Encrypted Reasoning Content](#encrypted-reasoning-content), [Key Features](#key-features), [Model Capabilities](#model-capabilities), [Multi-agent model](#multi-agent-model), [Reasoning](#reasoning) (+6 more)

### Community 404 - "session-store-ontology-links"
Cohesion: 0.26
Nodes (14): 1. `measured_sha` → `Commit` (the join key that already exists), 2. `scope_paths` → `about: Set<Entity>` (the link only SQLite can supply), 3. `facts.superseded_by` → `Supersession` (SQLite's version is degenerate), 4. `obligations` → `Finding` / `Claim.contradicts` (the reconciliation gap), Linking the session store (SQLite) and the ontology (TerminusDB), Ordered work, Projection trigger, The boundary (+6 more)

### Community 405 - "2026-08-07-architecture-policy-options"
Cohesion: 0.26
Nodes (14): 1. Reproduction, 2. Claim-by-claim verification, 3. Remediation options, 4. Recommendation, Architecture Policy Deadlock on PR #27 (v0.3.0) — Remediation Options, Claim 1 — "No `bats` shebang interpreter is recognized, so any edit to any real `.bats` file trips it." **Overstated — refuted experimentally.**, Claim 2 — "No path to add a brand-new compliant thin-adapter `.sh` file — new files are extension-banned before the grammar check is reachable." **Confirmed exactly as stated.**, Claim 3 — "It blanket-denies any edit at all to the legacy `wt-new.sh`." **Confirmed in effect.** (+6 more)

### Community 406 - "2026-08-07-windows-suite-measurement"
Cohesion: 0.26
Nodes (14): Commits, Complete list of slices whose `fail` column is not 0, Failure-cause frequency (missing tooling vs. real defects), How the data was recovered, Run, Slice count, Summary, The artifact-publish bug found by this run, and its fix (+6 more)

### Community 407 - "claude-thinking"
Cohesion: 0.26
Nodes (15): Cost control, Effort changes invalidate the prompt cache, Effort levels, How Claude decides when to think, Mechanics, Next steps, Per-message steering, Pricing (+7 more)

### Community 408 - "gemini-interactions"
Cohesion: 0.26
Nodes (15): Best practices, Data storage and retention, Feature guides, Feedback, Get started, How the Interactions API works, Interactions API, Limitations (+7 more)

### Community 409 - "openai-astra-guide"
Cohesion: 0.26
Nodes (14): GPT-6 Astra behavior, Initiative and follow-through, Instruction following, Introduction, Migrate with Codex, Migration quickstart, Personality and writing style, Prompting best practices (+6 more)

### Community 410 - "openai-astra-guide.raw"
Cohesion: 0.26
Nodes (14): GPT-6 Astra behavior, Initiative and follow-through, Instruction following, Introduction, Migrate with Codex, Migration quickstart, Personality and writing style, Prompting best practices (+6 more)

### Community 411 - "codex-review"
Cohesion: 0.26
Nodes (14): Critical, Findings, FOREMAN_REPORT - v0.3.0 session-transport series (cross-vendor audit), High, Low, Medium, Merge Strategy Recommendation, MUST-FIX-BEFORE-MERGE (+6 more)

### Community 412 - "FINAL-opus"
Cohesion: 0.26
Nodes (14): Blocked vs fixable in flight, Blocked — work cannot start, or would build the wrong thing, Cross-fix contradictions introduced by concurrent editing, Decision, DO NOT DISPATCH S1., FINAL-opus.md — Foreman v0.2.9 final audit lane, Finding-rate judgement, Fixable in flight — a worker proceeds and the gap closes (+6 more)

### Community 413 - "2026-07-18-v0275-1-lifecycle-three-stage"
Cohesion: 0.26
Nodes (14): Acceptance, File structure, Global constraints (apply to every task), lifecycle-three-stage Implementation Plan (v0.2.7.5 · package 1/7), Self-review, Task 0: determine each vendor's real, NON-BILLING auth probe (empirical), Task 1: tool-check emits per-vendor auth state, Task 2: a lane-scoped readiness verdict (+6 more)

### Community 414 - "2026-08-11-sessiondb-port-unification"
Cohesion: 0.26
Nodes (14): File Structure, Global Constraints, Notes for the implementer, SessionDB Port Unification Implementation Plan, Task 1: Golden oracle, Task 2: v1 sidecar reader, Task 3: Rebuild the database from the canonical sidecar, Task 4: Durability (+6 more)

### Community 415 - "2026-07-19-empirical-workloads-design"
Cohesion: 0.26
Nodes (14): Acceptance, C1 — Spec-determinability triage gate (coded; capability `spec-triage`), C2 — `foreman-discover` workflow + agent-def (new, top-model; capability `discover-lane`), C3 — Captured-facts convergence artifact (capability `captured-facts`), C4 — Post-discovery re-decomposition (capability `spec-triage`, doctrine only), C5 — Workload-fit accounting (capability `workload-fit`), foreman — empirical-workload support: DISCOVER → CONVERGE → IMPLEMENT (design), Honest scope (post-audit reframe) (+6 more)

### Community 416 - "tasks"
Cohesion: 0.24
Nodes (14): home_charl_fm_wt_foreman_dsl_release_openspec_changes_openspec_superpowers_convergence_entry_md, home_charl_fm_wt_foreman_dsl_release_openspec_changes_openspec_superpowers_convergence_future_owner_md, File inventory: openspec/changes/openspec-superpowers-convergence/tasks.md, 1. Closed OpenSpec workflows, 2. Release coverage policy, 3. Exact release admission policy, 4. ExecutionContractV2 manifest and pure policy, 5. Atomic family ledger and CLI (+6 more)

### Community 417 - "design"
Cohesion: 0.26
Nodes (14): File inventory: openspec/changes/round-ownership-default/design.md, Alternatives considered and REJECTED, Design — round-ownership-default, Formal verification, 2026-07-28: the fix is abandoned at the first auto-resume, Migration: what actually breaks, and why it is safe, Ordering, Risks, Standing limits of this evidence (+6 more)

### Community 418 - "spec"
Cohesion: 0.26
Nodes (14): File inventory: openspec/changes/spec-triage-gate/specs/spec-triage/spec.md, ADDED Requirements, Requirement: after discovery converges, the gate admits — but does not compel — offloading a determined sub-spec (C4 doctrine, not an enforced gate), Requirement: an under-determined spec is refused at all three grok entry points and routed to foreman-discover, Requirement: the declaration alone is not sufficient — the narrow scan also refuses a mis-declared spec, Requirement: the under-determination scan is narrowly anchored — it does not false-positive on legitimately-determined specs, Scenario: a determined spec containing "explore"/"discover the dirty file set" is not refused, Scenario: a mis-declared spec is caught by the scan (+6 more)

### Community 419 - "tasks"
Cohesion: 0.26
Nodes (14): File inventory: openspec/changes/three-outcome-verdicts/tasks.md, T10 -- a separate audit-attempt bound and a terminal state, T11 -- close the gate-to-merge TOCTOU, T12 -- WARNING is decided by policy, T1 — confirm the premises before changing anything, T2 — the verdict artifact, T3 — bound the audit call, T4 — gate: bind the verdict to the attempt and the evaluated tree (+6 more)

### Community 420 - "design"
Cohesion: 0.26
Nodes (14): File inventory: openspec/changes/v030-release-program/design.md, Canonical encoding and derived counts, Closed item-result dispositions, Complete bundle-identity failure rule, Design: v0.3.0 release program, InventedCompletionV1, Outcome rule, Package inventory and ownership (+6 more)

### Community 421 - "design"
Cohesion: 0.26
Nodes (14): File inventory: openspec/changes/v050-release-program/design.md, Authority model, Dependency slices carried from v0.6 packages, Design: Foreman v0.5 release program, Design objective, Endstop family, Exit predicates, Failure and rollback behavior (+6 more)

### Community 422 - "cli / main"
Cohesion: 0.38
Nodes (13): File inventory: packages/graph-store/src/cli.ts, File inventory: packages/graph-store/src/main.ts, CliIo, cmdCapabilities(), cmdContract(), cmdSmoke(), cmdVersionRef(), defaultIo (+5 more)

### Community 423 - "architecture-adapter"
Cohesion: 0.36
Nodes (14): File inventory: packages/policy/src/architecture-adapter.ts, DENY, escapeRegExp(), hasSmuggledOperators(), inspectLaneRunMigrationAdapter(), inspectLaneSuperviseMigrationAdapter(), inspectLegacyAdapter(), inspectPosixShellAdapter() (+6 more)

### Community 424 - "projection-lease"
Cohesion: 0.34
Nodes (6): File inventory: packages/session-store/src/projection-lease.ts, LeaseRow, ProjectionLeasePort, requireNow(), SqliteProjectionLeasePort, SqliteProjectionLeasePortOptions

### Community 425 - "orchestration-hardening"
Cohesion: 0.26
Nodes (15): File inventory: skills/foreman/references/orchestration-hardening.md, 10. Hard mode (`worker-run.sh` + `pr-open.sh`, hard-mode-launcher), 11. Vendor usage reporting (decision-lineage emission), 1. Launcher contract (`launcher/`), 2. `watch.sh` v2 typed-state machine, 3. pueue admission control (`lane-queue.sh`), 4. Vendor config isolation, 5. Merge-freshness gate (`merge-gate.sh`) (+7 more)

### Community 426 - "parallel-worktrees"
Cohesion: 0.26
Nodes (14): File inventory: skills/foreman/references/parallel-worktrees.md, Agent roles, Architect rules (Fable), Branches, Claude Code note, Layout, Lifecycle, Parallel recipe (soft) (+6 more)

### Community 427 - "2026-06-10-visual-companion-auth-hardening"
Cohesion: 0.26
Nodes (14): File inventory: skills/superpowers/docs/superpowers/plans/2026-06-10-visual-companion-auth-hardening.md, File Map, Self-Review Checklist, Task 10: Re-run Security Probes, Task 1: Bootstrap Keyed Root Loads, Task 2: WebSocket Origin Enforcement, Task 3: Helper Uses Stored Key For Reconnect, Task 4: Security Headers (+6 more)

### Community 428 - "2026-06-09-sdd-task-scoped-review-dispatch-design"
Cohesion: 0.26
Nodes (14): File inventory: skills/superpowers/docs/superpowers/specs/2026-06-09-sdd-task-scoped-review-dispatch-design.md, 1. New file: `skills/subagent-driven-development/code-quality-reviewer-prompt.md` becomes self-contained, 2. `skills/subagent-driven-development/spec-reviewer-prompt.md` cleanups, 3. `skills/subagent-driven-development/SKILL.md` controller changes, Cost iterations (post-launch eval economics), Design, Goals, Iterations 4-5 (2026-06-10): variance honesty, structural fixes, positive recipes (+6 more)

### Community 429 - "selftest-test-infrastructure"
Cohesion: 0.50
Nodes (14): File inventory: tests/selftest-test-infrastructure.sh, assert_contains(), assert_status(), check_annual_overdue_report(), check_detection_criterion(), check_fractional_delta_boundary(), check_preconditions(), check_runner() (+6 more)

### Community 430 - "openai-astra.raw / openai-sol.raw"
Cohesion: 0.25
Nodes (13): api_docs_guides_latest_model_md, api_docs_pricing_md, Endpoints, GPT-6 Astra, Model details, Pricing, Rate limits, Snapshots (+5 more)

### Community 431 - "AUDIT-final"
Cohesion: 0.27
Nodes (13): Derivation shape, F1 — BLOCKER — type/error hardening bypasses the appended hooks region, F2 — BLOCKER — PNG cleanup trap replaces Bats' failure-reporting trap, F3 — BLOCKER — the relocation class moved outside the enumerated regions, Final Cold Audit, Findings, Hygiene, Non-vacuity (+5 more)

### Community 432 - "REPORT"
Cohesion: 0.27
Nodes (13): AGENT_TRAPS.md, Files touched this round, Full regression run, Gaps / out of scope, N1 — HIGH. flock acquisition no longer destroys caller FD 3, N2 — HIGH. Traps saved/restored; command cannot clobber cleanup, N3 — MEDIUM. First source ignores inherited hold state, Previously-sound claims (R9) (+5 more)

### Community 433 - "REPORT"
Cohesion: 0.27
Nodes (13): Bats (host mutex: `flock /tmp/foreman-bats.lock`), F1 — reclaim deletion gated on positively selected `mkdir` only, F2 — exclusive owner token; release verifies ownership, F3 — register EEXIST bound to `probe_target`, F4 — existing suites migrated to trust contract, Files touched (this continuation + prior partial), REPORT — L2+L3 integration rework (round 2 continuation), Residual / out of scope (+5 more)

### Community 434 - "v0.2.8.2-cleanup-log"
Cohesion: 0.27
Nodes (13): Current register, Executed exact-release graph replacement, Executed GitHub control-plane cleanup, Executed host-only cleanup, Executed post-Council graph replacement, Executed tracked-document cleanup, Not approved, Preservation (+5 more)

### Community 435 - "openai-sol"
Cohesion: 0.27
Nodes (13): Endpoints, GPT-5.6 Sol, GPT-5.6 Sol profile, Model details, Pricing, Quick comparison, Rate limits, Snapshots (+5 more)

### Community 436 - "research-citations"
Cohesion: 0.27
Nodes (13): codex exec vs codex mcp-server: startup, resume, caching, GPT-5.6 family and effort tiers (launched 2026-07-08/09), LEVERS RANKED (expected wall-clock impact x confidence), Model + effort configuration, Observed latency differences by effort, Q1. OpenAI Codex CLI: model selection, reasoning effort, exec vs mcp-server, Q2. Parallel audit patterns (shard + consolidate), Q3. xAI Grok CLI ("Grok Build") as third audit vendor (+5 more)

### Community 437 - "EDIT-readme-line"
Cohesion: 0.25
Nodes (13): 1. Line Edits, 2.1 The contrastive snap: "X, not Y", 2.2 "Silent" / "silently" as moral intensifier, 2.3 "Never" as sentence engine, 2.4 Em-dash cargo: secondary facts packed into primary sentences, 2. Recurring Tics, 3. Best-Written Passage, 4. Worst-Written Passage (+5 more)

### Community 438 - "2026-08-02-council-review-plane"
Cohesion: 0.27
Nodes (13): Council as the Review Plane for grok-4.5 Lanes Implementation Plan, File Structure, Global Constraints, Self-review, Task 1: Lane review bundle, Task 2: Quorum arithmetic, Task 3: Advisory bridge, fail-closed on authority, Task 4: Third reviewer domain (+5 more)

### Community 439 - "2026-08-02-node-typescript-migration"
Cohesion: 0.27
Nodes (13): Foreman Node.js and TypeScript Migration Plan, Global constraints, Work package 10: convergence, Work package 1: workspace and policy gate, Work package 2: GraphStore, Work package 3: launcher supervision, Work package 4: event log, Work package 5: SessionDB (+5 more)

### Community 440 - "tasks"
Cohesion: 0.27
Nodes (13): File inventory: openspec/changes/archive/2026-07-30-terminusdb-withdrawn-adapter/tasks.md, T10 — Integration notes and docs in-tree, T11 — FINAL GATE (merge criteria), T1 — Package scaffold and HTTP client, T2 — Author encoding and error taxonomy, T3 — normalize_data_version, DataVersionToken, and DiffRef, T4 — CAS wrapper, T5 — Non-empty query wrapper and Path Distinct (+5 more)

### Community 441 - "design"
Cohesion: 0.27
Nodes (13): File inventory: openspec/changes/graph-store-port/design.md, Concurrency, Decision shape, Design — graph-store-port, Historical decision record, Ingest and one-way projection, Port and landed files-only behavior, Query discipline and the permanent competency suite (+5 more)

### Community 442 - "spec"
Cohesion: 0.27
Nodes (13): File inventory: openspec/changes/hermetic-foreman-appliance/specs/hermetic-foreman-appliance/spec.md, ADDED Requirements, Hermetic Foreman appliance specification, Requirement: Dedicated rootless hard-mode engine, Requirement: One control product, Requirement: Optional private semantic memory, Requirement: Pinned OCI build graph, Requirement: Reproducible release evidence (+5 more)

### Community 443 - "sprints"
Cohesion: 0.27
Nodes (13): File inventory: openspec/changes/node-typescript-runtime/sprints.md, Authority rule, M0 — governance and baseline, M1 — workspace, core, and architecture policy, M2 — GraphStore, M3 — launcher, M4 — event log and SessionDB, M5 — release evidence (+5 more)

### Community 444 - "tasks"
Cohesion: 0.27
Nodes (13): File inventory: openspec/changes/node-typescript-runtime/tasks.md, M0 — establish the rule, M1 — workspace and architecture gate, M2 — migrate GraphStore, M3 — migrate launcher supervision, M4A — migrate the event log, M4B — migrate SessionDB, M5 — migrate release evidence modules (+5 more)

### Community 445 - "design"
Cohesion: 0.27
Nodes (13): File inventory: openspec/changes/openspec-superpowers-convergence/design.md, Context, Coverage validation is a pure core with an Effect boundary, Decisions, Design: OpenSpec and Superpowers convergence, Goals and non-goals, Installed runtime inventory is exact, Migration plan (+5 more)

### Community 446 - "spec"
Cohesion: 0.27
Nodes (13): File inventory: openspec/changes/wsl-preflight/specs/wsl-preflight/spec.md, ADDED Requirements, Requirement: the preflight runs before any event-log write and refuses an unsafe FOREMAN_HOME (FOREMAN_HOME only, override available), Requirement: the preflight warns on a stale WSL build, Requirement: the preflight warns on cross-boundary networking and tool-resolution risk, Scenario: a /mnt/* worktree is warned, never refused, Scenario: a native-filesystem FOREMAN_HOME proceeds, Scenario: a Windows-shimmed tool triggers a warning (+5 more)

### Community 447 - "projection-epoch / projection-lease"
Cohesion: 0.29
Nodes (6): File inventory: packages/memory/src/projection-epoch.ts, ProjectionCatchUpBatchV1, ProjectionEpochCoordinator, ProjectionEpochCoordinatorOptions, ProjectionEpochSource, ProjectionLease

### Community 448 - "qdrant-client-port.test"
Cohesion: 0.27
Nodes (5): File inventory: packages/memory/src/qdrant-client-port.test.ts, applyInput(), port(), RecordingClient, ref_qdrant_js_client_rest

### Community 449 - "metrics-lint"
Cohesion: 0.43
Nodes (13): File inventory: skills/foreman/scripts/lib/metrics-lint.sh, ml_blocker_open(), ml_claims_value(), ml_has_companion(), ml_is_uncomputable(), ml_lint_file(), ml_lint_text(), ml_lower() (+5 more)

### Community 450 - "maintenance"
Cohesion: 0.40
Nodes (13): File inventory: skills/foreman/scripts/maintenance.sh, append_item(), cleanup(), directory_hash(), parse_vendored_rows(), render_human(), run_compat(), run_graph() (+5 more)

### Community 451 - "PULL_REQUEST_TEMPLATE"
Cohesion: 0.27
Nodes (13): File inventory: skills/superpowers/.github/PULL_REQUEST_TEMPLATE.md, Does this PR contain multiple unrelated changes?, Environment tested, Evaluation, Existing PRs, Human review, Is this change appropriate for the core library?, New harness support (required if this PR adds a new harness) (+5 more)

### Community 452 - "INSTALL"
Cohesion: 0.27
Nodes (13): File inventory: skills/superpowers/.opencode/INSTALL.md, Getting Help, Installation, Installing Superpowers for OpenCode, Migrating from the old symlink-based install, Plugin not loading, Prerequisites, Skills not found (+5 more)

### Community 453 - "CODE_OF_CONDUCT"
Cohesion: 0.27
Nodes (13): File inventory: skills/superpowers/CODE_OF_CONDUCT.md, 1. Correction, 2. Warning, 3. Temporary Ban, 4. Permanent Ban, Attribution, Contributor Covenant Code of Conduct, Enforcement (+5 more)

### Community 454 - "2026-05-06-lift-drill-into-evals-design"
Cohesion: 0.27
Nodes (13): File inventory: skills/superpowers/docs/superpowers/specs/2026-05-06-lift-drill-into-evals-design.md, Architecture after the move, Background, Branching, Concrete path/config edits, Deletion gate (per bash test), Goals, Lift drill into superpowers as `evals/` — design (+5 more)

### Community 455 - "2026-06-10-positive-instruction-redesign-design"
Cohesion: 0.27
Nodes (13): File inventory: skills/superpowers/docs/superpowers/specs/2026-06-10-positive-instruction-redesign-design.md, Also explicitly not-dropped (tested-and-declined, with data), Audit results (2026-06-10, all ~30 skills + prompt templates), Current state, Micro-test design, Positive-Instruction Redesign of Skill Guidance — Design Spec, PR scoping, Result: writing-plans micro-test (run 2026-06-10, after this spec was written) (+5 more)

### Community 456 - "2026-06-10-strict-cost-sdd-design"
Cohesion: 0.27
Nodes (13): File inventory: skills/superpowers/docs/superpowers/specs/2026-06-10-strict-cost-sdd-design.md, Budget and sequencing, Judgment guardrail (co-invariant with quality), L1 — Plan-side crispness (writing-plans changes; est. −$1.5-3/run, plus variance reduction), L2 — Controller tier (est. −$4-5/run; the biggest single lever, gated hardest), L3 — Reviewer tier (est. −$0.7-1/run; most likely rung to die on the judgment guardrail), L4 — Resident-context diet (est. −$0.5-1/run), L5 — Re-litigations (explicitly flagged, maintainer-vetoed or counter-thesis) (+5 more)

### Community 457 - "lint-shell"
Cohesion: 0.47
Nodes (13): File inventory: skills/superpowers/scripts/lint-shell.sh, add_shell_file(), collect_all_shell_files(), collect_changed_shell_files(), collect_requested_shell_files(), die(), ensure_git_work_tree(), is_shell_file() (+5 more)

### Community 458 - "SKILL"
Cohesion: 0.27
Nodes (13): File inventory: skills/superpowers/skills/writing-plans/SKILL.md, Bite-Sized Task Granularity, Execution Handoff, File Structure, No Placeholders, Overview, Plan Document Header, Remember (+5 more)

### Community 459 - "test-package-codex-plugin"
Cohesion: 0.45
Nodes (13): File inventory: skills/superpowers/tests/codex/test-package-codex-plugin.sh, assert_contains(), assert_equals(), assert_not_matches(), cleanup(), extract_archive(), fail(), list_archive() (+5 more)

### Community 460 - "ci-local"
Cohesion: 0.40
Nodes (13): File inventory: tools/ci-local.sh, gate_bats(), gate_dependencies(), gate_docs(), gate_formal(), gate_hygiene(), gate_install(), gate_lanes() (+5 more)

### Community 461 - "grok-implementer"
Cohesion: 0.29
Nodes (12): Contract, Evidence contract, Footguns (mandatory, measured 2026-09-05), Git discipline (standing rule), Grok Implementer (Foreman), Known limits (Grok headless), Preflight — no silent fallback, Report (+4 more)

### Community 462 - "security-spec-review"
Cohesion: 0.15
Nodes (13): 6. Audit, replay, and incident requirements, Requirement: Audit events use a canonical envelope (AUD-01), Requirement: Audit integrity is independently verifiable (AUD-02), Requirement: Audit storage minimizes sensitive content (AUD-03), Requirement: Replay modes are explicit (AUD-04), Requirement: Replay verifies decision determinism (AUD-05), Requirement: Security incidents stop privilege propagation (AUD-06), Scenario: An event is deleted (+5 more)

### Community 463 - "README"
Cohesion: 0.29
Nodes (12): Core runtime — required, Dependencies — everything required to run Foreman, Docs gate, Gate and development tooling, Locking — read this before changing coreutils, Optional and durable-lane transport, Profiles, Quick start on a fresh host (+4 more)

### Community 464 - "grok-text"
Cohesion: 0.28
Nodes (12): developers_model_capabilities_text_generate_text_md, [Adding encrypted thinking content](#adding-encrypted-thinking-content), [Chaining the conversation](#chaining-the-conversation), [Creating a new model response](#creating-a-new-model-response), [Delete a model response](#delete-a-model-response), [Disable storing previous request/response on server](#disable-storing-previous-requestresponse-on-server), [Generate Text](#generate-text), [Model Capabilities](#model-capabilities) (+4 more)

### Community 465 - "AUDIT-sol"
Cohesion: 0.28
Nodes (12): a) Inventory derivation — FAIL (F1), b) New `100644` directly executed script detection — FAIL for SDD, PASS for the other two families (F1), c) Working-tree CR check and ext4 skip — PARTIAL (F3), Codex Audit -- s1/crlf-extensionless-hardening (bfc8af4..f02f207), d) `.gitattributes` syntax, ordering, and nested interaction — PASS, Detail, e) Mode-only versus content changes — PASS, f) Every SHALL and Scenario checklist — PARTIAL / BLOCKING (+4 more)

### Community 466 - "AUDIT-sol-r3"
Cohesion: 0.29
Nodes (12): Evidence Log, F1 — BLOCKER — newly covered scripts remain non-executable, F2 — BLOCKER — root coverage is still a literal singleton and relocates the hole, F3 — WARNING — index object/type errors are silently converted to exclusion, F4 — BLOCKER — the new PNG test mutates the live worktree/object database and has no failure cleanup, F5 — BLOCKER — Windows carve-out test does not protect the `.bat` or `.cmd` root rules, Findings, Round 3 Audit (+4 more)

### Community 467 - "BRIEF"
Cohesion: 0.29
Nodes (12): 0. Scope boundary — read this before anything else, 1. Objective, 2. Files, 3. Interfaces — the contract, 3a. Public API, 3b. THE SEAM WITH ROUND L2 — important, 3c. Flat locking (T12), 3d. Refusal vocabulary (T15) — exactly six codes, one shape, ordered (+4 more)

### Community 468 - "v0.2.9.0-notes"
Cohesion: 0.29
Nodes (12): Cleanup, Council status, Dogfood, Graph assets, Limits, Live-canary evidence, Product, Providers (+4 more)

### Community 469 - "claude-opus"
Cohesion: 0.29
Nodes (13): Availability, Capabilities, Claude Opus 5 profile, Claude Opus 5Latest, Good to know, How it compares, Model IDs, Overview (+5 more)

### Community 470 - "gemini-pricing"
Cohesion: 0.15
Nodes (12): gemini_api_docs_deprecations_md, gemini_api_docs_embeddings_md, gemini_api_docs_live_md, gemini_api_docs_models_gemini_3_flash_preview_md, gemini_api_docs_models_gemini_3_pro_image_md, gemini_api_docs_models_gemini_embedding_2_md, gemini_api_docs_models_gemini_omni_flash_md, gemini_api_docs_models_gemini_robotics_er_2_preview_md (+4 more)

### Community 471 - "openai-astra"
Cohesion: 0.29
Nodes (12): Endpoints, GPT-6 Astra, GPT-6 Astra profile, Model details, Pricing, Rate limits, Snapshots, Standard (+4 more)

### Community 472 - "openai-sol.raw"
Cohesion: 0.29
Nodes (12): Endpoints, GPT-5.6 Sol, Model details, Pricing, Quick comparison, Rate limits, Snapshots, Standard (+4 more)

### Community 473 - "openai-state"
Cohesion: 0.29
Nodes (12): Compaction, Conversation state, Data retention for model responses, Managing context for text generation, Managing the context window, Manually manage conversation state, Next steps, OpenAI APIs for conversation state (+4 more)

### Community 474 - "openai-state.raw"
Cohesion: 0.29
Nodes (12): Compaction, Conversation state, Data retention for model responses, Managing context for text generation, Managing the context window, Manually manage conversation state, Next steps, OpenAI APIs for conversation state (+4 more)

### Community 475 - "2026-07-18-v0275-3-wsl-reliability-env-refresh"
Cohesion: 0.29
Nodes (12): Acceptance, File structure, Global constraints, Self-review, Task 1: full WSL native provisioner (bootstrap-wsl.sh), Task 2: fix the WSL codex PATH-leak (live bug), Task 3: .wslconfig tuning, Task 4: clock-sync hook (protects the event log) (+4 more)

### Community 476 - "2026-07-18-v0275-4-worktree-hardening"
Cohesion: 0.29
Nodes (12): Acceptance, File structure, Global constraints, Self-review, Task 1: git-guards config bootstrap, Task 2: git_retry backoff wrapper, Task 3: stale-lock sweep at lane start, Task 4: scoped GIT_OPTIONAL_LOCKS / GIT_ASK_YESNO (+4 more)

### Community 477 - "2026-07-18-v0275-7-docs-readme-refresh"
Cohesion: 0.29
Nodes (12): Acceptance, docs-readme-refresh Implementation Plan (v0.2.7.5 · package 7/7), File structure, Global constraints, Self-review, Task 1: ground-truth inventory, Task 2: README.md, Task 3: docs/USAGE.md (+4 more)

### Community 478 - "2026-07-31-v029-tranche-a1-recording-instruments"
Cohesion: 0.29
Nodes (12): Global Constraints, Plan series, Task 1: Recover the stranded defect ledger, Task 2: Record the obligation-16 verdict as a scoped measurement, Task 3: Let a wrong measurement be retired (obligation 21), Task 4: One session store per repository, not per worktree (fact 16 / fact 28), Task 5: True up the obligations ledger, Task 6: Stop the plugin shipping without its headline feature (+4 more)

### Community 479 - "2026-08-08-v031-session-portability"
Cohesion: 0.29
Nodes (12): File Structure, Global Constraints, Self-review notes, Task 1: Golden oracle, Task 2: FilesOnlySessionStore, Task 3: Negative control, Task 4: Backend factory, Task 5: Migrate fm-session onto the port (+4 more)

### Community 480 - "2026-08-08-v031-release-design"
Cohesion: 0.29
Nodes (12): Architecture, Dogfooding, Exit predicates, Open questions, Provenance, Risks, Sequencing, Testing strategy (+4 more)

### Community 481 - "2026-09-12-pel-release-design"
Cohesion: 0.29
Nodes (13): Decision and alternatives, Execution semantics, Foreman Pel release design, Four adapters and six model profiles, Knowledge workflow and tool state, Open decisions for the first implementation brief, Outcome, Pel core and Foreman library (+5 more)

### Community 482 - "ground-truth-inventory"
Cohesion: 0.29
Nodes (12): File inventory: openspec/changes/archive/2026-07-18-docs-readme-refresh/ground-truth-inventory.md, Config keys, docs-check.sh — confirmed tool set (no AI-slop detector), Ground-truth inventory (Task 1), Hard mode — shipped vs. approved-spec upgrade path, Lanes (soft mode), Lifecycle wrapper scripts (v0.2.7.5 lifecycle-three-stage), POSIX launcher cascade (pidns) (+4 more)

### Community 483 - "spec"
Cohesion: 0.29
Nodes (12): File inventory: openspec/changes/archive/2026-07-18-wsl-reliability-env-refresh/specs/environment/spec.md, ADDED Requirement: dependency versions are reconciled to verified currency, ADDED Requirement: shellcheck and WSL bats-core are actually present, ADDED Requirement: the event log survives post-sleep clock drift, ADDED Requirement: the root→non-root migration is inventoried, not executed, ADDED Requirement: WSL codex resolves to a native install, not the Windows shim, ADDED Requirement: WSL is a fully-provisioned, co-equal foreman environment, ADDED Requirement: .wslconfig is tuned for an agent host (+4 more)

### Community 484 - "design"
Cohesion: 0.29
Nodes (12): File inventory: openspec/changes/audit-groundedness-gate/design.md, Alternatives rejected, Conditional obligations are separate checks, never combinators, Design — audit-groundedness-gate, Risks, Stated plainly, what cannot be made symbolic, The one rule, What the canary has to prove (+4 more)

### Community 485 - "spec"
Cohesion: 0.29
Nodes (12): File inventory: openspec/changes/crlf-extensionless-hardening/specs/line-endings/spec.md, ADDED Requirements, Requirement: binary files are protected from text=auto mis-detection, Requirement: every bash-executed tracked file is LF in its git index on every platform, and LF in the working tree on an autocrlf=true checkout, Requirement: every directly executed Foreman script is executable in the git index, Requirement: genuine Windows scripts remain CRLF, Scenario: a binary asset is untouched by the catch-all, Scenario: a fresh ext4 clone can direct-exec the SDD scripts (+4 more)

### Community 486 - "spec"
Cohesion: 0.29
Nodes (12): File inventory: openspec/changes/round-resume-typescript/specs/round-resume/spec.md, ADDED Requirements, Requirement: R5A is a pure TypeScript module, Requirement: resume uses the existing recovery authority, Requirement: select one exact current attempt, Requirement: the decision is closed and fail-safe, Scenario: a boundary is required, Scenario: an older prompt has a valid plan (+4 more)

### Community 487 - "tasks"
Cohesion: 0.29
Nodes (12): File inventory: openspec/changes/test-infrastructure-hardening/tasks.md, T10 — regression injection and gate, T1 — the precondition helper, T2 — runner: budgets, baselines, reporting, T3 — annotate the existing suite, T4 — remove live-vendor coupling, T5 — determinism, T6 — installer stops dirtying the tree (+4 more)

### Community 488 - "r4c3-design"
Cohesion: 0.29
Nodes (12): File inventory: openspec/changes/vendor-preflight/r4c3-design.md, Architecture-policy transition, Complete `lane-run` port, Considered approaches, Data flow, Decision, Exact migration seam, Failure behavior (+4 more)

### Community 489 - "durable-lanes"
Cohesion: 0.29
Nodes (12): File inventory: skills/foreman/references/durable-lanes.md, Architecture, Configuration, Durable lanes, Event vocabulary (decision lineage + telemetry), Honest limits, Lock-primitive availability by host class, Locking (+4 more)

### Community 490 - "lanes"
Cohesion: 0.29
Nodes (13): File inventory: skills/foreman/references/lanes.md, Codex auditor flags (soft) — GPT-5.6 Sol, Codex implementer flags (soft), Config (`.foreman/config.toml`), Default pairing, GPT-6 Astra judgment flags, Grok headless recipe (lane-run, durable lanes), Grok worker flags (soft) (+5 more)

### Community 491 - "reference-environment"
Cohesion: 0.29
Nodes (13): File inventory: skills/foreman/references/reference-environment.md, Architect report template, Clock-sync: protecting the event log across sleep/resume (v0.2.7.5 package 3), Codex auth: headless vs interactive (v0.2.8.1), Commands, Pre-implementation gate (architect duty), Profiles, Reference environment (Windows + WSL2) (+5 more)

### Community 492 - "vendor-concurrency-test"
Cohesion: 0.38
Nodes (12): File inventory: skills/foreman/scripts/vendor-concurrency-test.sh, ARGV, LANE_ROOTS, POST_AUTH, PRE_AUTH, vendor-concurrency-test.sh script, vct_auth_status(), vct_build_argv() (+4 more)

### Community 493 - "SKILL"
Cohesion: 0.29
Nodes (12): File inventory: skills/ste/SKILL.md, Instructions — this is where specs live, Punctuation, Sentences and paragraphs, STE — Simplified Technical English for Foreman, Terminology, The rules that bind here, Verbs and voice (+4 more)

### Community 494 - "superpowers"
Cohesion: 0.36
Nodes (12): File inventory: skills/superpowers/.pi/extensions/superpowers.ts, ref_earendil_works_pi_coding_agent, bootstrapSkillPath, extensionDir, firstNonCompactionSummaryIndex(), getBootstrapContent(), messageContainsBootstrap(), packageRoot (+4 more)

### Community 495 - "2026-05-05-platform-neutral-config-refs-design"
Cohesion: 0.29
Nodes (12): File inventory: skills/superpowers/docs/superpowers/specs/2026-05-05-platform-neutral-config-refs-design.md, Background, Commit plan, Implementation note, In scope, Non-goals, Out of scope, Platform-neutral config-file references — Phase B design (+4 more)

### Community 496 - "2026-05-05-platform-neutral-prose-design"
Cohesion: 0.29
Nodes (12): File inventory: skills/superpowers/docs/superpowers/specs/2026-05-05-platform-neutral-prose-design.md, Background, Carve-outs that stay as "Claude", Coined-term rename, Commit plan, Files affected, In scope, Non-goals (+4 more)

### Community 497 - "defense-in-depth"
Cohesion: 0.29
Nodes (12): File inventory: skills/superpowers/skills/systematic-debugging/defense-in-depth.md, Applying the Pattern, Defense-in-Depth Validation, Example from Session, Key Insight, Layer 1: Entry Point Validation, Layer 2: Business Logic Validation, Layer 3: Environment Guards (+4 more)

### Community 498 - "SKILL"
Cohesion: 0.29
Nodes (12): File inventory: skills/superpowers/skills/verification-before-completion/SKILL.md, Common Failures, Key Patterns, Overview, Rationalization Prevention, Red Flags - STOP, The Bottom Line, The Gate Function (+4 more)

### Community 499 - "test-bootstrap-caching"
Cohesion: 0.29
Nodes (12): File inventory: skills/superpowers/tests/opencode/test-bootstrap-caching.mjs, afterFirst, afterSecond, assertMissingBootstrap(), assertPresentBootstrap(), bootstrapText(), countBootstrapParts(), firstOutput (+4 more)

### Community 500 - "typescriptmigration"
Cohesion: 0.29
Nodes (12): File inventory: typescriptmigration.md, Current baseline, Final zero-Python gate, Foreman TypeScript Migration Checklist, Goal, Module checklist, Per-sprint acceptance checklist, Production and release paths: 4 files remaining (+4 more)

### Community 501 - "RELEASE-NOTES"
Cohesion: 0.15
Nodes (13): Code Review Consolidation, Codex Plugin Mirror Tooling, Community, Contributor Guidelines for AI Agents, Cursor, Documentation & Install, Gemini CLI, OpenCode (+5 more)

### Community 502 - "SKILL"
Cohesion: 0.32
Nodes (11): Check for context, Ending Discovery, Guardrails, Handling Different Entry Points, OpenSpec Awareness, The Stance, What You Don't Have To Do, What You Might Do (+3 more)

### Community 503 - "SKILL"
Cohesion: 0.32
Nodes (11): Check for context, Ending Discovery, Guardrails, Handling Different Entry Points, OpenSpec Awareness, The Stance, What You Don't Have To Do, What You Might Do (+3 more)

### Community 504 - "COUNCIL-ACE-PROFILE"
Cohesion: 0.32
Nodes (11): Acceptance criteria, Accepted sentence shapes, Canonicalization, Content words, Council ACE Profile 1, Function words, Goals, Non-goals (+3 more)

### Community 505 - "SKILL"
Cohesion: 0.32
Nodes (11): Check for context, Ending Discovery, Guardrails, Handling Different Entry Points, OpenSpec Awareness, The Stance, What You Don't Have To Do, What You Might Do (+3 more)

### Community 506 - "lane-p1-rework.report"
Cohesion: 0.30
Nodes (11): ARCHITECT_ACTIONS, `bats tests/lane-review-bundle.bats`, Bundle schema (after rework), Files changed, FOREMAN_REPORT — lane-review-bundle rework (Council F1–F7), Per-finding evidence, Required tests (fail-capable), `shellcheck -S warning skills/foreman/scripts/lane-review-bundle.sh` (+3 more)

### Community 507 - "AUDIT-L3"
Cohesion: 0.32
Nodes (11): Criteria, Findings, HIGH — `el_init` can delete a live or unclassifiable holder's lock, HIGH — reclamation evidence and refusals are discarded, L3 Cold Audit, LOW — compaction design note claims a unique tmp and stronger defense than implemented, MEDIUM — index-lock refusal leaves an unindexed, non-retryable worktree, Passed conclusions (+3 more)

### Community 508 - "task-4-report"
Cohesion: 0.32
Nodes (11): 1. Failing test output (Step 2), 2. Passing test run (Step 4), 3. tests/baseline.tsv line 45, 4. Row counts before/after the copy, 5. recover output from both worktrees (Step 6, negative control), 6. find /root -maxdepth 5 -name session.db (final state), 7. supersede 16 output (Step 7), 8. Commit SHA (+3 more)

### Community 509 - "task-8-report"
Cohesion: 0.32
Nodes (11): 1. Step 1 — lanectl.sh ps (before starting), 2. systemd-run command and unit name, 3. TOTAL and RESULT lines, 4. Per-slice table (all 45 registered slices ran; none missing, none extra), 5. Per-file timeout check, 6. Wall-clock time, 7. Measurement and session, 8. git push (+3 more)

### Community 510 - "AUDIT-MERGE"
Cohesion: 0.32
Nodes (11): Confirmed integration properties (partial), F1 — HIGH — two reclaim callers can delete while the mechanism is flock or indeterminate, F2 — HIGH — the owner token is overwriteable by a check-then-act loser, F3 — HIGH — register-backed `mkdir` evidence is not bound to the probed target, F4 — HIGH — the committed regression suite was not migrated to the trust contract, Findings, Merge Integration Audit, Shellcheck delta — cosmetic, not a masked defect (+3 more)

### Community 511 - "v0.2.8.2-notes"
Cohesion: 0.32
Nodes (11): Deterministic formal-runner assets, External pilot result, External-portability defect list, Foreman portability changes, Known limits, Linux NATS coverage, Scope reset, v0.2.8.2 release notes (+3 more)

### Community 512 - "v0.2.9.0-cleanup-log"
Cohesion: 0.32
Nodes (11): Current register, DST-0030 withdrawn worktree, DST-0031 worker package files, DST-0032 primary run artifacts, DST-0035 stale OpenSpec packages, DST-0036 failed external dependency scan, DST-0037 harness runtime paths, DST-0038 current run artifacts (+3 more)

### Community 513 - "foreman-model-routing-2026-09-04"
Cohesion: 0.32
Nodes (11): Changes, Foreman model routing update, Local acquisition artifacts, Local inventory boundary, Plan recorded before edits, RED evidence, Remaining limitations, Research method (+3 more)

### Community 514 - "REPORT_B-prevention"
Cohesion: 0.32
Nodes (11): Amendment A (the one contract change): round-script ownership, Amendment B: add Task 8 — auto-resume supervisor, Amendment C: harden the terminal predicate (edit T2 + T4), One-line summary for the planner, Prevention-Gap Audit — v0.2.5 vs. the background-and-stop attractor, Q1 — The 12 attractor occurrences under foreman-launch (T1) + lane-run T2 + watch T4, Q2 — Contract amendment so "agent stopped early" cannot lose work, Q3 — Auto-resume primitive (bounded) — new plan task (+3 more)

### Community 515 - "REPORT_C-environment"
Cohesion: 0.30
Nodes (11): 1. Bun, 2. pueue, 3. REPORT_compile.md / REPORT_ffi.md — caveats vs. plan's Global Constraints, 4. signtool, 5. env/reference-manifest.toml integration, 6. CI / GitHub Actions, foreman v0.2.5 Environment & Feasibility Audit, GAPS (blocking or open before T0/T1) (+3 more)

### Community 516 - "AUDIT-gpt6-astra-round1-2026-09-05"
Cohesion: 0.30
Nodes (11): Blocking findings, Coverage register review, GPT-6 Astra audit of the v0.5 release plan, GPT-6 Astra audit, round 1, Model self-identification, Non-blocking findings, Predicate review, Verdict (+3 more)

### Community 517 - "AUDIT-gpt6-astra-round2-2026-09-05"
Cohesion: 0.32
Nodes (11): Blocking findings, Coverage register review, GPT-6 Astra audit of the v0.5 release plan, round 2, GPT-6 Astra audit, round 2, Model self-identification, Non-blocking findings, Predicate review, Round-1 findings status (+3 more)

### Community 518 - "AUDIT-gpt6-astra-round3-2026-09-05"
Cohesion: 0.32
Nodes (11): Blocking findings, Coverage register review, GPT-6 Astra audit of the v0.5 release plan, round 3, GPT-6 Astra audit, round 3, Model self-identification, Non-blocking findings, Predicate review, Round-2 findings status (+3 more)

### Community 519 - "AUDIT-gpt6-astra-round4-2026-09-05"
Cohesion: 0.32
Nodes (11): Blocking findings, Coverage register review, GPT-6 Astra audit of the v0.5 release plan, round 4, GPT-6 Astra audit, round 4, Model self-identification, Non-blocking findings, Predicate review, Round-3 findings status (+3 more)

### Community 520 - "FINAL-codex"
Cohesion: 0.32
Nodes (11): BLOCKED — change before dispatch, Could not check, Cross-fix contradictions, Decision, Finding-rate judgement, FIXABLE IN FLIGHT — do not hold unrelated implementation, Foreman v0.2.9 Final Codex Audit, Per-stage dispatchability (+3 more)

### Community 521 - "RECONCILE"
Cohesion: 0.32
Nodes (11): 1. Verdict ruling: **APPROVED-WITH-FIXES**, with a gated start, 2. Cross-lane agreement/disagreement matrix, 3. Consolidated, prioritised fix list, 4. The honest claim set for v0.2.9, 5. Recommended scope, with the store in it, 6. Note to the council lanes (terminusdb-schema / -adapter / -operations), P0 — fix before the first dispatch (blocks start of execution), P1 — fix before the owning stage starts (parallel with S0–S3) (+3 more)

### Community 522 - "brief"
Cohesion: 0.32
Nodes (11): Context, Design review brief — Foreman v0.3.1 storage port contract, Output format, Port 1 — `SessionStore` (system of record), Port 2 — `MemoryIndex` (derived projection), The defect being fixed, The design under review, The governing invariant (+3 more)

### Community 523 - "2026-07-18-v0275-2-grok-lane-activation"
Cohesion: 0.32
Nodes (11): Acceptance, File structure, Global constraints, grok-lane-activation Implementation Plan (v0.2.7.5 · package 2/7), Self-review, Task 1: verify the grok arm of the vendor map, Task 2: secrets-refusal preflight, Task 3: manifest + Setup-stage auth (+3 more)

### Community 524 - "2026-07-18-v0275-5-posix-cascade-parity"
Cohesion: 0.32
Nodes (11): Acceptance, File structure, Global constraints, posix-cascade-parity Implementation Plan (v0.2.7.5 · package 5/7), Self-review, Task 1: subreaper safety net (prctl via bun:ffi), Task 2: pidns bootstrap (the cascade guarantee), Task 3: contract parity (+3 more)

### Community 525 - "2026-09-12-pel-release-plan"
Cohesion: 0.32
Nodes (12): Dependencies, Foreman Pel release plan, Global constraints, P0: Reconcile the baseline and freeze the simplification cohort, P1: Freeze the Pel compatibility profile, P2: Build checked parsing, evaluation, and previews, P3: Build four provider adapters and six exact profiles, P4: Execute one durable vertical slice (+4 more)

### Community 526 - "2026-07-15-readme-deepening-design"
Cohesion: 0.32
Nodes (11): Decisions log, Execution, Files, Goal, README deepening — design, Self-contained scope, Six ASCII diagrams (required, each labeled), Structure (15 sections, in order) (+3 more)

### Community 527 - "2026-08-06-v030-checkpoint"
Cohesion: 0.32
Nodes (11): 1. Decisions taken (these are settled), 2. Audit findings that drove those decisions, 3. Verified defects — found by execution, not inspection, 4. Suite accountability — the structural finding, 5. Effect adoption gap, 6. Corrections made during the session, 7. Open — needs an owner decision, 8. Where everything is (+3 more)

### Community 528 - "tool-check"
Cohesion: 0.42
Nodes (11): Check-One(), Get-FileSha256(), Get-FsClass(), Get-HostClassForPin(), Get-LockAtomicityProbe(), Get-NormalizedPath(), Get-PinnedVerdict(), Get-Ver() (+3 more)

### Community 529 - "spec"
Cohesion: 0.30
Nodes (11): home_charl_fm_wt_foreman_dsl_release_openspec_changes_archive_2026_08_01_wsl_seam_doctrine_withdrawn_specs_wsl_seam_x_md, File inventory: openspec/changes/archive/2026-08-01-wsl-seam-doctrine-withdrawn/specs/wsl-seam/spec.md, ADDED Requirements, Requirement: browser-callback auth flows on WSL are operator-foreground, Requirement: every directly-exec'd tracked script is executable-or-guarded, Requirement: the pueue daemon on WSL is restart-on-demand, not persistent, Scenario: a directly-exec'd script without +x is caught, Scenario: an extensionless directly-exec'd script without +x is caught (+3 more)

### Community 530 - "spec"
Cohesion: 0.32
Nodes (11): File inventory: openspec/changes/archive/2026-07-17-test-harness-fork-tax/specs/test-harness/spec.md, Requirement: jq-CRLF probe is computed at most once per run, Requirement: kill-escalation tests use a bounded grace of 1 second, Requirement: per-test git repo is copied from a per-file template, Requirement: SCRIPTS is assigned without a subshell, Scenario: jq absent leaves jq unwrapped, Scenario: repeated sourcing spawns the probe once, Scenario: scripts still resolve and run (+3 more)

### Community 531 - "spec"
Cohesion: 0.32
Nodes (11): File inventory: openspec/changes/archive/2026-07-18-grok-lane-activation/specs/lane-run/spec.md, ADDED Requirement: grok authentication is a Setup-stage responsibility, ADDED Requirement: grok lanes refuse secrets-bearing worktrees, ADDED Requirement: lane-run maps the grok vendor to an isolated GROK_HOME, ADDED Requirement: the grok-implementer recipe is non-interactive and isolated, MODIFIED Requirement: the env manifest describes a real, resolvable grok install, Scenario: a clean worktree proceeds, Scenario: a worktree with a .env file blocks the grok lane (+3 more)

### Community 532 - "tasks"
Cohesion: 0.32
Nodes (11): File inventory: openspec/changes/archive/2026-07-30-terminusdb-withdrawn-operations/tasks.md, T1 -- Docker deployment, T2 -- data directory placement, T3 -- backup and restore, rehearsed, T4 -- schema migration runbook, T5 -- the named query layer (24 competency questions), T6 -- monitoring without Prometheus, T7 -- timed drop-and-rebuild (+3 more)

### Community 533 - "design"
Cohesion: 0.32
Nodes (11): File inventory: openspec/changes/archive/2026-07-30-terminusdb-withdrawn-schema/design.md, Alternatives considered and REJECTED, Approach, Competency question mapping (N2 section 9, 24 questions), Design -- terminusdb-schema, graphify -> schema mapping manifest (v1), Risks, Schema version and change procedure (+3 more)

### Community 534 - "design"
Cohesion: 0.32
Nodes (11): File inventory: openspec/changes/decision-lineage-and-telemetry/design.md, Alternatives considered and REJECTED, Cost, honestly, or not at all, Design — decision-lineage-and-telemetry, Emission must never be able to fail a gate, Risks, Security: references, never contents, The four event types (+3 more)

### Community 535 - "tasks"
Cohesion: 0.32
Nodes (11): File inventory: openspec/changes/graph-store-port/tasks.md, T1 — the GraphStore port, T2 — the frozen schema, T3 — the files-only implementation (lands before the adapter), T4 — the SQLite ontology adapter, T5 — the query wrapper and the non-emptiness contract, T6 — concurrency, T7 — ingest (+3 more)

### Community 536 - "spec"
Cohesion: 0.32
Nodes (11): File inventory: openspec/changes/resume-safety-services-typescript/specs/resume-safety-services/spec.md, ADDED Requirements, Requirement: lock observation does not follow links, Requirement: one Effect program collects both observations, Requirement: process observation fails safe, Requirement: R5B performs observation only, Scenario: a caller receives a free lock snapshot, Scenario: a link points to a lock directory (+3 more)

### Community 537 - "tasks"
Cohesion: 0.32
Nodes (11): File inventory: openspec/changes/round-ownership-default/tasks.md, T1 — confirm the premises before changing anything, T2 — resolve the flag, T3 — enforce at the dispatch boundary, T4 — Setup migration, T5 — doctrine, T6 — tests, T7 — gate (+3 more)

### Community 538 - "spec"
Cohesion: 0.32
Nodes (11): File inventory: openspec/changes/workload-fit-accounting/specs/workload-fit/spec.md, ADDED Requirements, Requirement: foreman-fit-report reads the fit ledger — NOT the event log — and emits a discovery-vs-offload split with a poor-fit verdict, Requirement: the architect declares an up-front fit estimate and warns on poor cost-fit, seeding the fit ledger, Scenario: a healthy hybrid run (mostly offload) reports good fit, Scenario: a high discovery_fraction estimate triggers an up-front warning and seeds the ledger, Scenario: a missing fit ledger is refused cleanly, not read from the event log, Scenario: a mixed run reports its discovery-vs-offload split from the fit ledger (+3 more)

### Community 539 - "spec"
Cohesion: 0.32
Nodes (11): File inventory: openspec/changes/wsl-launcher-shipped/specs/launcher-dist/spec.md, ADDED Requirements, Requirement: readiness reports the launcher's absence loudly, DEGRADED (not NOT-READY) when bun is also absent, Requirement: Setup builds the POSIX launcher when absent, Requirement: the frozen launcher-absent degraded fallback is unchanged, Scenario: build step is idempotent and bun-tolerant, Scenario: degraded alert payload is untouched, Scenario: fresh WSL clone gets a built launcher (+3 more)

### Community 540 - "architecture-cli / architecture-cli.test"
Cohesion: 0.36
Nodes (10): File inventory: packages/policy/src/architecture-cli.test.ts, File inventory: packages/policy/src/architecture-cli.ts, ArchCliIo, emit(), parseArchitectureArgv(), ParsedArchArgs, runArchitectureCli(), ArchitectureGit (+2 more)

### Community 541 - "INSTALL / README"
Cohesion: 0.29
Nodes (10): File inventory: plugins/foreman-qa/INSTALL.md, File inventory: plugins/foreman-qa/README.md, Install, Local marketplace install, Source of truth, Symlink or copy into ~/.claude/plugins/, Contents, foreman-qa (+2 more)

### Community 542 - "SKILL"
Cohesion: 0.32
Nodes (11): File inventory: skills/checkpoint/SKILL.md, 1. Facts — durable, true by construction, 2. Measurements — perishable, and the reason this system exists, 3. Obligations — owed work and stated blockers, 4. Supersede rather than edit, 5. End the session, checkpoint — canonical session stopping point, Creating a checkpoint — when to do it (+3 more)

### Community 543 - "security-model"
Cohesion: 0.32
Nodes (11): File inventory: skills/foreman/references/security-model.md, container (Docker/WSL2), Hard mode (shipped), Honest limits, launcher-only (default, no Docker), Operator rules, pr-open: gate → HTTPS PAT push → draft PR, Process containment (POSIX launcher) (+3 more)

### Community 544 - "agy"
Cohesion: 0.36
Nodes (11): File inventory: skills/foreman/scripts/adapters/agy.sh, adapter_audit_argv(), adapter_auth_probe(), adapter_caps(), adapter_home_var(), adapter_implement_argv(), _adapter_report_cli_version(), adapter_result_text() (+3 more)

### Community 545 - "claude"
Cohesion: 0.36
Nodes (11): File inventory: skills/foreman/scripts/adapters/claude.sh, adapter_audit_argv(), adapter_auth_probe(), adapter_caps(), adapter_home_var(), adapter_implement_argv(), _adapter_report_cli_version(), adapter_result_text() (+3 more)

### Community 546 - "codex"
Cohesion: 0.36
Nodes (11): File inventory: skills/foreman/scripts/adapters/codex.sh, adapter_audit_argv(), adapter_auth_probe(), adapter_caps(), adapter_home_var(), adapter_implement_argv(), _adapter_report_cli_version(), adapter_result_text() (+3 more)

### Community 547 - "grok"
Cohesion: 0.36
Nodes (11): File inventory: skills/foreman/scripts/adapters/grok.sh, adapter_audit_argv(), adapter_auth_probe(), adapter_caps(), adapter_home_var(), adapter_implement_argv(), _adapter_report_cli_version(), adapter_result_text() (+3 more)

### Community 548 - "audit-call"
Cohesion: 0.45
Nodes (11): File inventory: skills/foreman/scripts/lib/audit-call.sh, _ac_config_get(), _ac_configured_candidates(), _ac_configured_model(), _ac_default_model(), _ac_has_adapter(), _ac_has_audit_capability(), ac_model_family() (+3 more)

### Community 549 - "resume / checkpoint"
Cohesion: 0.38
Nodes (10): File inventory: skills/foreman/scripts/lib/checkpoint.sh, File inventory: skills/foreman/scripts/resume.sh, ckpt_snapshot(), checkpoint.sh script, exact_delete_extras(), main(), recover_prompt_payload(), resolve_checkpoint_sha() (+2 more)

### Community 550 - "SKILL"
Cohesion: 0.32
Nodes (11): File inventory: skills/scrapling/SKILL.md, Cookie 格式速查, Guardrails, References 索引, Scrapling 网页抓取 Skill, 模板索引, 步骤 0：检查版本, 步骤 1：安全预检与 quick path (+3 more)

### Community 551 - "api-quick-ref"
Cohesion: 0.32
Nodes (11): File inventory: skills/scrapling/references/api-quick-ref.md, DynamicFetcher（Playwright，JS 渲染）, Fetcher（基于 curl_cffi，最快）, FetcherSession（保持会话 cookie）, Response 常用属性, Scrapling API 速查卡, Selector（纯 HTML 解析，无网络请求）, StealthyFetcher（Camoufox，绕过反爬） (+3 more)

### Community 552 - "troubleshooting"
Cohesion: 0.32
Nodes (11): File inventory: skills/scrapling/references/troubleshooting.md, 404 "page is private", cf_clearance cookie 无效, Cloudflare 403 + "Just a moment", Cloudflare 多轮 Turnstile, Cookie should have a url or a domain/path pair, Expected array, got object at $.cookies, ModuleNotFoundError: curl_cffi (+3 more)

### Community 553 - "2026-02-19-visual-brainstorming-refactor"
Cohesion: 0.32
Nodes (11): File inventory: skills/superpowers/docs/superpowers/plans/2026-02-19-visual-brainstorming-refactor.md, Chunk 1: Server, Template, Client, Tests, Skill, File Map, Task 1: Update `frame-template.html`, Task 2: Update `index.js` — content injection and `.events` file, Task 3: Simplify `helper.js`, Task 4: Update tests for new structure, Task 5: Delete `wait-for-feedback.sh` (+3 more)

### Community 554 - "2026-03-23-codex-app-compatibility"
Cohesion: 0.32
Nodes (11): File inventory: skills/superpowers/docs/superpowers/plans/2026-03-23-codex-app-compatibility.md, Codex App Compatibility Implementation Plan, File Structure, Task 1: Add Step 0 to `using-git-worktrees`, Task 2: Update `using-git-worktrees` Integration section, Task 3: Add Step 1.5 to `finishing-a-development-branch`, Task 4: Add Step 5 cleanup guard to `finishing-a-development-branch`, Task 5: Update Integration lines in `subagent-driven-development` and `executing-plans` (+3 more)

### Community 555 - "2026-06-11-visual-companion-final-hardening-fixup"
Cohesion: 0.32
Host semantic extraction token usage: unknown (not metered). Deterministic extraction requires no model calls.

### Community 556 - "SKILL"
Cohesion: 0.32
Nodes (11): File inventory: skills/superpowers/skills/executing-plans/SKILL.md, Executing Plans, Integration, Overview, Remember, Step 1: Load and Review Plan, Step 2: Execute Tasks, Step 3: Complete Development (+3 more)

### Community 557 - "test-lint-shell"
Cohesion: 0.50
Nodes (11): File inventory: skills/superpowers/tests/shell-lint/test-lint-shell.sh, assert_contains(), assert_not_contains(), cleanup(), configure_git_identity(), fail(), make_fixture_repo(), pass() (+3 more)

### Community 558 - "check-inventory"
Cohesion: 0.55
Nodes (11): File inventory: tests/lib/check-inventory.sh, emit_row(), main(), scan_assertions(), scan_gate_runner(), scan_gate_scripts(), scan_gate_workflows(), scan_probes() (+3 more)

### Community 560 - "codex-implementer"
Cohesion: 0.35
Nodes (10): Codex Implementer (Foreman), Contract, Evidence contract, Git discipline (standing rule), Known limits, Preflight — no silent fallback, Rules, Run codex (+2 more)

### Community 561 - "explore"
Cohesion: 0.35
Nodes (10): Check for context, Ending Discovery, Guardrails, OpenSpec Awareness, The Stance, What You Don't Have To Do, What You Might Do, When a change exists (+2 more)

### Community 562 - "spec"
Cohesion: 0.35
Nodes (10): ADDED Requirements, Purpose, Requirement: Council hosted gate fails closed, Requirement: Hosted Council gate excludes provider live calls, Requirement: Root gates run the Council Node 24 suite, Scenario: Council check fails on a pull request, Scenario: Linux root gate includes the Council step, Scenario: Windows root gate includes the Council step (+2 more)

### Community 563 - "2026-09-05"
Cohesion: 0.35
Nodes (10): 1. What actually happened, in order, 2026-09-05, 2. What went right, 3. What went wrong, 4. Standing rules that came out of today, 5. Where things stand, 6. Resume instructions, Addendum: the approved experiments (+2 more)

### Community 564 - "gemini-headless"
Cohesion: 0.31
Nodes (10): docs_cli_cli_reference_md, docs_cli_tutorials_automation_md, Exit codes, Headless mode reference, JSON output, Next steps, Output formats, Streaming JSON output (+2 more)

### Community 565 - "AUDIT-2026-07-30-fullsuite"
Cohesion: 0.35
Nodes (10): 1. The headline: the suite completes, and it FAILS, 2. The six failures, 3. `lane-queue.bats` test 7 escapes its own shim (evidence-backed), 4. The test-policy layer has never been calibrated for WSL, 5. Static analysis — clean, 6. OpenSpec — independently confirmed, 7. Code read: `lib/lock.sh` is sound, AUDIT — 2026-07-30 — first completed full-suite run on `integrate/v029-w1` (+2 more)

### Community 566 - "BRIEF"
Cohesion: 0.35
Nodes (10): 1. Objective, 2. Files, 3. Interfaces / required content, 3a. `.gitattributes` root, 3b. The inventory — DERIVE IT, DO NOT HARDCODE 41, 3c. `tests/line-endings.bats`, 4. Constraints, 5. Verification — MANDATORY, and the report (+2 more)

### Community 567 - "AUDIT-sol-L1"
Cohesion: 0.35
Nodes (10): Claim-by-claim audit summary, Findings, HIGH — acquisition-operation failures are misreported as timeouts, and `UNAVAILABLE` details do not reliably name errno, HIGH — `FM_LOCK_FS_UNSUPPORTED` tests “any unsupported” instead of “no mechanism covers this filesystem”, HIGH — `FM_LOCK_PROBE_UNTRUSTED` is overbroad in mixed-verdict states, HIGH — `fm_with_lock` does not release on every exit path, HIGH — re-sourcing the library erases a live outer-lock record, MEDIUM — nested is not always the first evaluated refusal cause (+2 more)

### Community 568 - "BRIEF"
Cohesion: 0.35
Nodes (10): 0. Scope, 1. T2 — migrate the durable core off inline mkdir spin-loops, 2. T3 — correct the false doctrine that caused this defect, 3. T9 — remove the fail-open path (this is a blocker in its own right), 4. T10 — the compaction race, 5. T11 — per-lock, owner-aware reclamation, 6. T13 — operational, 7. Verification — mandatory (+2 more)

### Community 569 - "REPORT"
Cohesion: 0.35
Nodes (10): 1. Runner (reproducible, method-recorded, `^[violation]` anchor), 2. Per-model expected outcomes (pin VIOLATE/PASS), 3. Vacuity reporting (VACUOUS vs holds), 4. CI wiring (`.github/workflows/`), 5. Kill policy (no `pkill -f` by pattern; PID/PGID only), 6. Verification evidence (known-bad fail, known-clean pass, wrong grep, vacuous, non-zero exit, bounds), 7. Deferred work (and why), Files added/touched (+2 more)

### Community 570 - "BRIEF"
Cohesion: 0.35
Nodes (10): Dogfooding — this ships into use immediately (D9), Scope — tasks T1 through T6 of `decision-lineage-and-telemetry` ONLY, SPEC — decision-lineage-emission (S4a), T1 — verify the additivity premise BEFORE writing code, T2-T4 — put the decisions in the log, T5 — usage: tokens, cost, model identity, T6 — phase timing, Verification (+2 more)

### Community 571 - "REPORT"
Cohesion: 0.35
Nodes (10): 1. GraphStore port (operation set + contracts), 2. Files-only implementation, 3. Contract suite (backend-agnostic, runs against files-only), 4. Verification: suite passes against files-only, 5. Verification: suite is backend-agnostic (stub fails for real reasons), 6. Verification: fallback exercised with no store configured, 7. Deferred (out of scope this round), Known-bad checker observation (AGENT_TRAPS §3.2) (+2 more)

### Community 572 - "2026-07-29-lane-strandings"
Cohesion: 0.35
Nodes (10): Cross-cutting findings, Lane strandings — 2026-07-29, S-1 — Opus audit lane died mid-write, analysis lost, S-2 — grok round SUSPENDED by its own self-update (SIGTTIN), S-3 / S-4 — implement lane backgrounded its round and ended its turn (x2), S-5 — audit lane sat 21 minutes in preflight without launching its vendor, S-6 — audit lane left redundant untracked watchdogs running, S-7 — the watchdog itself could not see the stall (orchestrator fault) (+2 more)

### Community 573 - "2026-07-17-resume-checkpoint"
Cohesion: 0.35
Nodes (10): Artefact index (for tomorrow + the v0.2.5 planning session), Biggest learnings this session (all in bugeventlog.md), Cross-vendor invariant held, Resume checkpoint — 2026-07-17 (v0.2.0 bundle, ~1 hour from tag), State of the tree, TL;DR — what remains to tag v0.2.0, UPDATE (end of 2026-07-17): perf bundle FORCE-MERGED to main, v0.2.0 bundle — final scope (+2 more)

### Community 574 - "REPORT_compile"
Cohesion: 0.35
Nodes (10): 1. Current `--compile` capabilities, 2. CRITICAL — bun:ffi dlopen of system DLLs inside a compiled binary: **WORKS (verified locally)**, 3. Code signing (Windows Authenticode), 4. Version pinning / reproducibility, 5. Runtime flags / memory footprint (measured, Bun 1.3.14, Win11), 6. Known open blockers (Windows + `--compile`), statuses checked via GitHub API 2026-07-16, Build recipe (windows-x64), REPORT_compile — Lane B: `bun build --compile` for foreman-launch (Windows) (+2 more)

### Community 575 - "REPORT_ffi"
Cohesion: 0.35
Nodes (10): Empirical test log (this session, 2026-07-16), Minimal viable call plan (all [MEASURED] working, Bun 1.3.14 x64), Q1. bun:ffi API surface + Windows x64 status, Q2. Exact call sequence — and the race question, Q3. Handle lifetime + crash guarantee, Q4. Breaking-change risk + fallbacks, Q5. Prior art — npm/bun packages wrapping Job Objects, RISKS (ranked) (+2 more)

### Community 576 - "gemini-cache / gemini-model"
Cohesion: 0.27
Nodes (10): Context caching, Implicit caching, Documentation, Gemini 3.8 Flash, gemini-3.8-flash, Gemini 3.8 Flash profile, gemini_api_docs_generate_content_caching_md, gemini_api_docs_text_generation_md (+2 more)

### Community 577 - "openai-sol-card"
Cohesion: 0.18
Nodes (10): gpt_5_6_cot_controllability_md, gpt_5_6_cot_monitorability_md, gpt_5_6_cybersecurity_capabilities_md, gpt_5_6_metagaming_md, gpt_5_6_monitor_design_md, gpt_5_6_performance_in_cases_flagged_by_users_md, gpt_5_6_references_md, gpt_5_6_safeguards_md (+2 more)

### Community 578 - "vendor-concurrency-results"
Cohesion: 0.35
Nodes (10): Auxiliary evidence collected (safe, real CLI, deliberately NOT authenticated), Constraints, Credential-staging blocker (both vendors — no authenticated matrix run), Harness (`vendor-concurrency-test.sh`), LIVE authenticated run (2026-07-18, user-authorized shared-account), Protocol (run manually, per vendor), Results, Task 2 execution log (2026-07-18) (+2 more)

### Community 579 - "F-uutils-mkdir-blocker"
Cohesion: 0.35
Nodes (10): Blast radius, Claim, Evidence — measured, reproducible, FINDING F-UUTILS-MKDIR — the portable mkdir-mutex is not atomic on Ubuntu 26.04, How this surfaced, Mechanism — the smoking gun, Proposed remedy (for the v0.2.9 roadmap), Separate finding, same triage: test 50 is invalid as root (+2 more)

### Community 580 - "2026-07-18-v0275-6-t5b-concurrency-verdict"
Cohesion: 0.35
Nodes (10): Acceptance, File structure, Global constraints, Self-review, t5b-concurrency-verdict Implementation Plan (v0.2.7.5 · package 6/7), Task 1: matrix-runner harness logic (shim-driven), Task 2: codex + grok destructive runs (manual, contained), Task 3: Claude Code ruling + results doc (+2 more)

### Community 581 - "2026-08-05-bounded-execution-terminal-policy"
Cohesion: 0.35
Nodes (10): File structure, Foreman Endstop Implementation Plan, Global Constraints, Task 1: Pure contract and terminal reducer, Task 2: Atomic journal transaction, Task 3: Durable execution ledger and CLI, Task 4: Guard queue admission, Task 5: Falsify loop closure (+2 more)

### Community 582 - "2026-08-03-council-preflight-cli-design"
Cohesion: 0.35
Nodes (10): Acceptance, Council Preflight CLI Design, Failure behavior, Processing sequence, Provider routing, Request contract, Selected approach, Status and scope (+2 more)

### Community 583 - "spec"
Cohesion: 0.35
Nodes (10): File inventory: openspec/changes/archive/2026-07-18-lifecycle-three-stage/specs/lifecycle/spec.md, ADDED Requirement: Cleanup runs a deterministic teardown set, ADDED Requirement: foreman operates in three ordered stages, ADDED Requirement: Setup emits a machine-readable readiness verdict, ADDED Requirement: Setup owns all model authentication, MODIFIED Requirement: SKILL.md documents the lifecycle as the operating frame, Scenario: Cleanup preserves dirty work, Scenario: grok unauthenticated blocks its lane at the door (+2 more)

### Community 584 - "spec"
Cohesion: 0.35
Nodes (10): File inventory: openspec/changes/archive/2026-07-18-worktree-hardening/specs/worktree/spec.md, ADDED Requirement: Defender exclusion doctrine is documented, ADDED Requirement: lanes scope optional-lock and yes/no env vars, ADDED Requirement: shared-lock operations retry with bounded backoff, ADDED Requirement: stale locks are swept before a lane starts, ADDED Requirement: the repo carries the concurrency-safe git config, MODIFIED Requirement: wt-cleanup never destroys uncommitted work and orders shutdown, Scenario: a transient index.lock contention succeeds on retry (+2 more)

### Community 585 - "tasks"
Cohesion: 0.35
Nodes (10): File inventory: openspec/changes/audit-groundedness-gate/tasks.md, T1 — the rule, the registry, and the refusal, T2 — the canary, before the checks it protects, T3 — wave 1: the checks that need nothing new, T4 — wave 2: two prose invariants become enforced, T5 — wave 3: the checks that need a spec-format change, T6 — integration with the gate and the record, T7 — shadow measurement and the promotion protocol (+2 more)

### Community 586 - "tasks"
Cohesion: 0.35
Nodes (10): File inventory: openspec/changes/bounded-execution-terminal-policy/tasks.md, 1. Contract and reducer, 2. Atomic journal transaction, 3. Durable execution ledger, 4. Guarded queue admission, 5. Progress and evidence reuse, 6. Dependency behavior, 7. Endless-loop falsification (+2 more)

### Community 587 - "tasks"
Cohesion: 0.35
Nodes (10): File inventory: openspec/changes/decision-lineage-and-telemetry/tasks.md, T1 — verify the additivity premise before writing any code, T2 — audit decisions in the log, T3 — findings in the log, T4 — gate decisions in the log, T5 — usage: tokens, cost, model identity, T6 — phase timing, T7 — the metrics rollup (+2 more)

### Community 588 - "design"
Cohesion: 0.35
Nodes (10): File inventory: openspec/changes/formal-model-suite/design.md, Alternatives considered, Design — formal-model-suite, Drift is the slow failure, and it is gated at the file level, Method honesty is a requirement, not a courtesy, Risks, The asset is the violation, not the model, The classifier is itself a check, so it gets a positive control (+2 more)

### Community 589 - "tasks"
Cohesion: 0.35
Nodes (10): File inventory: openspec/changes/formal-model-suite/tasks.md, T1 — the outcome classifier and its positive control, T2 — the expectation manifest, T3 — the runner, T4 — vacuous-predicate registry, T5 — coverage records and the drift gate, T6 — method and bound in the output, T7 — CI and operational discipline (+2 more)

### Community 590 - "design"
Cohesion: 0.35
Nodes (11): File inventory: openspec/changes/node-typescript-runtime/design.md, Compatibility adapters, Design — Node.js and TypeScript runtime migration, Effect boundary, Installation boundary, Module dependency map, Package boundaries, Policy enforcement (+3 more)

### Community 591 - "design"
Cohesion: 0.35
Nodes (10): File inventory: openspec/changes/profile-bound-lane-admission/design.md, Admission flow, Admission input, Design: profile-bound lane admission, Endstop execution packages, Failure behavior, Live lane adapter, Out of scope (+2 more)

### Community 592 - "tasks"
Cohesion: 0.35
Nodes (10): File inventory: openspec/changes/v050-release-program/tasks.md, 1. Bootstrap (root contract, before family activation), 2. Lane runtime (child v050-lane-runtime-typescript), 3. Launcher retirement (child v050-launcher-node-port), 4. Verdict honesty (children v050-three-outcome-verdicts, v050-audit-groundedness-gate, v050-evidence-contracts), 5. Exploratory route (children v050-spec-triage-gate, v050-foreman-discover-lane), 6. Host truth (children v050-build-determinism, v050-wsl-preflight), 7. Doctrine (child v050-doctrine-reality-drift) (+2 more)

### Community 593 - "tasks"
Cohesion: 0.35
Nodes (10): File inventory: openspec/changes/vendor-adapter-contract/tasks.md, T1 — the adapter interface, T2 — migrate the implement verb, T3 — introduce the audit verb, T4 — result capture, verdict validation, version recording, T5 — consume the write-evidence loop (owned by `evidence-contracts`), T6 — the contract tests, T7 — resolve the claude half-wiring (architect decision) (+2 more)

### Community 594 - "tasks"
Cohesion: 0.35
Nodes (10): File inventory: openspec/changes/vendor-preflight/tasks.md, R4C — persisted record and lane gate, T1 — the result model and the capability table, T2 — declared adapters: claude, codex, T3 — probed adapters: grok, agy, T4 — currency without mutation, T5 — wire the callers, T6 — tests, red-first (+2 more)

### Community 595 - "protocol"
Cohesion: 0.35
Nodes (10): File inventory: skills/council/references/protocol.md, Authority boundary, Blinding boundary (binding), Bundle identity (binding), Council protocol — advisory review loop, Dissent rule (binding), Non-approval classes, Outcome classes (disjoint) (+2 more)

### Community 596 - "audit-checklist"
Cohesion: 0.35
Nodes (10): File inventory: skills/foreman/references/audit-checklist.md, Audit checklist and verdict schema, Default auditor, Dimensions, Documentation & comments (iterative), Hard mode, Soft-mode invocation sketch, Soft mode (required unless user opts out) (+2 more)

### Community 597 - "liveness"
Cohesion: 0.45
Nodes (10): File inventory: skills/foreman/scripts/lib/liveness.sh, lv_classify_pid(), lv_cputime_secs(), lv_etime_secs(), lv_exists_only(), lv_is_dispatched_lane(), lv_is_live(), lv_pgrep_exists() (+2 more)

### Community 598 - "2026-01-22-document-review-system"
Cohesion: 0.35
Nodes (10): File inventory: skills/superpowers/docs/superpowers/plans/2026-01-22-document-review-system.md, Chunk 1: Spec Document Reviewer, Chunk 2: Plan Document Reviewer, Chunk 3: Update Plan Document Header, Document Review System Implementation Plan, Task 1: Create Spec Document Reviewer Prompt Template, Task 2: Add Review Loop to Brainstorming Skill, Task 3: Create Plan Document Reviewer Prompt Template (+2 more)

### Community 599 - "2026-03-11-zero-dep-brainstorm-server"
Cohesion: 0.35
Nodes (10): File inventory: skills/superpowers/docs/superpowers/plans/2026-03-11-zero-dep-brainstorm-server.md, Chunk 1: WebSocket Protocol Layer, Chunk 2: HTTP Server and Application Logic, Chunk 3: Swap and Cleanup, File Map, Task 1: Implement WebSocket protocol exports, Task 2: Add HTTP server, file watching, and WebSocket connection handling, Task 3: Update start-server.sh and remove old files (+2 more)

### Community 600 - "2026-06-09-sdd-task-scoped-review-dispatch"
Cohesion: 0.35
Nodes (10): File inventory: skills/superpowers/docs/superpowers/plans/2026-06-09-sdd-task-scoped-review-dispatch.md, Finishing, SDD Task-Scoped Review Dispatch Implementation Plan, Task 1: Rewrite the per-task quality reviewer prompt as self-contained, Task 2: Spec reviewer prompt cleanups, Task 3: Implementer prompt — re-run tests after fixing review findings, Task 4: SKILL.md controller changes, Task 5: New eval scenario — per-task quality reviewer catches a planted defect (+2 more)

### Community 601 - "condition-based-waiting"
Cohesion: 0.35
Nodes (10): File inventory: skills/superpowers/skills/systematic-debugging/condition-based-waiting.md, Common Mistakes, Condition-Based Waiting, Core Pattern, Implementation, Overview, Quick Patterns, Real-World Impact (+2 more)

### Community 602 - "windows-lifecycle.test"
Cohesion: 0.47
Nodes (10): File inventory: skills/superpowers/tests/brainstorm-server/windows-lifecycle.test.sh, cleanup(), fail(), get_key_from_info(), get_port_from_info(), http_check(), pass(), windows-lifecycle.test.sh script (+2 more)

### Community 603 - "ws-protocol.test / server"
Cohesion: 0.35
Nodes (10): File inventory: skills/superpowers/tests/brainstorm-server/ws-protocol.test.js, ref_crypto, assert, crypto, RFC-6455, path, runTests(), makeClientFrame() (+2 more)

### Community 604 - "helpers"
Cohesion: 0.36
Nodes (10): File inventory: tests/helpers.bash, helpers.bash script, jq(), seed_run(), setup_git_worktree(), setup_lock_mkdir_trust_fixture(), setup_lock_trust_fixture(), setup_lock_untrusted_fixture() (+2 more)

### Community 605 - "spec"
Cohesion: 0.18
Nodes (10): ADDED Requirements, Capability: store-adapter, Requirement: Operational note on server workers is documented only, Requirement: Response data-version is surfaced only via normalization path, Requirement: Single-parent commits only, Requirement: Strict-create mode maps DocumentIdAlreadyExists, Scenario: Adapter does not set TERMINUSDB_SERVER_WORKERS, Scenario: Batch write is one commit (+2 more)

### Community 606 - "codex-auditor"
Cohesion: 0.38
Nodes (9): After Codex returns, Codex Auditor (Foreman) — GPT-5.6 Sol, How you build the audit prompt, Inputs you expect from the architect, Preflight — no silent fallback, Report format, Rules, Run Codex — GPT-5.6 Sol, read-only, high reasoning (+1 more)

### Community 607 - "foreman-audit"
Cohesion: 0.38
Nodes (9): Codex invocation (preferred), Foreman Audit (worktree-isolated), FOREMAN_REPORT.json, FOREMAN_REPORT.md, Mandatory outputs, Mission, Preflight, Rules (+1 more)

### Community 608 - "security-spec-review"
Cohesion: 0.20
Nodes (9): 11. Mandatory changes before approval, 12. Approval checklist, 1. Scope and standards basis, 7. Forbidden states and fail-closed rules, 8. Validation and evaluation matrix, 9.1 Cross-capability invariants, 9.2 Effect design constraints, 9. Proposed OpenSpec capability split (+1 more)

### Community 609 - "2026-08-02-ace-prompt-preflight"
Cohesion: 0.38
Nodes (9): Council ACE Prompt Preflight Implementation Plan, Verification, Work package 1: Serialized contracts, Work package 2: ACE parser and compiler, Work package 3: Terminal-first response admission, Work package 4: Effect preprocessing service, Work package 5: Provider schema and canary adapters, Work package 6: Operator contract and dogfood (+1 more)

### Community 610 - "spec"
Cohesion: 0.38
Nodes (9): MODIFIED Requirements, Requirement: Invocation is shell-free and reproducible, Requirement: Terminal classification uses compound evidence, Scenario: An interim abstention precedes cancellation, Scenario: Claude canary uses stdin transport, Scenario: Claude schema output reports tool_use without tools, Scenario: Exit zero with truncated output, Scenario: Prompt contains shell metacharacters (+1 more)

### Community 611 - "grok-cache / grok-model"
Cohesion: 0.33
Nodes (9): developers_advanced_api_usage_prompt_caching_maximizing_cache_hits_md, developers_advanced_api_usage_prompt_caching_multi_turn_md, [Maximizing Cache Hits](#maximizing-cache-hits), [Next](#next), [Prompt Caching](#prompt-caching), [Set `prompt_cache_key` (Responses API)](#set-prompt_cache_key-responses-api), [Set `x-grok-conv-id` (Chat Completions API)](#set-x-grok-conv-id-chat-completions-api), [Set `x-grok-conv-id` metadata (gRPC API)](#set-x-grok-conv-id-metadata-grpc-api) (+1 more)

### Community 612 - "2026-08-02"
Cohesion: 0.38
Nodes (9): 1. What actually happened, in order, 2026-08-02, 2. What went right, 3. What went wrong, 4. Standing rules that came out of today, 5. Where things stand, 6. Resume instructions, Session: Council study, graphify, and what it exposes about the review loop (+1 more)

### Community 613 - "REPORT"
Cohesion: 0.38
Nodes (9): Commands run, F1 — VERIFIED already fixed at `9da74c5`, F2 — DONE. Hooks directory sweep restored, without reintroducing the bypass, F3 — DONE. The regression that would have caught F1, Observed, not introduced: working-tree exec-bit drift, Owed at merge, not here, REPORT — crlf-extensionless-hardening, round 7, The corrected D11 obligation — enumeration of every exclusion pattern (+1 more)

### Community 614 - "BRIEF"
Cohesion: 0.38
Nodes (9): Non-negotiables on the suite itself, Scope — tasks T6, T7 and T13, SPEC — lock-primitive-hardening, Round L4: the regression suite and the gate, T13 — operational, T6 — the regression suite, T7 — the gate, What I want from your judgment specifically, Why this round is different (+1 more)

### Community 615 - "BRIEF"
Cohesion: 0.38
Nodes (9): Dogfooding — this goes into use immediately (D9), Scope, SPEC — test-infrastructure-hardening, round 1 (T1 + T2), T1 — `tests/lib/preconditions.bash`, T2 — the runner, The failure class you are defending against — read this before coding, Verification — mandatory, Why this exists, in one measurement (+1 more)

### Community 616 - "graph-store"
Cohesion: 0.51
Nodes (9): gs_capabilities(), gs_contract_files_only(), gs_contract_stub_expect_fail(), _gs_pkg_parent(), gs_python(), gs_smoke_no_store(), gs_version_ref(), graph-store.sh script (+1 more)

### Community 617 - "experiments"
Cohesion: 0.38
Nodes (9): `agy` Readiness Experiment, Architecture Result, Council v0.3.0 Integration Evidence, First Dogfood Target, Localization Experiment, Scope, Shadow Composition Experiment, Verification Baseline (+1 more)

### Community 618 - "INSTALL"
Cohesion: 0.38
Nodes (9): Authentication (both platforms), Boot the architect, Install, Troubleshooting, Uninstall, What install does, Windows, WSL / macOS / Linux (+1 more)

### Community 619 - "2026-07-18-v025-sc-proof"
Cohesion: 0.38
Nodes (9): Residual limits (honest), SC-A — agent-stop survivability: PROVEN LIVE, SC-B — whole-round ownership: permanent tests, SC-C — bounded auto-resume: permanent tests, SC-D — stale-report immunity: permanent tests, SC-E — no concurrent writers on resume: permanent tests, SC-F — completion provable without the agent: permanent tests + SC-A, v0.2.5 prevention criteria — proof record (2026-07-18) (+1 more)

### Community 620 - "v0.3.0-destruction-log"
Cohesion: 0.38
Nodes (9): Current cleanup note, Current register (authoritative), Executed action record, File inventories, Historical process incident, R7B2-C behavior retirement, Recovery and evidence rules, v0.3.0 destruction log (+1 more)

### Community 621 - "effect-concurrency"
Cohesion: 0.38
Nodes (9): 1. Structured concurrency: what must be forked in a scope, and what leaks, 2. Interruption semantics, `uninterruptible`, and finalizers, 3. Bounded concurrency: documented mechanism vs. Foreman's vendor caps, 4. Racing, timeouts, and retries: documented composition and traps, 5. Anti-patterns the docs warn about, and the Effect-native replacement, Effect Concurrency Best Practices → Rules for Foreman, Summary of conflicts found (file:line), What Foreman already does right (worth preserving as the house style) (+1 more)

### Community 622 - "effect-services-testing"
Cohesion: 0.38
Nodes (9): 1. Defining a service and its live layer, 2. Layer composition and memoization, 3. Test doubles: swapping layers, keeping fakes honest, 4. TestClock, and Foreman's real-`setTimeout` tests, 5. Keeping logic out of Effect (pure functions) — and Foreman's own doctrine, Effect docs: Services, Layers, Testing — rules for Foreman, Summary of conflicts found (with files), Top 3 rules to apply to Foreman (+1 more)

### Community 623 - "EDIT-readme-facts"
Cohesion: 0.38
Nodes (9): 1. False or stale claims, 2. Unverifiable claims, 3. True claims worth keeping, 4. Dead references, 5. Single most misleading sentence, 6. Material omissions, Foreman README Fact-Checking Edit Plan, Verification notes (+1 more)

### Community 624 - "LANDING-ORDER"
Cohesion: 0.38
Nodes (9): Addendum: the boundary fix over-corrected before it settled, Contended files (modification claims, n >= 3), File contention and landing order — v0.2.9, Landing order, Open, Revision 2a correction (codex re-audit), Two packages had no stage — corrected, What changed from revision 1 (+1 more)

### Community 625 - "REAUDIT-codex"
Cohesion: 0.38
Nodes (9): Findings closed, Findings NOT closed, Foreman v0.2.9 Fix-Round Re-audit — Codex GPT-5.6 Sol, NEW defects introduced by the fix round, Self-consistency: does the workstream now survive its own standard?, Verdict, What I checked and found correct, What I could not check, and why (+1 more)

### Community 626 - "START-HERE"
Cohesion: 0.38
Nodes (9): Decisions already made, Dispatch S1 first, Standing environment notes, Start here — v0.2.9 Total GeorgeCall implementation, State, The one judgement still open, Then, Uncommitted, deliberately (+1 more)

### Community 627 - "2026-07-16-foreman-launch"
Cohesion: 0.38
Nodes (9): foreman-launch (Bun) Implementation Plan, Global Constraints, Risks (ranked, from the four reports), Sequencing, Task 1: launcher package scaffold + version pin + FFI smoke module, Task 2: supervised spawn — job-owned child with heartbeats and graded stop, Task 3: CLI entry + compiled binary + bats harness tests, Task 4: CI smoke + docs + manifest wiring (+1 more)

### Community 628 - "2026-08-03-council-preflight-cli"
Cohesion: 0.38
Nodes (9): Council Preflight CLI Implementation Plan, Global Constraints, Task 1: Add the closed runtime request contract, Task 2: Add canonical canary material and scoped files, Task 3: Add the application preflight coordinator, Task 4: Add the Node runtime composition package, Task 5: Close the OpenSpec and documentation slice, Task 6: Produce implementation evidence for Foreman audit (+1 more)

### Community 629 - "2026-08-04-v030-r4c-persisted-preflight"
Cohesion: 0.38
Nodes (9): Acceptance, Boundary, Council status, Foreman v0.3.0 R4C persisted preflight implementation plan, Goal, Work package 1: record store, Work package 2: CLI commands, Work package 3: thin adapters (+1 more)

### Community 630 - "RESUME"
Cohesion: 0.38
Nodes (9): File inventory: RESUME.md, Before you claim anything is done, Owner decisions that block work, Pointers, Release freeze — where to commit, RESUME — how to pick this repository up cold, Start here, What the store will tell you (+1 more)

### Community 631 - "design"
Cohesion: 0.38
Nodes (9): File inventory: openspec/changes/agy-lane-activation/design.md, Alternatives considered and rejected, Design — agy-lane-activation, Reasoning effort is expressed twice, and that is a doctrine problem, Risks, Timeout authority, Trust, and the thing most likely to kill this lane on day one, What a fourth vendor has to earn, and how we would know (+1 more)

### Community 632 - "spec"
Cohesion: 0.38
Nodes (9): File inventory: openspec/changes/archive/2026-07-18-docs-readme-refresh/specs/documentation/spec.md, ADDED Requirement: README describes the current product and both platforms, ADDED Requirement: the blader/humanizer skill runs over user-facing prose, ADDED Requirement: the doc set is internally consistent and link-clean, ADDED Requirement: USAGE documents the lifecycle end-to-end, MODIFIED Requirement: CLAUDE.md doctrine matches the shipped lifecycle, Scenario: a new user follows the quickstart on WSL, Scenario: docs-check is green on the refreshed set (+1 more)

### Community 633 - "proposal"
Cohesion: 0.38
Nodes (9): File inventory: openspec/changes/audit-groundedness-gate/proposal.md, A gate that cannot fail is worse than no gate, Change: audit-groundedness-gate, Impact, The cross-vendor invariant is checked at the wrong time, The failure class nothing catches today, What changes, Why (+1 more)

### Community 634 - "design"
Cohesion: 0.38
Nodes (9): File inventory: openspec/changes/doctrine-reality-drift/design.md, Alternatives considered and REJECTED, Design — doctrine-reality-drift, Risks, The empty-result rule, The registry row, and why the observed value is in it, Two adjacent checks that share the mechanism, What can actually be checked (+1 more)

### Community 635 - "tasks"
Cohesion: 0.38
Nodes (9): File inventory: openspec/changes/doctrine-reality-drift/tasks.md, T1 — the registry format, T2 — the checker, T3 — seed the registry from the known contradictions, T4 — coordinate the fixes, do not perform them, T5 — stale change folders, T6 — workaround stamps, T7 — tests and gate (+1 more)

### Community 636 - "spec"
Cohesion: 0.38
Nodes (9): File inventory: openspec/changes/foreman-discover-lane/specs/discover-lane/spec.md, ADDED Requirements, Requirement: foreman-discover is a bounded top-model empirical lane that emits facts + determined sub-specs, never product code, Requirement: grok is not eligible for discovery, Requirement: on budget exhaustion, foreman-discover self-reports partial with remaining unknowns (advisory, not coded enforcement), Scenario: a discovery brief is never routed to grok, Scenario: budget exhausts before convergence, Scenario: discovery converges and emits facts + sub-specs, no product code (+1 more)

### Community 637 - "design"
Cohesion: 0.38
Nodes (9): File inventory: openspec/changes/grok-secret-scan-typescript/design.md, Boundaries, Bounds, CLI and shell seam, Descriptor-anchor traversal, Design: bounded fixture-aware secret scan, Fixture exemptions, Scan model (+1 more)

### Community 638 - "tasks"
Cohesion: 0.38
Nodes (9): File inventory: openspec/changes/launcher-node-port/tasks.md, 1. Package scaffold and CLI, 2. Heartbeat and streams, 3. Supervision and timers, 4. Platform capabilities, 5. Churn and compiled artifact, 6. Documentation truth, Open follow-on (not this package) (+1 more)

### Community 639 - "design"
Cohesion: 0.38
Nodes (9): File inventory: openspec/changes/resume-supervisor-typescript/design.md, Alternatives rejected, Decision, Design: resume-supervisor-typescript, Queue execution, Resume budget, Runtime boundary, Supervisor (+1 more)

### Community 640 - "design"
Cohesion: 0.38
Nodes (9): File inventory: openspec/changes/vendor-adapter-contract/design.md, Alternatives considered and rejected, Demonstrated rejection — the two predicates this package still owns at the evidence boundary, Design — vendor-adapter-contract, Risks, The never-stdin invariant needs an owner, and so does argument order, What "no behaviour change for grok and codex" means, What the contract is actually for (+1 more)

### Community 641 - "plugin-lessons"
Cohesion: 0.56
Nodes (9): File inventory: plugins/foreman-qa/scripts/plugin-lessons.sh, harness_error(), main(), normalize_release(), record_finding(), run_candidates(), run_check(), plugin-lessons.sh script (+1 more)

### Community 642 - "gate-and-ratchets"
Cohesion: 0.38
Nodes (9): File inventory: plugins/foreman-qa/skills/foreman-testing/references/gate-and-ratchets.md, A TIMEOUT slice's counts are partial, not a result, baseline.tsv and skip-budget.tsv, Gate mode and ratchets, Gate mode: shadow vs enforce, Negative controls: does the SUITE catch a real defect?, Positive and negative controls, Positive controls: does the check discriminate? (+1 more)

### Community 643 - "README"
Cohesion: 0.38
Nodes (9): File inventory: skills/foreman/graph_store/README.md, Architectural rule, Environment, GraphStore product surface, Layout, Lineage queries, Operations (required of every backend), Optional capabilities (query before use; degrade if absent) (+1 more)

### Community 644 - "roles"
Cohesion: 0.38
Nodes (9): File inventory: skills/foreman/references/roles.md, Advisor (Judgment), Auditor (Cold-diff review), High-judgment reviewer, Orchestrator (Architect), Plan (parallel design), Roles, Search (parallel recon) (+1 more)

### Community 645 - "exports"
Cohesion: 0.38
Nodes (9): File inventory: skills/graphify/references/exports.md, graphify reference: extra exports and benchmark, Step 6b - Wiki (only if --wiki flag), Step 7 - Neo4j export (only if --neo4j or --neo4j-push flag), Step 7a - FalkorDB export (only if --falkordb or --falkordb-push flag), Step 7b - SVG export (only if --svg flag), Step 7c - GraphML export (only if --graphml flag), Step 7d - MCP server (only if --mcp flag) (+1 more)

### Community 646 - "2026-01-22-document-review-system-design"
Cohesion: 0.38
Nodes (9): File inventory: skills/superpowers/docs/superpowers/specs/2026-01-22-document-review-system-design.md, Document Review System Design, Error Handling, Files to Change, Markdown Task Syntax, Overview, Plan Document Reviewer, Spec Document Reviewer (+1 more)

### Community 647 - "bump-version"
Cohesion: 0.58
Nodes (9): File inventory: skills/superpowers/scripts/bump-version.sh, audit_excludes(), cmd_audit(), cmd_bump(), cmd_check(), declared_files(), read_json_field(), bump-version.sh script (+1 more)

### Community 648 - "SKILL"
Cohesion: 0.38
Nodes (9): File inventory: skills/superpowers/skills/brainstorming/SKILL.md, After the Design, Anti-Pattern: "This Is Too Simple To Need A Design", Brainstorming Ideas Into Designs, Checklist, Key Principles, Process Flow, The Process (+1 more)

### Community 649 - "helper"
Cohesion: 0.53
Nodes (9): File inventory: skills/superpowers/skills/brainstorming/scripts/helper.js, connect(), nextReconnectDelay(), reloadAfterRecovery(), sendEvent(), sessionKey(), setStatus(), showTombstone() (+1 more)

### Community 650 - "render-graphs"
Cohesion: 0.47
Nodes (9): File inventory: skills/superpowers/skills/writing-skills/render-graphs.js, combineGraphs(), { execSync }, extractDotBlocks(), extractGraphBody(), fs, main(), path (+1 more)

### Community 651 - "stop-server.test"
Cohesion: 0.51
Nodes (9): File inventory: skills/superpowers/tests/brainstorm-server/stop-server.test.sh, bad(), cleanup(), new_server_id(), ok(), stop-server.test.sh script, track_dir(), track_pid() (+1 more)

### Community 652 - "inject-regressions"
Cohesion: 0.44
Nodes (9): File inventory: tests/inject-regressions.sh, main(), make_tree(), mutate_drop_provenance(), mutate_duplicate_seq(), mutate_swallow_lock_failure(), run_case(), inject-regressions.sh script (+1 more)

### Community 653 - "foreman-plan"
Cohesion: 0.42
Nodes (8): Foreman Plan (worktree-isolated), FOREMAN_REPORT.json, FOREMAN_REPORT.md structure, Mandatory outputs, Mission, Return, Rules, File inventory: agents/foreman-plan.md

### Community 654 - "foreman-search"
Cohesion: 0.42
Nodes (8): FOREMAN_REPORT.json, FOREMAN_REPORT.md structure, Foreman Search (worktree-isolated), Mandatory outputs (before you finish), Mission, Return to architect, Rules, File inventory: agents/foreman-search.md

### Community 655 - "checklist"
Cohesion: 0.42
Nodes (8): Exact-candidate gates, Explicit non-goals, External dogfood, Live evidence, Product boundary, Release actions, v0.2.9.0 release record, File inventory: checklist.md

### Community 656 - "CLAUDE"
Cohesion: 0.42
Nodes (9): Always, Close out the day: write the devlog, Dogfood website task, Foreman project — architect doctrine, Iron Rule: Node.js and TypeScript, QA, testing, and code quality, Repo understanding: graph first, Soft loop (remember) (+1 more)

### Community 657 - "2026-08-08-d2-path-confusion"
Cohesion: 0.42
Nodes (8): D2 — the POSIX backslash path-confusion, Evidence, Residual, stated plainly, Ruling: A, 2–1, The dissent changed the fix, The question, What measurement found, File inventory: docs/decisions/2026-08-08-d2-path-confusion.md

### Community 658 - "2026-08-08-tool-check-ts-controls"
Cohesion: 0.42
Nodes (8): 1. checkSha256FileSync, 2. checkHostClass, 3. checkFsClassFromProbe, 4. checkPinnedVerdict, 5. checkProcVersion, 6. probeAtomicity, Positive Controls for TypeScript Tool-Check Functions, File inventory: docs/evidence/positive-control/2026-08-08-tool-check-ts-controls.md

### Community 659 - "BRIEF"
Cohesion: 0.42
Nodes (8): 0. The two mistakes already made here — do not make either again, 1. Scope, 2. T4 — the atomicity probe in the host inventory, 3. T5 — reference manifest and the pinned atomicity register, 4. T14 — wire mechanism selection to the verdict, 5. Verification — mandatory, SPEC — lock-primitive-hardening, Round L2: the evidence and trust plane, File inventory: docs/evidence/v029/s1-lock-L2/BRIEF.md

### Community 660 - "REWORK"
Cohesion: 0.42
Nodes (8): A PARTITION CORRECTION YOU NEED TO KNOW ABOUT, H1 — HIGH, the blocker. `el_init` can delete a live holder's lock, H2 — HIGH. Reclamation evidence and refusals are discarded, H3 — MEDIUM, round-introduced. A refused index lock strands the worktree, L1 — LOW. The design note overstates the compaction defence, REWORK — lock-primitive-hardening L3, round 2, Verification — mandatory, File inventory: docs/evidence/v029/s1-lock-L3/REWORK.md

### Community 661 - "REPORT"
Cohesion: 0.42
Nodes (8): 1. graph-project.sh, 2. Determinism proof, 3. Additivity (unknown event types), 4. Node and edge identity from event content, 5. Verification harness (observed FAIL before PASS), 6. Deferred items, REPORT — work-dag-projection, round 1, File inventory: docs/evidence/v029/s7-workdag/REPORT.md

### Community 662 - "task-3-report"
Cohesion: 0.42
Nodes (8): 1. Failing test run (Step 2), 2. Passing test run (Step 6), 3. `tests/baseline.tsv` line 45, 4. Retiring the live wrong measurements, 5. Commit, 6. Not verified / caveats, Task 3 report: retire a measurement proven wrong, File inventory: docs/evidence/v029-tranche-a1/task-3-report.md

### Community 663 - "task-5-report"
Cohesion: 0.42
Nodes (8): 1. Step 1 — verification commands before closing anything, 2. Obligations 8, 9, 10 — evidence and close output, 3. Step 4 — every remaining open/blocked obligation, verdict and evidence, 4. Final `recover` obligations section, 5. Commit, 6. What could not be verified, Task 5 report — True up the obligations ledger, File inventory: docs/evidence/v029-tranche-a1/task-5-report.md

### Community 664 - "REWORK"
Cohesion: 0.42
Nodes (8): F1 — reclaim callers can delete on the flock or indeterminate path, F2 — the owner token is overwriteable by a check-then-act loser, F3 — register-backed mkdir evidence is not bound to the probed target, F4 — the committed regression suite was not migrated to the trust contract, REWORK — L2+L3 integration, round 2, ROUND 2 CONTINUATION — read this first, Verification, File inventory: docs/evidence/v029/trial/REWORK.md

### Community 665 - "v0.3.1-notes"
Cohesion: 0.42
Nodes (8): Exit predicates, George's Odyssey, Product, QA evidence block, Review record, Verification, What does not ship, File inventory: docs/releases/v0.3.1-notes.md

### Community 666 - "effect-errors-resources"
Cohesion: 0.42
Nodes (8): 1. Expected errors vs. defects vs. interruption — and where Foreman's "rethrow outside Effect" sits, 2. Tagged errors: closed failure-reason sets, 3. `Cause`, defects, and the `RangeError` bug, 4. Resource safety: `acquireRelease`, `Scope`, finalizer ordering, interruption, 5. Retry and timeout composition, and the documented traps, Effect error management & resource safety — applied to Foreman, Summary of conflicts found (file : issue : doc basis), File inventory: docs/research/2026-08-06-testing-council/effect-errors-resources.md

### Community 667 - "REPORT_D-sequencing"
Cohesion: 0.42
Nodes (8): 1. Fold-in analysis + revised task list, 2. Gate strategy, 3. Testability holes, 4. Cross-release check (v0.3.0 on top of the launcher), 5. Missing scope (from last ~15 bugeventlog entries), Priority-ordered top 5 changes, v0.2.5 Plan Audit — Sequencing, Testability, Missing Scope, File inventory: docs/research/v025-plan-audit/REPORT_D-sequencing.md

### Community 668 - "EDIT-readme-structural"
Cohesion: 0.42
Nodes (8): 1. The diagnosis, 2. Proposed section order, 3. Per-section verdict, all fifteen, 4. What is missing, and where it belongs, 5. Claims v0.2.9 has disproved — for the fact-checking editor, 6. The three cuts I would fight for, EDIT: README — structural pass, File inventory: docs/research/vnext/EDIT-readme-structural.md

### Community 669 - "PKG-workflow-summary"
Cohesion: 0.42
Nodes (8): 1. `round-ownership-default`, 2. `three-outcome-verdicts`, 3. `decision-lineage-and-telemetry`, 4. `doctrine-reality-drift`, Cross-package ordering, PKG — workflow improvement packages for v0.2.9, What was deliberately not specified, File inventory: docs/research/vnext/PKG-workflow-summary.md

### Community 670 - "VERIFY-terminusdb-schema-live"
Cohesion: 0.42
Nodes (8): Consequence for the fix round, Honest limits of this verification, Live verification of the frozen schema — architect, 2026-07-28, Method, Results, Second run, 2026-07-28 — after the ingest fix (corrects the record above), What this settles, File inventory: docs/research/vnext/VERIFY-terminusdb-schema-live.md

### Community 671 - "RESIDUALS"
Cohesion: 0.42
Nodes (8): Foreman limits, Knowledge limits, Migration limits, Product limits, Release limits, Residual work after v0.2.9.0, Runtime limits, File inventory: docs/RESIDUALS.md

### Community 672 - "2026-07-19-v0281-field-fixes-design"
Cohesion: 0.42
Nodes (8): Acceptance, Cross-cutting — release, foreman v0.2.8.1 — field-failure fixes (design), Issue 1 — install.ps1 Windows link is fragile (cmd-shelling), Issue 2 — grok `--prompt-file` single-burst writes NOTHING on exploration-heavy specs, Issue 3 — codex `login --device-auth` has no working headless flow, Issue 4 — worktree fan-out unfit for a stateful/live target, File inventory: docs/superpowers/specs/2026-07-19-v0281-field-fixes-design.md

### Community 673 - "2026-09-05-v050-release-design"
Cohesion: 0.42
Nodes (8): Approaches considered, Deferred to v0.6, Exit predicates, How this design was decided, Package map, Review gate, v0.5.0 "One runtime, honest lanes" — design, File inventory: docs/superpowers/specs/2026-09-05-v050-release-design.md

### Community 674 - "bootstrap-wsl"
Cohesion: 0.64
Nodes (8): DEBIAN_FRONTEND, have(), install_apt(), link_native(), log(), native_ok(), bootstrap-wsl.sh script, File inventory: env/bootstrap-wsl.sh

### Community 675 - "tasks"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/agy-lane-activation/tasks.md, T1 — verify what is currently UNVERIFIED (blocks the READY verdict), T2 — the adapter, T3 — plumbing (all sites, or none), T4 — credential provisioning and cleanup, T5 — inventory honesty, T6 — agents, docs, and gate, Tasks — agy-lane-activation

### Community 676 - "tasks"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/archive/2026-07-17-test-harness-fork-tax/tasks.md, 1. B#3 — drop the `$(cd&&pwd)` SCRIPTS subshell (6 files), 2. A — pin `LANE_KILL_GRACE=1` (tests/lane-run.bats), 3. B#1 — memoize the jq-CRLF probe (tests/helpers.bash), 4. B#2 half-1 + B#3(line 32) — template + `cp -r` (tests/helpers.bash), 5. Verification (run by the orchestrator, NOT during a live gate), Deferred to v0.2.5 (not in this change), Tasks — test-harness fork-tax reduction

### Community 677 - "spec"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/archive/2026-07-18-posix-cascade-parity/specs/launcher-posix/spec.md, ADDED Requirement: a subreaper safety net keeps escapees reapable, ADDED Requirement: exit-code and heartbeat contract is unchanged, ADDED Requirement: the POSIX launcher runs as PID-namespace init, MODIFIED Requirement: the launcher README documents the closed asymmetry, Scenario: contract parity across builds, Scenario: killing the launcher reaps a double-forked escapee, Spec delta — POSIX launcher whole-tree teardown parity

### Community 678 - "spec"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/archive/2026-07-18-t5b-concurrency-verdict/specs/vendor-concurrency/spec.md, ADDED Requirement: a green verdict requires all assertions to hold at N, ADDED Requirement: Claude Code is ruled from the public evidence base, ADDED Requirement: grok promotion is gated on a green grok verdict, ADDED Requirement: results are recorded and gate cap changes, ADDED Requirement: the destructive matrix runs under strict containment, Scenario: codex greens at N=2 but not N=3, Spec delta — T5b destructive concurrency verdict

### Community 679 - "proposal"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/archive/2026-07-30-terminusdb-withdrawn-adapter/proposal.md, Capabilities, Change: TerminusDB client, adapter, and ingest path, Impact, Modified Capabilities, New Capabilities, What Changes, Why

### Community 680 - "schema-live-gate"
Cohesion: 0.61
Nodes (8): File inventory: openspec/changes/archive/2026-07-30-terminusdb-withdrawn-schema/scripts/schema-live-gate.sh, cleanup(), fail(), http_post(), log(), pass(), schema-live-gate.sh script, usage()

### Community 681 - "design"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/council-review-plane/design.md, Design — council review plane, Failure mode this design accepts, Reviewer supply, The split that makes this reachable, What stays out, Why quorum is the load-bearing requirement, Why the bundle, and not the worktree

### Community 682 - "design"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/external-memory-index/design.md, Boundaries, Design: External MemoryIndex, Epochs, Projection versions, Qdrant points, Qualification, Testing

### Community 683 - "proposal"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/external-memory-index/proposal.md, Capabilities, Change: External MemoryIndex, Impact, Modified Capabilities, New Capabilities, What Changes, Why

### Community 684 - "design"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/knowledge-plane-refresh/design.md, Boundary, Deferred work, Design: Graphify 0.9.48 qualification, Measured concurrency defect, Pin and execution, Publication and freshness, Qualification

### Community 685 - "tasks"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/knowledge-plane-refresh/tasks.md, 1. Reconcile and measure, 2. RED qualification suite, 3. TypeScript implementation, 4. Repository integration, 5. Qualification evidence, 6. Gate, Tasks: Graphify 0.9.48 qualification

### Community 686 - "design"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/launcher-node-port/design.md, Capability model, Design: launcher-node-port, Effect boundaries, Goals, Non-goals (this package), Status of proof (honest), Tests

### Community 687 - "proposal"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/openspec-superpowers-convergence/proposal.md, Capabilities, Change: OpenSpec and Superpowers convergence, Impact, Modified Capabilities, New Capabilities, What Changes, Why

### Community 688 - "tasks"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/profile-bound-lane-admission/tasks.md, Endstop package rules, R7B2-A: typed admission core, R7B2 acceptance evidence, R7B2-B: live lane adapter, R7B2-C: obsolete worktree homes, R7B2-D: release verification, Tasks: profile-bound-lane-admission

### Community 689 - "design"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/profile-bound-setup-preflight/design.md, Child environment isolation, Design: profile-bound Setup preflight, Out of scope, Persistence, Selected approach, Setup grammar, Wrapper model

### Community 690 - "design"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/profile-use-leasing/design.md, Design: profile-use leasing, Endstop package, Holder protocol, Lease authority, Live adapter, Selected approach, TypeScript boundary

### Community 691 - "design"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/project-registry/design.md, Decisions, Design: Stable project registry, Excluded scope, Migration, Recovery, Registration, Registry file

### Community 692 - "proposal"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/project-registry/proposal.md, Capabilities, Change: Stable project registry, Impact, Modified Capabilities, New Capabilities, What Changes, Why

### Community 693 - "tasks"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/regression-harness-tiers/tasks.md, 1. Tier 0 — slice gates and the annual self-test, 2. Tier 1 — vendor-replay golden corpus, 3. Tier 2 — seeded-defect statistical runs, 4. External-benchmark drift anchor — CUT from v0.2.9, no tasks, 5. Cost, cadence and budget enforcement, 6. Gate, Tasks — regression harness tiers

### Community 694 - "design"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/resume-count-events-typescript/design.md, Boundaries, Concurrency and durability, Design: atomic resume-attempt reservation, Failure surface, History rules, Selected approach, Stored event

### Community 695 - "design"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/resume-safety-services-typescript/design.md, Boundaries, Design: Effect resume-safety observations, Effect composition, Lock observation, Process observation, Selected approach, Testable live boundary

### Community 696 - "proposal"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/three-outcome-verdicts/proposal.md, And the policy that was supposed to govern this is not read, Audit latency, scoped honestly, Change: three-outcome-verdicts, Impact, What changes, What happens today when the auditor does not answer, Why

### Community 697 - "design"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/vendor-concurrency-and-quota/design.md, Alternatives considered and rejected, Design — vendor-concurrency-and-quota, Exhaustion must be classified, and the dangerous case is the quiet one, Quota is an entitlement question, and readiness answers the wrong one today, Risks, The cap is 1 because the rule says so, not because the vendor looks risky, The isolation dilemma has to be stated, not resolved by wishful topology

### Community 698 - "design"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/vendor-preflight/design.md, Design — vendor-preflight, Honest limits, The defect, precisely, Why a workload canary replaces the banner, Why one predicate cannot serve four vendors, Why the preflight must not call `update`, Why this is the same shape as the lock defect

### Community 699 - "r4c3-implementation-plan"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/vendor-preflight/r4c3-implementation-plan.md, Global constraints, R4C3 persisted vendor-lane admission implementation plan, Task 1: Write RED process-boundary tests, Task 2: Write RED architecture-policy tests, Task 3: Implement the closed migration validator, Task 4: Replace live lane readiness, Task 5: Build and verify

### Community 700 - "design"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/work-dag-projection/design.md, Boundary, Deferred work, Design: deterministic work-DAG projection, Determinism and publication, Input, Output, Safety

### Community 701 - "design"
Cohesion: 0.42
Nodes (8): File inventory: openspec/changes/workflow-weight-reduction/design.md, Context, Decisions, Dependencies, Design: workflow-weight-reduction, Failure handling, Interfaces, Verification

### Community 702 - "tasks"
Cohesion: 0.42
Nodes (8): File inventory: openspec/schemas/foreman-architectural/templates/tasks.md, Allowed File Scope, Checkbox Tasks, Exact Commands, GREEN, RED, Tasks, Verification

### Community 703 - "tasks"
Cohesion: 0.42
Nodes (8): File inventory: openspec/schemas/foreman-bounded/templates/tasks.md, Allowed File Scope, Checkbox Tasks, Exact Commands, GREEN, RED, Tasks, Verification

### Community 704 - "SKILL"
Cohesion: 0.42
Nodes (8): File inventory: plugins/foreman-qa/skills/foreman-afk/SKILL.md, It happened again, Pacing check, Rules, Running unattended, The failure this exists to prevent, The mechanism, stated plainly, What actually happened

### Community 705 - "SKILL"
Cohesion: 0.42
Nodes (8): File inventory: plugins/foreman-qa/skills/foreman-testing/SKILL.md, Assertion semantics -- the biggest trap, Controls: proving a check discriminates, foreman-testing, Gate mode: shadow vs enforce, Ratchets: baseline and skip-budget, Running tests, Style

### Community 706 - "bats-traps"
Cohesion: 0.42
Nodes (8): File inventory: plugins/foreman-qa/skills/foreman-testing/references/bats-traps.md, Assertion semantics, Bats traps, Never a bare skip, Per-file timeout, The gate mutex, The heredoc test-declaration trap, Wrapping bats in flock can deadlock against itself

### Community 707 - "SKILL"
Cohesion: 0.42
Nodes (8): File inventory: skills/council/SKILL.md, Council — Advisory Cross-Family Review, Hard stops, Interfaces, Operator loop (summary), Out of scope for this skill, When not to use, When to use

### Community 708 - "graph-project"
Cohesion: 0.56
Nodes (8): File inventory: skills/foreman/scripts/graph-project.sh, gp_finding_hash(), gp_project_file(), gp_project_stream(), gp_usage(), gp_validate_events(), LC_ALL, graph-project.sh script

### Community 709 - "maintenance"
Cohesion: 0.42
Nodes (8): File inventory: skills/scrapling/references/maintenance.md, Scrapling 安装与维护, 三 Fetcher 完整验证脚本, 包管理器, 升级, 安装层级, 安装浏览器依赖, 检查安装状态

### Community 710 - "bug_report"
Cohesion: 0.42
Nodes (8): File inventory: skills/superpowers/.github/ISSUE_TEMPLATE/bug_report.md, Actual behavior, Debug log or conversation transcript, Environment (required), Expected behavior, Is this a Superpowers issue or a platform issue?, Steps to reproduce, What happened?

### Community 711 - "2026-01-17-visual-brainstorming"
Cohesion: 0.42
Nodes (8): File inventory: skills/superpowers/docs/plans/2026-01-17-visual-brainstorming.md, Summary, Task 1: Create the Server Foundation, Task 2: Create the Helper Library, Task 3: Write Tests for the Server, Task 4: Add Visual Companion to Brainstorming Skill, Task 5: Add Server to Plugin Ignore (Optional Cleanup), Visual Brainstorming Companion Implementation Plan

### Community 712 - "2026-05-05-platform-neutral-readme-design"
Cohesion: 0.42
Nodes (8): File inventory: skills/superpowers/docs/superpowers/specs/2026-05-05-platform-neutral-readme-design.md, Background, Commit plan, In scope, Out of scope, Platform-neutral README ordering — Phase C design, Substitution, Verification

### Community 713 - "package-codex-plugin"
Cohesion: 0.58
Nodes (8): File inventory: skills/superpowers/scripts/package-codex-plugin.sh, cleanup(), die(), infer_format_from_output(), metadata_root_from_dir(), prepare_metadata_root(), package-codex-plugin.sh script, usage()

### Community 715 - "RESEARCH_REPORT"
Cohesion: 0.46
Nodes (7): Bottom line, Concrete Council security requirements, Council Security Research Report, Evidence-backed findings, Evidence limitations, Important disagreements and trade-offs, File inventory: components/council/docs/research/security/RESEARCH_REPORT.md

### Community 716 - "proposal"
Cohesion: 0.46
Nodes (7): Capabilities, Impact, Modified Capabilities, New Capabilities, What Changes, Why, File inventory: components/council/openspec/changes/ace-prompt-preflight/proposal.md

### Community 717 - "tasks"
Cohesion: 0.46
Nodes (7): 1. Contract and grammar baseline, 2. ACE parser and semantic linter, 3. Prompt materialization, 4. Provider health canary, 5. Review response admission, 6. Operator contract and live proof, File inventory: components/council/openspec/changes/ace-prompt-preflight/tasks.md

### Community 718 - "proposal"
Cohesion: 0.46
Nodes (7): Capabilities, Impact, Modified Capabilities, New Capabilities, What Changes, Why, File inventory: components/council/openspec/changes/claude-provider-canary/proposal.md

### Community 719 - "proposal"
Cohesion: 0.46
Nodes (7): Capabilities, Impact, Modified Capabilities, New Capabilities, What Changes, Why, File inventory: components/council/openspec/changes/codex-provider-canary/proposal.md

### Community 720 - "spec"
Cohesion: 0.46
Nodes (7): MODIFIED Requirements, Requirement: Every selected model passes a live canary, Scenario: A provider returns valid JSON and then cancels, Scenario: Claude rejects a file prompt variant, Scenario: Codex rejects an inline schema variant, Scenario: Grok rejects a file schema variant, File inventory: components/council/openspec/changes/codex-provider-canary/specs/prompt-preflight/spec.md

### Community 721 - "proposal"
Cohesion: 0.46
Nodes (7): Capabilities, Impact, Modified Capabilities, New Capabilities, What Changes, Why, File inventory: components/council/openspec/changes/council-node24-ci/proposal.md

### Community 722 - "2026-07-29"
Cohesion: 0.46
Nodes (7): 1. What actually happened, in order, 2026-07-29 — S1 implemented, four stages opened, nothing merged until now, 2. What went right — with evidence, 3. What went wrong, 4. Standing rules that came out of today, 5. Where things stand, File inventory: devlog/2026-07-29.md

### Community 723 - "2026-08-08-predicate-1-tier2"
Cohesion: 0.46
Nodes (7): Predicate 1 and the Tier 2 pair — council ruling and architect dissent, The architect declined to act on it, The question, The ruling, What was done instead, Why they remain, File inventory: docs/decisions/2026-08-08-predicate-1-tier2.md

### Community 724 - "2026-08-06-control-record"
Cohesion: 0.46
Nodes (7): Known grammar gaps, Positive-control record — 2026-08-06, Row 1 — `tests/lib/positive-control.bash::assert_positive_control`, Row 2 — `tests/lib/check-inventory.sh::check-inventory`, Scope of what these two rows attest, Why a control is required at all, File inventory: docs/evidence/positive-control/2026-08-06-control-record.md

### Community 725 - "2026-08-07-baseline-platform"
Cohesion: 0.46
Nodes (7): Known-bad arm: `tests/fixtures/policy/baseline-platform-bad.tsv`, Known-good arm: `tests/fixtures/policy/baseline-platform-good.tsv`, Positive-control record -- 2026-08-07, The two arms, What this demonstrates, Why the prior version of this record was wrong, File inventory: docs/evidence/positive-control/2026-08-07-baseline-platform.md

### Community 726 - "README"
Cohesion: 0.46
Nodes (7): Audit, Failure diagnosis, Independent verification, Scope, TDD evidence, v0.2.9.0 Council Canary Nonce Evidence, File inventory: docs/evidence/v029-council-canary-nonce/README.md

### Community 727 - "REWORK"
Cohesion: 0.46
Nodes (7): Constraints, N1 — HIGH. flock acquisition destroys a caller-owned file descriptor 3, N2 — HIGH. The wrapper overwrites caller and command traps, N3 — MEDIUM. First source trusts inherited private hold state, REWORK — lock-primitive-hardening L1, round 3, Verification, File inventory: docs/evidence/v029/s1-lock-L1/REWORK.md

### Community 728 - "BRIEF"
Cohesion: 0.46
Nodes (7): Deliverables, Scope, SPEC — formal-model-suite, round 1, The trap that makes this package necessary, Verification, What exists, File inventory: docs/evidence/v029/s2-formal/BRIEF.md

### Community 729 - "REPORT"
Cohesion: 0.46
Nodes (7): Deferred (D7 / out of T1–T3 scope), REPORT, T1, T2, T3, Verification, File inventory: docs/evidence/v029/s4-laneown/REPORT.md

### Community 730 - "BRIEF"
Cohesion: 0.46
Nodes (7): Dogfooding — this goes into use immediately (D9), Scope, SPEC — evidence-contracts, round 1 (T1 only: the evidence mechanism), T1 — the mechanism, Verification — mandatory, Why this exists — the defect class, with today's instances, File inventory: docs/evidence/v029/s6-evidence/BRIEF.md

### Community 731 - "BRIEF"
Cohesion: 0.46
Nodes (7): Dogfooding — D9, READ THIS FIRST — T1's premises are INVERTED, deliberately, SPEC — release-metrics, round 1 (T1 re-baselined, T2, T3), T2 — the metrics reference, T3 — the report linter, and why it matters more than the metrics, Verification — mandatory, File inventory: docs/evidence/v029/s6-metrics/BRIEF.md

### Community 732 - "BRIEF"
Cohesion: 0.46
Nodes (7): Deliverables, Scope, SPEC — work-dag-projection, round 1, The architectural rule, settled in SYNTHESIS, Verification, What exists, File inventory: docs/evidence/v029/s7-workdag/BRIEF.md

### Community 733 - "BRIEF"
Cohesion: 0.46
Nodes (7): Deliverables, Scope, SPEC — graph-store-port, round 1 (port contract + files-only implementation), The architectural rule, and it is load-bearing, Verification, Why the fallback must be real, not nominal, File inventory: docs/evidence/v029/s9-storeport/BRIEF.md

### Community 734 - "REPORT"
Cohesion: 0.46
Nodes (7): Deferred / notes, REPORT — terminusdb-schema (s9-tdbschema), T1 — Author the frozen schema, T2 — Competency question audit, T3 — Gate (openspec, markdownlint, live load-test, bugeventlog), Verification evidence (undeclared field / invalid enum / drop-rebuild), File inventory: docs/evidence/v029/s9-tdbschema/REPORT.md

### Community 735 - "task-2-report"
Cohesion: 0.46
Nodes (7): 1. Log-derived counts, 2. Measurements recorded, 3. Pre-existing items verified, not duplicated, 4. Ledger entry and commit, 5. Not verified / could not check, Task 2 report — Record the obligation-16 verdict as a scoped measurement, File inventory: docs/evidence/v029-tranche-a1/task-2-report.md

### Community 736 - "README"
Cohesion: 0.46
Nodes (7): Architecture policy specification-correctness review, Candidate identity, Correctness metric, File digests, Scope limit, Verification context, File inventory: docs/evidence/v0.3.0/architecture-policy-spec-correctness-round-001/README.md

### Community 737 - "README"
Cohesion: 0.46
Nodes (7): Admitted result, Candidate identity, Destruction guard specification-correctness review, File digests, Infrastructure retries, Scope limit, File inventory: docs/evidence/v0.3.0/destruction-guard-spec-correctness-round-001/README.md

### Community 738 - "README"
Cohesion: 0.46
Nodes (7): Candidate identity, Correctness metric, File digests, Installed-runtime specification-correctness review, Scope limit, Verification context, File inventory: docs/evidence/v0.3.0/installed-runtime-spec-correctness-round-001/README.md

### Community 739 - "README"
Cohesion: 0.46
Nodes (7): Attempt 1: rejected provider shape, Attempt 2: admitted result, File digests, Reviewed candidate, Scope limit, SpecCorrectnessV1 live activation record, File inventory: docs/evidence/v0.3.0/spec-correctness-round-001/README.md

### Community 740 - "v0.3.0-notes"
Cohesion: 0.46
Nodes (7): Exit predicates, Notes on the work, One Runtime, Product, The six verified defects, What this release does not do, File inventory: docs/releases/v0.3.0-notes.md

### Community 741 - "v0.4.0-checklist"
Cohesion: 0.46
Nodes (7): Branch cleanup, Completed foundation, Known release blockers, Release convergence, Remaining product lanes, v0.4.0 Release Checklist, File inventory: docs/releases/v0.4.0-checklist.md

### Community 742 - "v0.4.0-notes"
Cohesion: 0.46
Nodes (7): Deferred work, Foreman v0.4.0, Product, Security decision, Verification, Windows, File inventory: docs/releases/v0.4.0-notes.md

### Community 743 - "codex-app-server"
Cohesion: 0.25
Nodes (8): Approvals, Command execution approvals, Dynamic tool calls (experimental), File change approvals, MCP server elicitation requests, MCP tool-call approvals (apps), Permission requests, `tool/requestUserInput`

### Community 744 - "gemini-card"
Cohesion: 0.25
Nodes (7): models_gemini_flash_md, models_model_cards_gemini_3_5_flash_lite_md, models_model_cards_gemini_3_6_flash_md, models_model_cards_gemini_3_8_flash_md, models_model_cards_gemini_robotics_er_2_md, models_model_cards_gemini_robotics_on_device_2_md, models_model_cards_lyria_3_5_md

### Community 745 - "grok-pricing"
Cohesion: 0.46
Nodes (8): [Additional Information Regarding Models](#additional-information-regarding-models), Grok 4.6, Imagine API, [Model Aliases](#model-aliases), [Models](#models), Voice API, [Which model should I choose?](#which-model-should-i-choose), File inventory: docs/research/pel-release/sources/models/grok-pricing.md

### Community 746 - "openai-background"
Cohesion: 0.46
Nodes (7): Background mode, Cancelling a background response, Limits, Polling background responses, Response stream cursor, Streaming a background response, File inventory: docs/research/pel-release/sources/models/openai-background.md

### Community 747 - "CONSOLIDATED"
Cohesion: 0.46
Nodes (7): Defects found on the way, Targets adopted by `workflow-weight-reduction`, The measurement that matters, What must not be cut (union), Where the reviewers converged, Workflow weight review: consolidation, File inventory: docs/research/v050/workflow-reviews/CONSOLIDATED.md

### Community 748 - "gates-and-tests-gpt-6-astra"
Cohesion: 0.46
Nodes (7): Gates and tests review (GPT-6), Measure first, Model self-identification, Ranked proposals, What must not be cut, Where the weight is, File inventory: docs/research/v050/workflow-reviews/gates-and-tests-gpt-6-astra.md

### Community 749 - "orchestration-ceremony-gpt-6-astra"
Cohesion: 0.46
Nodes (7): Measure first, Model self-identification, Orchestration ceremony review (GPT-6), Ranked proposals, What must not be cut, Where the weight is, File inventory: docs/research/v050/workflow-reviews/orchestration-ceremony-gpt-6-astra.md

### Community 750 - "DECISION-audit-evidence-root"
Cohesion: 0.46
Nodes (7): Honest note, Superseded in part — the implemented form is better, The audit-evidence-root contradiction — architect decision, The distinction that resolves it, What must change, Why the obvious answers are wrong, File inventory: docs/research/vnext/DECISION-audit-evidence-root.md

### Community 751 - "VERIFY-opus-findings"
Cohesion: 0.46
Nodes (7): Architect verification of REVIEW-opus.md blocking findings, Consequence for the TerminusDB decision, Finding 1 — CONFIRMED, and the real mechanism identified, Finding 6 — CONFIRMED (arithmetic), partially my error, Findings 2-5 — ACCEPTED without independent re-verification, What Opus got right that is worth keeping, File inventory: docs/research/vnext/VERIFY-opus-findings.md

### Community 752 - "2026-08-03-total-georgecall-release-truth"
Cohesion: 0.46
Nodes (7): Global Constraints, Task 1: Add the canonical accomplishment ledger, Task 2: Expand the Total Georgecall release notes, Task 3: Correct active repository authority, Task 4: Verify, review, and publish, Total Georgecall Release Truth Implementation Plan, File inventory: docs/superpowers/plans/2026-08-03-total-georgecall-release-truth.md

### Community 753 - "2026-08-05-v030-r7b2-endstop-packages"
Cohesion: 0.46
Nodes (7): Global Constraints, R7B2 Endstop Packages Implementation Plan, Task 1: R7B2-A admission core, Task 2: R7B2-C obsolete homes, Task 3: R7B2-B lane adapter, Task 4: R7B2-D release verification, File inventory: docs/superpowers/plans/2026-08-05-v030-r7b2-endstop-packages.md

### Community 754 - "2026-08-05-v030-r7c-profile-use-leasing"
Cohesion: 0.46
Nodes (7): Global Constraints, R7C Profile-Use Leasing Implementation Plan, Task 1: Scoped profile-use lease, Task 2: Long-lived Node holder, Task 3: Live lane lifecycle, Task 4: Exact-candidate acceptance, File inventory: docs/superpowers/plans/2026-08-05-v030-r7c-profile-use-leasing.md

### Community 755 - "2026-08-03-council-preflight-path-normalization-design"
Cohesion: 0.46
Nodes (7): Council Preflight Path Normalization Design, Data flow, Decision, Error behavior, Problem, Verification, File inventory: docs/superpowers/specs/2026-08-03-council-preflight-path-normalization-design.md

### Community 756 - "2026-08-03-v029-release-artwork-design"
Cohesion: 0.46
Nodes (7): Data Flow, Integrity, Purpose, Scope, Total Georgecall Release Truth Design, Validation, File inventory: docs/superpowers/specs/2026-08-03-v029-release-artwork-design.md

### Community 757 - "auth-probes"
Cohesion: 0.43
Nodes (7): home_charl_fm_wt_foreman_dsl_release_openspec_changes_archive_2026_07_18_lifecycle_three_stage_out_not_authenticated_md, File inventory: openspec/changes/archive/2026-07-18-lifecycle-three-stage/auth-probes.md, claude — `claude auth status`, codex — `codex login status`, Empirical non-billing auth-probe commands (Task 0), grok — `grok models`, Summary table

### Community 758 - "ROADMAP"
Cohesion: 0.46
Nodes (7): File inventory: ROADMAP.md, Current authority, Foreman roadmap, Latest release: George's Odyssey (v0.3.1), Next program: v0.4.0, Released line, v0.3.1 completion record

### Community 759 - "spec"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/archive/2026-07-19-hard-mode-launcher/specs/hard-mode/spec.md, ADDED Requirement: pr-open pushes only after the gate and only host-side, ADDED Requirement: secrets and mounts follow least privilege, ADDED Requirement: worker-run supervises the worker through foreman-launch, Scenario: gate not passed blocks the PR, Scenario: launcher-only hard-mode task with no Docker, Spec delta — launcher-based hard mode (worker-run + pr-open)

### Community 760 - "spec"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/archive/2026-08-01-wsl-ci-parity-withdrawn/specs/ci/spec.md, ADDED Requirements, Requirement: ubuntu-latest runs shellcheck and the bats suite on every relevant PR, Requirement: windows-latest uses shell: bash for the Git-Bash half, Scenario: a PR touching a shell script triggers the Ubuntu job, Scenario: the Windows job exercises Git-Bash with pipefail honored, Spec delta — WSL CI parity

### Community 761 - "spec"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/captured-facts-convergence/specs/captured-facts/spec.md, ADDED Requirements, Requirement: a discovery-derived grok spec inlines the facts (write-first, zero reads-first), Requirement: discovery emits a captured-facts artifact with provenance, Scenario: a discovery-derived spec is write-first with facts inlined, Scenario: captured-facts.md carries provenance for every fact, Spec delta — captured-facts convergence artifact

### Community 762 - "tasks"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/council-review-plane/tasks.md, Out of scope, deliberately, Phase 1 — usable without any Council code, Phase 2 — Council decides, Phase 3 — reviewer supply, Phase 4 — wire it in without granting authority, Tasks — council-review-plane

### Community 763 - "design"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/credential-profile-authority/design.md, CLI, Design: external credential-profile authority, Filesystem contract, Out of scope (R7B and later), Record model, Selected approach

### Community 764 - "tasks"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/evidence-contracts/tasks.md, T1 — the evidence mechanism (this package is the implementation owner), T2 — declared deliverable sets and lane-type contracts, T3 — inconclusive semantics and the bounded loop, T4 — the planted-write positive control, T5 — mutation probe (unchanged scope), T6 — coverage and gate

### Community 765 - "tasks"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/external-memory-index/tasks.md, 1. Durable projection versions, 2. Qdrant adapter, 3. Qualification and epochs, 4. Hermetic embeddings, 5. Release lane, External MemoryIndex implementation tasks

### Community 766 - "design"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/graph-context-builder/design.md, Boundary, Deferred work, Design: deterministic graph context, Identity and budget, Selection, Verification

### Community 767 - "tasks"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/graph-context-builder/tasks.md, 1. Reconcile the release scope, 2. Build the context boundary, 3. Verify citations, 4. Ship the command, 5. Gate, Tasks: deterministic graph context

### Community 768 - "design"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/graph-eval-falsification/design.md, Deferred work, Design: graph evaluation boundary, File and process boundary, Release result, Run-set authority, Verdict

### Community 769 - "design"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/hermetic-foreman-appliance/design.md, Design: Hermetic Foreman appliance, Hard-mode host, Lock authority, Operator entry points, Product boundary, Verification

### Community 770 - "proposal"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/hermetic-foreman-appliance/proposal.md, Capabilities, Change: Hermetic Foreman appliance, Impact, New Capabilities, What Changes, Why

### Community 771 - "tasks"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/hermetic-foreman-appliance/tasks.md, 1. Appliance lock, 2. OCI build and operator entry points, 3. Control doctor, 4. Rootless hard-mode service, 5. Reproducibility and release lane, Hermetic Foreman appliance implementation tasks

### Community 772 - "proposal"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/knowledge-plane-refresh/proposal.md, Capabilities, Modified capability, New capability, Proposal: qualify the v0.4 knowledge plane, What changes, Why

### Community 773 - "tasks"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/lane-ownership-and-reaping/tasks.md, T1 — ownership primitives, T2 — state-based liveness, T3 — stall taxonomy, T4 — dispatch hygiene, T5 — tests and gate, red-first, Tasks — lane-ownership-and-reaping

### Community 774 - "design"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/lane-runtime-typescript/design.md, Context, Decisions, Design: lane-runtime-typescript, Failure handling, Interfaces, Verification

### Community 775 - "tasks"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/project-registry/tasks.md, 1. Registry codec and store, 2. Session command integration, 3. Honest recovery, 4. Project-bound projections, 5. Release lane, Project registry implementation tasks

### Community 776 - "tasks"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/v040-release-program/tasks.md, 1. Release authority and policy, 2. Product foundations, 3. Derived knowledge plane, 4. Release preparation, 5. Candidate verification, 6. Publication

### Community 777 - "tasks"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/vendor-concurrency-and-quota/tasks.md, T1 — topology and cap governance, T2 — extend the concurrency harness, T3 — entitlement and quota reporting, T4 — the destructive run (recorded evidence, or a recorded negative), T5 — docs, tests, gate, Tasks — vendor-concurrency-and-quota

### Community 778 - "spec"
Cohesion: 0.46
Nodes (7): File inventory: openspec/changes/wsl-tool-path-persistence/specs/environment/spec.md, ADDED Requirements, Requirement: grok-readiness UNIT tests do not depend on live grok reachability, Requirement: vendor CLIs resolve WSL-native without relying on ~/.bashrc, Scenario: a non-interactive lane resolves grok WSL-native, Scenario: grok-lane unit tests pass with no network access, Spec delta — WSL tool PATH persistence

### Community 779 - "design"
Cohesion: 0.46
Nodes (7): File inventory: openspec/schemas/foreman-architectural/templates/design.md, Context, Decisions, Design, Failure Handling, Interfaces, Verification

### Community 780 - "spec"
Cohesion: 0.46
Nodes (7): File inventory: openspec/schemas/foreman-architectural/templates/spec.md, Failure Scenarios, Normative Requirements, Out of Scope, Purpose, Spec, Success Scenarios

### Community 781 - "spec"
Cohesion: 0.46
Nodes (7): File inventory: openspec/schemas/foreman-bounded/templates/spec.md, Failure Scenarios, Normative Requirements, Out of Scope, Purpose, Spec, Success Scenarios

### Community 782 - "ROADMAP"
Cohesion: 0.46
Nodes (7): File inventory: packages/policy/src/fixtures/v040/ROADMAP.md, Current authority, Foreman roadmap, Latest release: George's Odyssey (v0.3.1), Next program: v0.4.0, Released line, v0.3.1 completion record

### Community 783 - "SKILL"
Cohesion: 0.46
Nodes (8): File inventory: plugins/foreman-qa/skills/foreman-code-quality/SKILL.md, Comment coverage (shdoc), Foreman code quality, Markdown style, Shell: shellcheck, safe edits, modes, The docs gate, TypeScript / Effect (Iron Rule), Verify what is staged

### Community 784 - "model-routing-evidence"
Cohesion: 0.46
Nodes (7): File inventory: skills/foreman/references/model-routing-evidence.md, Configurable Council profile, Current route, Evidence boundary, First-party source ledger, Model routing evidence, Practical limitations

### Community 785 - "stall"
Cohesion: 0.68
Nodes (7): File inventory: skills/foreman/scripts/lib/stall.sh, stall.sh script, stall_classify(), stall_from_pid(), stall_never_launched(), stall_no_output(), stall_report()

### Community 786 - "security"
Cohesion: 0.46
Nodes (7): File inventory: skills/scrapling/references/security.md, Cookie / token 处理, Prompt injection 与 AI-targeted 输出, Site pattern 处理, 安全与合规边界, 授权、robots.txt、ToS, 最小化与可复验

### Community 787 - "feature_request"
Cohesion: 0.46
Nodes (7): File inventory: skills/superpowers/.github/ISSUE_TEMPLATE/feature_request.md, Context, Environment (required), Is this appropriate for core Superpowers?, Proposed solution, What alternatives did you consider?, What problem does this solve?

### Community 788 - "stop-server"
Cohesion: 0.64
Nodes (7): File inventory: skills/superpowers/skills/brainstorming/scripts/stop-server.sh, command_has_server_id(), command_line_for_pid(), is_brainstorm_server(), mark_stopped(), read_expected_server_id(), stop-server.sh script

### Community 789 - "test-session-start"
Cohesion: 0.61
Nodes (7): File inventory: skills/superpowers/tests/hooks/test-session-start.sh, assert_command_output(), cleanup(), fail(), make_home(), pass(), test-session-start.sh script

### Community 790 - "graph-project-harness"
Cohesion: 0.61
Nodes (7): File inventory: tests/graph-project-harness.sh, expect_rc(), known_nodes(), LC_ALL, record(), graph-project-harness.sh script, write_good_log()

### Community 791 - "check-registry-compare"
Cohesion: 0.68
Nodes (7): File inventory: tests/lib/check-registry-compare.sh, compare(), derive_inventory(), fail(), main(), check-registry-compare.sh script, validate_registry()

### Community 792 - "spec"
Cohesion: 0.25
Nodes (8): Requirement: Externally fenced projection mutations, Scenario: A drainer lease is taken over, Scenario: An old retract settles last, Scenario: An old upsert settles last, Scenario: Desired state is retried, Scenario: Projection version allocation would overflow, Scenario: Recall returns a result, Scenario: The service fails

### Community 793 - "spec"
Cohesion: 0.25
Nodes (8): Requirement: Isolated hard-mode engine, Scenario: A host backing path is accessible, Scenario: A result archive tries to escape, Scenario: A worker discloses credential material, Scenario: A worker receives and returns task bytes, Scenario: Hard mode starts, Scenario: The API reports a compatible version, Scenario: The engine service is unavailable

### Community 794 - "2026-08-03-xai-live-smoke"
Cohesion: 0.52
Nodes (6): Compiler result, Provider result, Release decision, Scope, xAI live-smoke record — 2026-08-03, File inventory: components/council/docs/evidence/2026-08-03-xai-live-smoke.md

### Community 795 - "design"
Cohesion: 0.52
Nodes (6): Context, Decisions, Goals / Non-Goals, Migration Plan, Risks / Trade-offs, File inventory: components/council/openspec/changes/claude-provider-canary/design.md

### Community 796 - "tasks"
Cohesion: 0.52
Nodes (6): 1. Contract, 2. Process runner, 3. Claude adapter, 4. Grok preservation, 5. Workspace and verification, File inventory: components/council/openspec/changes/claude-provider-canary/tasks.md

### Community 797 - "design"
Cohesion: 0.52
Nodes (6): Context, Decisions, Goals / Non-Goals, Migration Plan, Risks / Trade-offs, File inventory: components/council/openspec/changes/codex-provider-canary/design.md

### Community 798 - "tasks"
Cohesion: 0.52
Nodes (6): 1. Contract, 2. Schema-file materializer, 3. Codex adapter, 4. Grok and Claude preservation, 5. Workspace and verification, File inventory: components/council/openspec/changes/codex-provider-canary/tasks.md

### Community 799 - "design"
Cohesion: 0.52
Nodes (6): Context, Decisions, Goals / Non-Goals, Migration Plan, Risks / Trade-offs, File inventory: components/council/openspec/changes/council-node24-ci/design.md

### Community 800 - "2026-08-06"
Cohesion: 0.52
Nodes (6): 1. What shipped, 2026-08-06, 2. What we learned, 3. What went wrong, 4. Where it stopped, File inventory: devlog/2026-08-06.md

### Community 801 - "2026-08-08-tool-check-coverage-reconciliation"
Cohesion: 0.52
Nodes (6): Controlled before (9 shell probes), Controlled now (3 TypeScript probe successors in `tests/positive-control-registry.tsv`), Summary, Tool-check positive-control coverage reconciliation — 2026-08-08, Uncontrolled now (6 TypeScript check successors deferred in `tests/positive-control-todo.tsv`), File inventory: docs/evidence/positive-control/2026-08-08-tool-check-coverage-reconciliation.md

### Community 802 - "README"
Cohesion: 0.52
Nodes (6): Audit lineage, Scope, TDD evidence, v0.2.9.0 Council Path Normalization Evidence, Verification, File inventory: docs/evidence/v029-council-path-normalization/README.md

### Community 803 - "README"
Cohesion: 0.52
Nodes (6): Council shadow outcome, Immutable change, Scope, v0.2.9.0 external Foreman dogfood, Verification, File inventory: docs/evidence/v029-external-dogfood/README.md

### Community 804 - "BRIEF"
Cohesion: 0.52
Nodes (6): Method, SPEC — OpenSpec conformance for the five WSL packages, The cause, The job, Verification, File inventory: docs/evidence/v029/s0-conform/BRIEF.md

### Community 805 - "BRIEF"
Cohesion: 0.52
Nodes (6): Deliverables, Scope, SPEC — readme-refresh, round 1, Verification, Why, File inventory: docs/evidence/v029/s10-readme/BRIEF.md

### Community 806 - "REWORK"
Cohesion: 0.52
Nodes (6): F1 — BLOCKING. An exclusion wildcard swallowed the founding case, F2 — BLOCKING. Round 6 dropped the non-bash hooks sweep, F3 — the regression that would have caught F1, REWORK — crlf-extensionless-hardening, round 7, Verification, File inventory: docs/evidence/v029/s1-crlf/REWORK.md

### Community 807 - "REWORK"
Cohesion: 0.52
Nodes (6): Context, Item 1 — fix L4-F1 (you MAY edit lib/lock.sh for this, and only this), Item 2 — the coverage-gap analysis you owe, Item 3 — non-vacuity of the suite itself, REWORK — L4: fix the finding your own suite caught, then finish what you owe, File inventory: docs/evidence/v029/s1-lock-L4/REWORK.md

### Community 808 - "BRIEF"
Cohesion: 0.52
Nodes (6): Scope — T1 through T3, SPEC — lane-ownership-and-reaping, round 1, This package is already partly built and in daily use, Verification — every case observed failing, Why it exists — nine strandings in one session, File inventory: docs/evidence/v029/s4-laneown/BRIEF.md

### Community 809 - "BRIEF"
Cohesion: 0.52
Nodes (6): Deliverables, Scope, SPEC — terminusdb-schema, round 1, The architectural decisions already made — do not relitigate them, Verification, File inventory: docs/evidence/v029/s9-tdbschema/BRIEF.md

### Community 810 - "2026-07-16-resume-checkpoint"
Cohesion: 0.52
Nodes (6): Merged to main, NOT merged — T3 (lane-run) and T5 (watch), Remaining path to close Round B / v0.2.0, Resume checkpoint — 2026-07-16 (durable-lanes Round B, session cut short), Standing context, File inventory: docs/notes/2026-07-16-resume-checkpoint.md

### Community 811 - "claude-cli"
Cohesion: 0.52
Nodes (7): [​](#cli-commands) CLI commands, [​](#cli-flags) CLI flags, CLI reference, [​](#see-also) See also, [​](#system-prompt-flags-in-resumed-conversations) System prompt flags in resumed conversations, [​](#system-prompt-flags) System prompt flags, File inventory: docs/research/pel-release/sources/models/claude-cli.md

### Community 812 - "openai-streaming.raw"
Cohesion: 0.52
Nodes (6): Advanced use cases, Enable streaming, Moderation risk, Read the responses, Streaming API responses, File inventory: docs/research/pel-release/sources/models/openai-streaming.raw.md

### Community 813 - "research-summary"
Cohesion: 0.52
Nodes (6): Evidence, Findings, FOREMAN_REPORT, Open questions, Summary, File inventory: docs/research/v040/research-summary.md

### Community 814 - "fable"
Cohesion: 0.52
Nodes (6): Conformance cases, Disagreements, Enhancements, Material defects, Verdict, File inventory: docs/reviews/2026-08-08-storage-port/fable.md

### Community 815 - "gpt-5.6-sol"
Cohesion: 0.52
Nodes (6): Conformance cases, Disagreements, Enhancements, Material defects, Verdict, File inventory: docs/reviews/2026-08-08-storage-port/gpt-5.6-sol.md

### Community 816 - "grok-4.5"
Cohesion: 0.52
Nodes (6): Conformance cases, Disagreements, Enhancements, Material defects, Verdict, File inventory: docs/reviews/2026-08-08-storage-port/grok-4.5.md

### Community 817 - "2026-07-15-foreman-combined-skill-design"
Cohesion: 0.52
Nodes (6): Foreman Combined Skill — Design, Modes, Non-goals (this scaffold), Success criteria, Summary, File inventory: docs/superpowers/specs/2026-07-15-foreman-combined-skill-design.md

### Community 818 - "2026-08-03-council-canary-nonce-binding-design"
Cohesion: 0.52
Nodes (6): Council Canary Nonce Binding Design, Decision, Problem, Schema identity, Verification, File inventory: docs/superpowers/specs/2026-08-03-council-canary-nonce-binding-design.md

### Community 819 - "2026-08-05-resume-safety-services-design"
Cohesion: 0.52
Nodes (6): Architecture, Goal, Resume Safety Services Design, Safety boundary, Test strategy, File inventory: docs/superpowers/specs/2026-08-05-resume-safety-services-design.md

### Community 820 - "2026-08-05-round-resume-decision-design"
Cohesion: 0.52
Nodes (6): Architecture, Goal, Round Resume Decision Design, Scope, Test strategy, File inventory: docs/superpowers/specs/2026-08-05-round-resume-decision-design.md

### Community 821 - "tasks"
Cohesion: 0.48
Nodes (6): home_charl_fm_wt_foreman_dsl_release_openspec_changes_v030_release_program_tools_md, File inventory: openspec/changes/v030-release-program/tasks.md, 0. Authority and program baseline, 1. Program execution, 2. Release convergence, Tasks: v0.3.0 release program

### Community 822 - "measurements"
Cohesion: 0.48
Nodes (6): home_charl_fm_wt_foreman_dsl_release_plugins_foreman_qa_skills_foreman_qa_references_output_last_session_none_md, File inventory: plugins/foreman-qa/skills/foreman-qa/references/measurements.md, A figure carries a tree, not just a command, Claim-provenance tally, Measurement provenance — 2026-08-07, session.bats assertion counts

### Community 823 - "proposal"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/archive/2026-07-17-test-harness-fork-tax/proposal.md, Change: test-harness fork-tax reduction, Impact, Out of scope (deferred to v0.2.5), What changes, Why

### Community 824 - "design"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/archive/2026-07-18-lifecycle-three-stage/design.md, Approach, Design — lifecycle-three-stage, Execution, Motivation, Sequencing

### Community 825 - "design"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/archive/2026-07-19-hard-mode-launcher/design.md, Approach, Design — hard-mode-launcher (approved spec), Execution (next release), Reconciliation (post-ship, Task 7), Research basis (2026-07-18, cited)

### Community 826 - "WITHDRAWN"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/archive/2026-07-30-terminusdb-withdrawn-schema/WITHDRAWN.md, Also rejected, What must NOT be lost, What replaced it, Why, WITHDRAWN 2026-07-30 — TerminusDB

### Community 827 - "design"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/archive/2026-08-01-wsl-ci-parity-withdrawn/design.md, Approach, Citations (load-bearing), Design — wsl-ci-parity, Key decision, Verification

### Community 828 - "proposal"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/build-determinism/proposal.md, Acceptance Evidence, Change: build-determinism, Exclusions, Purpose, Scope

### Community 829 - "proposal"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/council-v029-preflight-release/proposal.md, Council v0.2.9.0 preflight release, Non-goals, Purpose, Result, Scope

### Community 830 - "design"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/crlf-extensionless-hardening/design.md, Approach, Citations (load-bearing), Design — crlf-extensionless-hardening, Key decision, Verification

### Community 831 - "PARKED"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/foreman-discover-lane/PARKED.md, PARKED 2026-08-01 — v0.3.x candidate, not in the v0.2.9 scope, Related, What must NOT be lost, What would make it checkable, Why it is parked rather than implemented

### Community 832 - "tasks"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/graph-eval-falsification/tasks.md, 1. Reconcile scope, 2. Build the evaluator, 3. Ship the command and evidence, 4. Gate, Tasks: graph evaluation boundary

### Community 833 - "tasks"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/profile-use-leasing/tasks.md, Acceptance, Holder and live lane, R7C Endstop package, Tasks: profile-use leasing, TypeScript and Effect core

### Community 834 - "design"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/regression-harness-tiers/design.md, Alternatives REJECTED, Approach, Cuts and falsifiability fixes (2026-07-28 fix round), Design — regression harness tiers, Risks

### Community 835 - "design"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/round-resume-typescript/design.md, Boundaries, Components, Decision order, Design: typed round-resume decision, Selected approach

### Community 836 - "proposal"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/session-store-recovery/proposal.md, Acceptance Evidence, Change: session-store-recovery, Exclusions, Purpose, Scope

### Community 837 - "PARKED"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/spec-triage-gate/PARKED.md, PARKED 2026-08-01 — v0.3.x candidate, not in the v0.2.9 scope, Related, What is NOT the blocker, What must be decided before it un-parks, Why it is parked rather than implemented

### Community 838 - "proposal"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/test-infrastructure-hardening/proposal.md, And a second class, measured after this package was first written: the check itself is wrong, Change: test-infrastructure-hardening, Impact, What changes, Why

### Community 839 - "proposal"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/v040-release-program/proposal.md, Change: v040-release-program, Impact, Out of scope, What changes, Why

### Community 840 - "design"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/wsl-launcher-shipped/design.md, Approach, Citations (load-bearing), Design — wsl-launcher-shipped, Key decision, Verification

### Community 841 - "design"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/wsl-preflight/design.md, Approach, Citations (load-bearing), Design — wsl-preflight, Key decisions, Verification

### Community 842 - "design"
Cohesion: 0.52
Nodes (6): File inventory: openspec/changes/wsl-tool-path-persistence/design.md, Approach, Citations (load-bearing), Design — wsl-tool-path-persistence, Key decision, Verification

### Community 843 - "proposal"
Cohesion: 0.52
Nodes (6): File inventory: openspec/schemas/foreman-architectural/templates/proposal.md, Acceptance Evidence, Exclusions, Proposal, Purpose, Scope

### Community 844 - "proposal"
Cohesion: 0.52
Nodes (6): File inventory: openspec/schemas/foreman-bounded/templates/proposal.md, Acceptance evidence, Exclusions, In scope, Proposal, Purpose

### Community 845 - "supervisor-main"
Cohesion: 0.52
Nodes (6): File inventory: packages/orchestration/src/supervisor-main.ts, io, pending, resolveSkillRoot(), skillRoot, writeFully()

### Community 846 - "run-tests"
Cohesion: 0.52
Nodes (6): File inventory: scripts/run-tests.ts, childEnv, empty, fail(), patterns, result

### Community 847 - "ownership"
Cohesion: 0.52
Nodes (6): File inventory: skills/council/references/ownership.md, Architect owns, Council ownership — Foreman, Council, architect, Council owns, Decision guide, Foreman owns

### Community 848 - "query"
Cohesion: 0.52
Nodes (6): File inventory: skills/graphify/references/query.md, For /graphify explain, For /graphify path, graphify reference: query, path, explain, Step 0 — Constrained query expansion (REQUIRED before traversal), Step 1 — Traversal

### Community 849 - "cookie-vault"
Cohesion: 0.52
Nodes (6): File inventory: skills/scrapling/references/cookie-vault.md, Cookie 保险库模板, Playwright 格式（StealthyFetcher/DynamicFetcher 用）, 备注, 模板：添加新站点, 示例站点 (example.com)

### Community 850 - "upstream-map"
Cohesion: 0.52
Nodes (6): File inventory: skills/scrapling/references/upstream-map.md, CLI quick path, Scope boundary, sync checklist, Upstream alignment map, Upstream source of truth

### Community 851 - "2026-05-07-pi-extension-and-evals"
Cohesion: 0.52
Nodes (6): File inventory: skills/superpowers/docs/superpowers/plans/2026-05-07-pi-extension-and-evals.md, Pi Extension and Evals Implementation Plan, Task 1: Pi package manifest and extension tests, Task 2: Pi tool mapping reference, Task 3: Drill Pi backend and session log normalization, Task 4: Documentation and full verification

### Community 852 - "condition-based-waiting-example"
Cohesion: 0.52
Nodes (6): File inventory: skills/superpowers/skills/systematic-debugging/condition-based-waiting-example.ts, ref_threads_thread_manager, ref_threads_types, waitForEvent(), waitForEventCount(), waitForEventMatch()

### Community 853 - "SKILL"
Cohesion: 0.52
Nodes (6): File inventory: skills/superpowers/skills/using-superpowers/SKILL.md, Platform Adaptation, Red Flags, Skill Priority, The Rule, User Instructions

### Community 854 - "start-server.test"
Cohesion: 0.67
Nodes (6): File inventory: skills/superpowers/tests/brainstorm-server/start-server.test.sh, cleanup(), fail(), make_fake_uname(), pass(), start-server.test.sh script

### Community 855 - "test-sdd-workspace"
Cohesion: 0.67
Nodes (6): File inventory: skills/superpowers/tests/claude-code/test-sdd-workspace.sh, cleanup(), fail(), main(), pass(), test-sdd-workspace.sh script

### Community 856 - "spec"
Cohesion: 0.29
Nodes (7): Requirement: Bounded project export and restore, Scenario: A moved project opens without a move command, Scenario: A project moves, Scenario: An empty destination restores a project, Scenario: An operator clones a project, Scenario: Registration state is ambiguous, Scenario: Registration stops after store publication

### Community 857 - "spec"
Cohesion: 0.29
Nodes (7): Requirement: Exact-candidate release convergence, Scenario: Candidate bytes change after a pass, Scenario: Publication is interrupted, Scenario: Publication preparation starts, Scenario: Publication succeeds, Scenario: The candidate integrates and publishes main, Scenario: The release candidate is verified

### Community 858 - "RELEASE-NOTES"
Cohesion: 0.29
Nodes (7): Agentskills Compliance, Bug Fixes, Community, Improvements, Maintenance, New Features, v5.0.1 (2026-03-10)

### Community 859 - "foreman-advisor"
Cohesion: 0.60
Nodes (5): Foreman Advisor, How to answer, Never, When you’re called, File inventory: agents/foreman-advisor.md

### Community 860 - "bugeventlog"
Cohesion: 0.33
Nodes (6): 2026-08-02 — Event 20: first Council bundle used equal base and head commits, Enhancement, Evidence, Impact, Root cause, What happened

### Community 861 - "bugeventlog"
Cohesion: 0.33
Nodes (6): 2026-08-02 — Event 21: Codex transcript contaminated the Council verdict body, Enhancement, Evidence, Impact, Root cause, What happened

### Community 862 - "bugeventlog"
Cohesion: 0.33
Nodes (6): 2026-08-02 — Event 23: docs-check tail hid the nested import finding surface, Enhancement, Evidence, Impact, Root cause, What happened

### Community 863 - "bugeventlog"
Cohesion: 0.33
Nodes (6): 2026-08-02 — Event 24: Task 2 commit landed; operational docs still said uncommitted, Enhancement, Evidence, Impact, Root cause, What happened

### Community 864 - "bugeventlog"
Cohesion: 0.33
Nodes (6): 2026-08-02 — Event 25: docs-check and localization guards were not fail-capable against injection, Enhancement, Evidence, Impact, Root cause, What happened

### Community 865 - "bugeventlog"
Cohesion: 0.33
Nodes (6): 2026-08-02 — Event 26: docs-check baseline left at 8 after rework added two tests, Enhancement, Evidence, Impact, Root cause, What happened

### Community 866 - "bugeventlog"
Cohesion: 0.33
Nodes (6): 2026-08-02 — Event 27: raw-token markdownlint guard and Council release-authority prose, Enhancement, Impact, RED controls, Root cause, What happened

### Community 867 - "bugeventlog"
Cohesion: 0.33
Nodes (6): 2026-08-02 — Event 28: JSONC decoder silent success on malformed comments, Enhancement, Impact, RED control, Root cause, What happened

### Community 868 - "bugeventlog"
Cohesion: 0.33
Nodes (6): 2026-08-02 — Event 29: JSONC nonstandard numerics and handoff open race, Enhancement, Impact, RED controls, Root cause, What happened

### Community 869 - "bugeventlog"
Cohesion: 0.33
Nodes (6): 2026-08-02 — Review-loop and tooling defects found while dogfooding Foreman on itself, Event 1 — a stale lane worktree produced two false HIGH findings in one audit round, Event 2 — verification that re-ran the spec's own commands confirmed the wrong answer twice, Event 3 — seven exec-bit drops, and the gate written to catch them was blind to its own file, Event 4 — a generated index counted as a citation, nearly preserving 2.6MB of dead weight, Event 5 — tooling that loses vendor rounds and breaks the project it indexes

### Community 870 - "visual-pass"
Cohesion: 0.60
Nodes (5): Failed PDF capture retained as a diagnostic, Inspected tiles and contribution, PixelRAG Visual Pass, Source and command, File inventory: components/council/docs/research/security/visual-pass.md

### Community 871 - "spec"
Cohesion: 0.60
Nodes (5): MODIFIED Requirements, Requirement: Every selected model passes a live canary, Scenario: A provider returns valid JSON and then cancels, Scenario: Claude rejects a file prompt variant, File inventory: components/council/openspec/changes/claude-provider-canary/specs/prompt-preflight/spec.md

### Community 872 - "tasks"
Cohesion: 0.60
Nodes (5): 1. Regression, 2. Workflows, 3. Documentation and OpenSpec, 4. Verification, File inventory: components/council/openspec/changes/council-node24-ci/tasks.md

### Community 873 - "README"
Cohesion: 0.60
Nodes (5): Foreman v0.4 appliance, Hard mode, Local control smoke, Reproducibility, File inventory: containers/appliance/README.md

### Community 874 - "README"
Cohesion: 0.60
Nodes (5): Receipt contract, Results, Scope, v0.2.9.0 Council live-canary evidence, File inventory: docs/evidence/v029-council-live-canaries/README.md

### Community 875 - "2026-07-15-planning-fidelity"
Cohesion: 0.60
Nodes (5): Planning fidelity — thoughts + a prompt to run after the next release, Stubbed ideas (ranked by leverage), The prompt (paste into a Foreman soft-mode session), Why (grounded in the durable-lanes build, 2026-07-15), File inventory: docs/notes/2026-07-15-planning-fidelity.md

### Community 876 - "TOOLS-AND-VAULT"
Cohesion: 0.60
Nodes (5): Research tools and Foreman vault, Source handling, Tool updates, Vault installation, File inventory: docs/research/pel-release/TOOLS-AND-VAULT.md

### Community 877 - "2026-08-05-resume-safety-services"
Cohesion: 0.60
Nodes (5): Global constraints, Resume Safety Services Implementation Plan, Task 1: Add pure boundary classifiers, Task 2: Add Effect services and live layers, File inventory: docs/superpowers/plans/2026-08-05-resume-safety-services.md

### Community 878 - "2026-08-05-round-resume-decision"
Cohesion: 0.60
Nodes (5): Global Constraints, Round Resume Decision Implementation Plan, Task 1: Select the current typed round, Task 2: Decide safe round resume, File inventory: docs/superpowers/plans/2026-08-05-round-resume-decision.md

### Community 879 - "bootstrap-windows"
Cohesion: 0.87
Nodes (5): Have(), Log(), ScoopInstall(), WingetInstall(), File inventory: env/bootstrap-windows.ps1

### Community 880 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/agy-lane-activation/proposal.md, Change: agy-lane-activation, Impact, What changes, Why

### Community 881 - "design"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-18-docs-readme-refresh/design.md, Approach, Design — docs-readme-refresh, Execution, Motivation

### Community 882 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-18-docs-readme-refresh/proposal.md, Change: docs-readme-refresh, Impact, What changes, Why

### Community 883 - "design"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-18-grok-lane-activation/design.md, Approach, Design — grok-lane-activation, Execution, Research basis (2026-07-18, verified)

### Community 884 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-18-grok-lane-activation/proposal.md, Change: grok-lane-activation, Impact, What changes, Why

### Community 885 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-18-lifecycle-three-stage/proposal.md, Change: lifecycle-three-stage, Impact, What changes, Why

### Community 886 - "design"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-18-posix-cascade-parity/design.md, Approach, Design — posix-cascade-parity, Execution, Research basis (2026-07-18, probed live on this WSL)

### Community 887 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-18-posix-cascade-parity/proposal.md, Change: posix-cascade-parity, Impact, What changes, Why

### Community 888 - "design"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-18-t5b-concurrency-verdict/design.md, Approach, Design — t5b-concurrency-verdict, Execution, Research basis (2026-07-18, cited)

### Community 889 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-18-t5b-concurrency-verdict/proposal.md, Change: t5b-concurrency-verdict, Impact, What changes, Why

### Community 890 - "design"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-18-worktree-hardening/design.md, Approach, Design — worktree-hardening, Execution, Research basis (2026-07-18, cited)

### Community 891 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-18-worktree-hardening/proposal.md, Change: worktree-hardening, Impact, What changes, Why

### Community 892 - "design"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-18-wsl-reliability-env-refresh/design.md, Approach, Design — wsl-reliability-env-refresh, Execution, Research basis (2026-07-18, probed live)

### Community 893 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-18-wsl-reliability-env-refresh/proposal.md, Change: wsl-reliability-env-refresh (full WSL setup + reliability + deps), Impact, What changes, Why

### Community 894 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-19-hard-mode-launcher/proposal.md, Change: hard-mode-launcher, Impact, What changes, Why

### Community 895 - "design"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-30-terminusdb-withdrawn-operations/design.md, Alternatives REJECTED, Approach, Design -- terminusdb-operations, Risks

### Community 896 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-30-terminusdb-withdrawn-operations/proposal.md, Change: terminusdb-operations, Impact, What changes, Why

### Community 897 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-30-terminusdb-withdrawn-schema/proposal.md, Change: terminusdb-schema, Impact, What changes, Why

### Community 898 - "tasks"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-07-30-terminusdb-withdrawn-schema/tasks.md, T1 -- author the frozen schema, T2 -- competency question audit, T3 -- gate, Tasks -- terminusdb-schema

### Community 899 - "WITHDRAWN"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-08-01-wsl-ci-parity-withdrawn/WITHDRAWN.md, What must NOT be lost, What replaced it, Why, WITHDRAWN 2026-08-01 — wsl-ci-parity

### Community 900 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-08-01-wsl-ci-parity-withdrawn/proposal.md, Change: wsl-ci-parity, Impact, What changes, Why

### Community 901 - "WITHDRAWN"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/archive/2026-08-01-wsl-seam-doctrine-withdrawn/WITHDRAWN.md, What must NOT be lost, What replaced it, Why, WITHDRAWN 2026-08-01 — wsl-seam-doctrine

### Community 902 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/bounded-execution-terminal-policy/proposal.md, Change: bounded-execution-terminal-policy, Impact, What changes, Why

### Community 903 - "design"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/captured-facts-convergence/design.md, Approach, Design — captured-facts-convergence, Key decisions, Verification

### Community 904 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/captured-facts-convergence/proposal.md, Change: captured-facts-convergence, Impact, What changes, Why

### Community 905 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/council-review-plane/proposal.md, Change: council-review-plane, Impact, What Changes, Why

### Community 906 - "design"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/council-v029-preflight-release/design.md, Design, Evidence flow, Failure policy, Release boundary

### Community 907 - "tasks"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/council-v029-preflight-release/tasks.md, 1. Product, 2. Verification, 3. Release, Tasks

### Community 908 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/credential-profile-authority/proposal.md, Change: credential-profile-authority, Scope, What changes, Why

### Community 909 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/crlf-extensionless-hardening/proposal.md, Change: crlf-extensionless-hardening, Impact, What changes, Why

### Community 910 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/decision-lineage-and-telemetry/proposal.md, Change: decision-lineage-and-telemetry, Impact, What changes, Why

### Community 911 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/doctrine-reality-drift/proposal.md, Change: doctrine-reality-drift, Impact, What changes, Why

### Community 912 - "design"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/foreman-discover-lane/design.md, Approach, Design — foreman-discover-lane, Key decisions, Verification

### Community 913 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/foreman-discover-lane/proposal.md, Change: foreman-discover-lane, Impact, What changes, Why

### Community 914 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/formal-model-suite/proposal.md, Change: formal-model-suite, Impact, What changes, Why

### Community 915 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/graph-context-builder/proposal.md, Change: Ship the deterministic graph-context builder, Impact, What changes, Why

### Community 916 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/graph-eval-falsification/proposal.md, Change: Ship the graph evaluation boundary, Impact, What changes, Why

### Community 917 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/graph-store-port/proposal.md, Change: graph-store-port, Impact, What changes, Why

### Community 918 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/grok-secret-scan-typescript/proposal.md, Change: grok-secret-scan-typescript, Scope, What changes, Why

### Community 919 - "tasks"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/grok-secret-scan-typescript/tasks.md, Cold-audit attempt 1 repairs, Later work packages, R6: bounded fixture-aware secret scan, Tasks: grok-secret-scan-typescript

### Community 920 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/lane-ownership-and-reaping/proposal.md, Change: lane-ownership-and-reaping, Impact, What changes, Why

### Community 921 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/lane-runtime-typescript/proposal.md, Change: lane-runtime-typescript, Impact, What changes, Why

### Community 922 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/launcher-node-port/proposal.md, Change: launcher-node-port, Impact, What changes, Why

### Community 923 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/lock-primitive-hardening/proposal.md, Change: lock-primitive-hardening, Impact, What changes, Why

### Community 924 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/node-typescript-runtime/proposal.md, Change: node-typescript-runtime, Impact, What changes, Why

### Community 925 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/profile-bound-lane-admission/proposal.md, Change: profile-bound-lane-admission, Scope, What changes, Why

### Community 926 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/profile-bound-setup-preflight/proposal.md, Change: profile-bound-setup-preflight, Scope, What changes, Why

### Community 927 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/profile-use-leasing/proposal.md, Change: profile-use-leasing, Scope, What changes, Why

### Community 928 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/regression-harness-tiers/proposal.md, Impact, Proposal — regression harness tiers, What changes, Why

### Community 929 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/resume-count-events-typescript/proposal.md, Proposal: attempt-bound durable resume counts, Scope, What changes, Why

### Community 930 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/resume-safety-services-typescript/proposal.md, Change: resume-safety-services-typescript, Impact, What changes, Why

### Community 931 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/resume-supervisor-typescript/proposal.md, Change: resume-supervisor-typescript, Scope, What changes, Why

### Community 932 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/round-ownership-default/proposal.md, Change: round-ownership-default, Impact, What changes, Why

### Community 933 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/round-resume-typescript/proposal.md, Change: round-resume-typescript, Impact, What changes, Why

### Community 934 - "design"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/spec-triage-gate/design.md, Approach, Design — spec-triage-gate, Key decisions, Verification

### Community 935 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/spec-triage-gate/proposal.md, Change: spec-triage-gate, Impact, What changes, Why

### Community 936 - "coverage-matrix"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/v030-release-program/coverage-matrix.md, Metric rules, Release boundaries and carried work, Released truth anchors, v0.3.0 specification coverage matrix

### Community 937 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/v030-release-program/proposal.md, Change: v030-release-program, Impact, What changes, Why

### Community 938 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/v050-release-program/proposal.md, Change: v050-release-program, Impact, What changes, Why

### Community 939 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/vendor-adapter-contract/proposal.md, Change: vendor-adapter-contract, Impact, What changes, Why

### Community 940 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/vendor-concurrency-and-quota/proposal.md, Change: vendor-concurrency-and-quota, Impact, What changes, Why

### Community 941 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/vendor-preflight/proposal.md, Change: vendor-preflight, Impact, What changes, Why

### Community 942 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/work-dag-projection/proposal.md, Change: Ship the deterministic work-DAG projection, Impact, What changes, Why

### Community 943 - "tasks"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/work-dag-projection/tasks.md, 1. Reconcile the release scope, 2. Qualify the projector, 3. Gate, Tasks: deterministic work-DAG projection

### Community 944 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/workflow-weight-reduction/proposal.md, Change: workflow-weight-reduction, Impact, What changes, Why

### Community 945 - "design"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/workload-fit-accounting/design.md, Approach, Design — workload-fit-accounting, Key decisions, Verification

### Community 946 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/workload-fit-accounting/proposal.md, Change: workload-fit-accounting, Impact, What changes, Why

### Community 947 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/wsl-launcher-shipped/proposal.md, Change: wsl-launcher-shipped, Impact, What changes, Why

### Community 948 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/wsl-preflight/proposal.md, Change: wsl-preflight, Impact, What changes, Why

### Community 949 - "proposal"
Cohesion: 0.60
Nodes (5): File inventory: openspec/changes/wsl-tool-path-persistence/proposal.md, Change: wsl-tool-path-persistence, Impact, What changes, Why

### Community 950 - "qdrant-live.test / qdrant-memory-index"
Cohesion: 0.53
Nodes (3): File inventory: packages/memory/src/qdrant-live.test.ts, LiveEmbedding, EmbeddingPort

### Community 951 - "SKILL"
Cohesion: 0.60
Nodes (5): File inventory: plugins/foreman-qa/skills/foreman-qa-maintenance/SKILL.md, Foreman QA maintenance, Maintenance ritual, Release gate, Source of truth

### Community 952 - "init-firewall"
Cohesion: 0.80
Nodes (5): File inventory: sandbox/init-firewall.sh, apply(), check(), resolve_and_allow(), init-firewall.sh script

### Community 953 - "README"
Cohesion: 0.60
Nodes (5): File inventory: site/README.md, Content notes, Files, Foreman documentation site, Preview

### Community 954 - "durable-preflight"
Cohesion: 0.80
Nodes (5): File inventory: skills/foreman/scripts/durable-preflight.sh, dp_one(), dp_verify(), main(), durable-preflight.sh script

### Community 955 - "release-policy"
Cohesion: 0.60
Nodes (5): File inventory: skills/foreman/scripts/lib/release-policy.sh, ARTIFACT, EXIT_CONFIG, EXIT_MISSING_CLI, release-policy.sh script

### Community 956 - "platform_support"
Cohesion: 0.60
Nodes (5): File inventory: skills/superpowers/.github/ISSUE_TEMPLATE/platform_support.md, Does this tool have a plugin or extension system?, Environment (required), Have you tried manual installation?, Which IDE or platform?

### Community 957 - "test-pressure-1"
Cohesion: 0.60
Nodes (5): File inventory: skills/superpowers/skills/systematic-debugging/test-pressure-1.md, Choose A, B, or C, Pressure Test 1: Emergency Production Fix, Scenario, Your Options

### Community 958 - "test-pressure-2"
Cohesion: 0.60
Nodes (5): File inventory: skills/superpowers/skills/systematic-debugging/test-pressure-2.md, Choose A, B, or C, Pressure Test 2: Sunk Cost + Exhaustion, Scenario, Your Options

### Community 959 - "test-pressure-3"
Cohesion: 0.60
Nodes (5): File inventory: skills/superpowers/skills/systematic-debugging/test-pressure-3.md, Choose A, B, or C, Pressure Test 3: Authority + Social Pressure, Scenario, Your Options

### Community 960 - "run-all / run-test"
Cohesion: 0.47
Nodes (4): File inventory: skills/superpowers/tests/explicit-skill-requests/run-all.sh, File inventory: skills/superpowers/tests/explicit-skill-requests/run-test.sh, run-all.sh script, run-test.sh script

### Community 961 - "reap-stale-lanes"
Cohesion: 0.87
Nodes (5): File inventory: tools/reap-stale-lanes.sh, cputime_secs(), etime_secs(), is_dispatched_lane(), reap-stale-lanes.sh script

### Community 962 - "spec"
Cohesion: 0.33
Nodes (6): Requirement: Hermetic Foreman appliance, Scenario: A new operator bootstraps Foreman, Scenario: A skill is installed, Scenario: Credentials are needed, Scenario: Semantic memory is enabled, Scenario: The appliance builds

### Community 963 - "spec"
Cohesion: 0.33
Nodes (6): Requirement: Projection epoch isolation, Scenario: A projection is retracted twice, Scenario: A rebuild fails before activation, Scenario: A rebuild succeeds, Scenario: Recall races with activation, Scenario: Writes race with rebuild

### Community 964 - "spec"
Cohesion: 0.33
Nodes (6): Requirement: Qdrant MemoryIndex adapter, Scenario: A desired-state key is encoded, Scenario: A mutation returns before completion, Scenario: A payload index is missing, Scenario: A Qdrant deployment has an unsupported topology, Scenario: The external adapter is selected

### Community 965 - "RELEASE-NOTES"
Cohesion: 0.33
Nodes (6): Breaking Changes, Bug Fixes, Documentation, Improvements, New Features, v3.1.0 (2025-10-17)

### Community 966 - "SKILL"
Cohesion: 0.33
Nodes (6): 1. Rich Description Field, 2. Keyword Coverage, 3. Descriptive Naming, 4. Token Efficiency (Critical), 5. Cross-Referencing Other Skills, Skill Discovery Optimization (SDO)

### Community 967 - "bugeventlog"
Cohesion: 0.40
Nodes (5): 2026-07-31 — Event 13: the obligations ledger held three closed items open, Enhancement, Every remaining open and blocked row was checked against the tree, Obligation 10 named a withdrawn dependency, The ledger did not match the tree

### Community 968 - "bugeventlog"
Cohesion: 0.40
Nodes (5): 2026-07-31 — Event 14: a review agent wrote to, and then deleted from, the live store it was reviewing, Enhancement, Repair, The reviewer changed the record it was checking, There is no read-only path today

### Community 969 - "bugeventlog"
Cohesion: 0.40
Nodes (5): 2026-08-01 — Event 19: four sites advertised a vendor lane that the fifth could not build, A config directory was not an isolation boundary, Enhancement, Four sites said the Claude lane was runnable, T7 removed the operational advertising

### Community 970 - "run_known_bad"
Cohesion: 0.80
Nodes (4): expect_fail(), PYTHONPATH, run_known_bad.sh script, File inventory: docs/evidence/v029/s9-storeport/superseded-shell-round/graph_store_harness/run_known_bad.sh

### Community 971 - "effect-docs-url-inventory"
Cohesion: 0.40
Nodes (5): Community, DevTools, Other, Resources, File inventory: docs/research/2026-08-06-testing-council/effect-docs-url-inventory.md

### Community 972 - "gemini-pricing"
Cohesion: 0.40
Nodes (5): Batch, Flex, Gemini 3.7 Flash, Priority, Standard

### Community 973 - "gemini-pricing"
Cohesion: 0.40
Nodes (5): Batch, Flex, Gemini 3.6 Flash, Priority, Standard

### Community 974 - "gemini-pricing"
Cohesion: 0.40
Nodes (5): Batch, Flex, Gemini 3.5 Flash, Priority, Standard

### Community 975 - "gemini-pricing"
Cohesion: 0.40
Nodes (5): Batch, Flex, Gemini 3.5 Flash-Lite, Priority, Standard

### Community 976 - "gemini-pricing"
Cohesion: 0.40
Nodes (5): Batch, Flex, Gemini 3 Flash Preview, Priority, Standard

### Community 977 - "gemini-pricing"
Cohesion: 0.40
Nodes (5): Batch, Flex, Gemini 3 Pro Image (Nano Banana Pro) 🍌, Priority, Standard

### Community 978 - "gemini-pricing"
Cohesion: 0.40
Nodes (5): Batch, Flex, Gemini 2.5 Flash, Priority, Standard

### Community 979 - "gemini-pricing"
Cohesion: 0.40
Nodes (5): Batch, Flex, Gemini 2.5 Flash-Lite, Priority, Standard

### Community 980 - "gemini-pricing"
Cohesion: 0.40
Nodes (5): Batch, Flex, Gemini 2.5 Flash Image (Nano Banana) 🍌, Priority, Standard

### Community 981 - "REPORT_A-drift"
Cohesion: 0.70
Nodes (4): DRIFT AUDIT — v0.2.5 plan (2026-07-16) vs shipped v0.2.0 (main @ fe61fa1), Per-task drift table, The 5 most important amendments (priority order), File inventory: docs/research/v025-plan-audit/REPORT_A-drift.md

### Community 982 - "2026-08-03-council-canary-nonce-binding"
Cohesion: 0.70
Nodes (4): Council Canary Nonce Binding Implementation Plan, Global Constraints, Task 1: Bind the canary response nonce, File inventory: docs/superpowers/plans/2026-08-03-council-canary-nonce-binding.md

### Community 983 - "2026-08-03-council-preflight-path-normalization"
Cohesion: 0.70
Nodes (4): Council Preflight Path Normalization Implementation Plan, Global Constraints, Task 1: Normalize preflight runtime paths, File inventory: docs/superpowers/plans/2026-08-03-council-preflight-path-normalization.md

### Community 984 - "README"
Cohesion: 0.70
Nodes (4): docs/superpowers — historical plan and design records, What is here, Why this directory is not renamed, File inventory: docs/superpowers/README.md

### Community 985 - "wsl-clock-preflight"
Cohesion: 0.80
Nodes (4): default_host_clock(), read_clock(), wsl-clock-preflight.sh script, File inventory: env/wsl-clock-preflight.sh

### Community 986 - "tasks"
Cohesion: 0.70
Nodes (4): File inventory: openspec/changes/build-determinism/tasks.md, Allowed file scope, Tasks, Verification

### Community 987 - "tasks"
Cohesion: 0.70
Nodes (4): File inventory: openspec/changes/credential-profile-authority/tasks.md, Later work packages (R7B+), R7A: external credential-profile authority, Tasks: credential-profile-authority

### Community 988 - "proposal"
Cohesion: 0.70
Nodes (4): File inventory: openspec/changes/evidence-contracts/proposal.md, Impact, What Changes, Why

### Community 989 - "tasks"
Cohesion: 0.70
Nodes (4): File inventory: openspec/changes/lane-runtime-typescript/tasks.md, Allowed file scope, Tasks, Verification

### Community 990 - "tasks"
Cohesion: 0.70
Nodes (4): File inventory: openspec/changes/profile-bound-setup-preflight/tasks.md, Later work packages, R7B1: profile-bound Setup preflight, Tasks: profile-bound-setup-preflight

### Community 991 - "tasks"
Cohesion: 0.70
Nodes (4): File inventory: openspec/changes/resume-count-events-typescript/tasks.md, Later work packages, R5C: attempt-bound durable resume counts, Tasks: resume-count-events-typescript

### Community 992 - "tasks"
Cohesion: 0.70
Nodes (4): File inventory: openspec/changes/resume-safety-services-typescript/tasks.md, Later work packages, R5B: Effect observation services, Tasks: resume-safety-services-typescript

### Community 993 - "tasks"
Cohesion: 0.70
Nodes (4): File inventory: openspec/changes/round-resume-typescript/tasks.md, Later work packages, R5A: pure decision authority, Tasks: round-resume-typescript

### Community 994 - "tasks"
Cohesion: 0.70
Nodes (4): File inventory: openspec/changes/session-store-recovery/tasks.md, Allowed file scope, Tasks, Verification

### Community 995 - "tasks"
Cohesion: 0.70
Nodes (4): File inventory: openspec/changes/workflow-weight-reduction/tasks.md, Allowed file scope, Tasks, Verification

### Community 996 - "foreman-qa-reviewer"
Cohesion: 0.70
Nodes (4): File inventory: plugins/foreman-qa/agents/foreman-qa-reviewer.md, Foreman QA reviewer, Output, Review doctrine

### Community 997 - "docs-check"
Cohesion: 0.90
Nodes (4): File inventory: skills/foreman/scripts/docs-check.sh, forced_missing(), record(), docs-check.sh script

### Community 998 - "lane-review-bundle"
Cohesion: 0.90
Nodes (4): File inventory: skills/foreman/scripts/lane-review-bundle.sh, _is_meta_path(), _paths_to_json(), lane-review-bundle.sh script

### Community 999 - "review-quorum"
Cohesion: 0.80
Nodes (4): File inventory: skills/foreman/scripts/lib/review-quorum.sh, rq_evaluate(), _rq_is_positive_int(), review-quorum.sh script

### Community 1000 - "add-watch"
Cohesion: 0.70
Nodes (4): File inventory: skills/graphify/references/add-watch.md, For /graphify add, For --watch, graphify reference: add a URL and watch a folder

### Community 1001 - "hooks"
Cohesion: 0.70
Nodes (4): File inventory: skills/graphify/references/hooks.md, For git commit hook, For native AGENTS.md integration, graphify reference: commit hook and native AGENTS.md integration

### Community 1002 - "update"
Cohesion: 0.70
Nodes (4): File inventory: skills/graphify/references/update.md, For --cluster-only, For --update (incremental re-extraction), graphify reference: incremental update and cluster-only

### Community 1003 - "testing"
Cohesion: 0.70
Nodes (4): File inventory: skills/superpowers/docs/testing.md, Plugin tests, Skill behavior evals, Testing Superpowers

### Community 1004 - "codex-tools"
Cohesion: 0.70
Nodes (4): File inventory: skills/superpowers/skills/using-superpowers/references/codex-tools.md, Codex App Finishing, Environment Detection, Subagent dispatch requires multi-agent support

### Community 1005 - "pi-tools"
Cohesion: 0.70
Nodes (4): File inventory: skills/superpowers/skills/using-superpowers/references/pi-tools.md, Pi Tool Mapping, Subagents, Task lists

### Community 1006 - "browser-launcher.test"
Cohesion: 0.70
Nodes (4): File inventory: skills/superpowers/tests/brainstorm-server/browser-launcher.test.js, assert, {
  browserLauncherForPlatform
}, test()

### Community 1007 - "test-worktree-path-policy"
Cohesion: 0.90
Nodes (4): File inventory: skills/superpowers/tests/claude-code/test-worktree-path-policy.sh, assert_contains(), assert_not_contains(), test-worktree-path-policy.sh script

### Community 1008 - "positive-control"
Cohesion: 0.70
Nodes (4): File inventory: tests/lib/positive-control.bash, assert_positive_control(), assert_positive_control_token(), positive-control.bash script

### Community 1009 - "release-metrics-harness"
Cohesion: 0.80
Nodes (4): File inventory: tests/release-metrics-harness.sh, expect_case(), FOREMAN_REPO_ROOT, release-metrics-harness.sh script

### Community 1010 - "spec"
Cohesion: 0.40
Nodes (5): Requirement: ingest classifies every node kind and edge relation type against the schema's mapping manifest, Scenario: a mapped node kind writes under its manifest class, Scenario: an unmapped edge relation type fails closed, Scenario: an unmapped node kind is rejected before any write, Scenario: hyperedges are recorded, not silently dropped

### Community 1011 - "spec"
Cohesion: 0.40
Nodes (5): Requirement: Bounded immutable context packs, Scenario: A citation is invalid, Scenario: A context pack is built, Scenario: Dynamic retrieval is requested, Scenario: Implementer and auditor receive evidence

### Community 1012 - "spec"
Cohesion: 0.40
Nodes (5): Requirement: Complete release-scope reconciliation, Scenario: A stale focused ledger is assigned to v0.4, Scenario: An active package is not part of v0.4, Scenario: Coverage is incomplete, Scenario: The Track 1 authorities do not exist yet

### Community 1013 - "RELEASE-NOTES"
Cohesion: 0.40
Nodes (5): Brainstorm Server, Bug Fixes, Codex App Compatibility, Inline Self-Review Replaces Subagent Review Loops, v5.0.6 (2026-03-24)

### Community 1014 - "RELEASE-NOTES"
Cohesion: 0.40
Nodes (5): Breaking Changes, Fixes, Improvements, Tests, v4.2.0 (2026-02-05)

### Community 1015 - "RELEASE-NOTES"
Cohesion: 0.40
Nodes (5): Breaking Changes, Major Changes, New Features, Other Improvements, v4.0.0 (2025-12-17)

### Community 1016 - "SKILL"
Cohesion: 0.40
Nodes (5): Anti-Patterns, ❌ Code in Flowcharts, ❌ Generic Labels, ❌ Multi-Language Dilution, ❌ Narrative Example

### Community 1017 - "SKILL"
Cohesion: 0.40
Nodes (5): Discipline-Enforcing Skills (rules/requirements), Pattern Skills (mental models), Reference Skills (documentation/APIs), Technique Skills (how-to guides), Testing All Skill Types

### Community 1018 - "bugeventlog"
Cohesion: 0.50
Nodes (4): 2026-07-30 · Wave-1 dispatch, Project Feynman, Event 1 — the stall watchdog measured a file that is written only at completion, Event 2 — `repos/` in .gitignore does not match a `repos` symlink, and per-worktree, Event 3 — a watchdog with two blind surfaces killed three live lanes

### Community 1019 - "bugeventlog"
Cohesion: 0.50
Nodes (4): 2026-07-31 — Event 12: the shims were the cause, not the deadlock — measurement 2 was right, the checkpoint's advice was wrong, A measurement can be wrong with no commit touching its scope, `tests/decision-events.bats` is a separate, still-open problem, The checkpoint told readers to trust the wrong number

### Community 1020 - "bugeventlog"
Cohesion: 0.50
Nodes (4): 2026-07-31 — Event 16: a guard fired on its own documentation, A substring is not an invocation, Enhancement, The predicate did not match the claim

### Community 1021 - "codex-app-server"
Cohesion: 0.50
Nodes (3): codex_codex_sdk_md, codex_config_file_config_reference_md, codex_open_source_md

### Community 1022 - "run_contract"
Cohesion: 0.83
Nodes (3): PYTHONPATH, run_contract.sh script, File inventory: docs/evidence/v029/s9-storeport/superseded-shell-round/graph_store_harness/run_contract.sh

### Community 1023 - "claude--docs-claude-com-en-docs-about-claude-models-overview"
Cohesion: 0.83
Nodes (3): source: https://docs.claude.com/en/docs/about-claude/models/overview, status: 200, File inventory: docs/reference/models/raw/claude--docs-claude-com-en-docs-about-claude-models-overview.md

### Community 1024 - "claude--docs-claude-com-en-docs-about-claude-pricing"
Cohesion: 0.83
Nodes (3): source: https://docs.claude.com/en/docs/about-claude/pricing, status: 200, File inventory: docs/reference/models/raw/claude--docs-claude-com-en-docs-about-claude-pricing.md

### Community 1025 - "gemini--ai-google-dev-gemini-api-docs-models"
Cohesion: 0.83
Nodes (3): source: https://ai.google.dev/gemini-api/docs/models, status: 200, File inventory: docs/reference/models/raw/gemini--ai-google-dev-gemini-api-docs-models.md

### Community 1026 - "gemini--ai-google-dev-gemini-api-docs-pricing"
Cohesion: 0.83
Nodes (3): source: https://ai.google.dev/gemini-api/docs/pricing, status: 200, File inventory: docs/reference/models/raw/gemini--ai-google-dev-gemini-api-docs-pricing.md

### Community 1027 - "gpt-5.6--developers-openai-com-api-docs-models-gpt-5-6-luna"
Cohesion: 0.83
Nodes (3): source: https://developers.openai.com/api/docs/models/gpt-5.6-luna, status: 200, File inventory: docs/reference/models/raw/gpt-5.6--developers-openai-com-api-docs-models-gpt-5-6-luna.md

### Community 1028 - "gpt-5.6--developers-openai-com-api-docs-models-gpt-5-6-sol"
Cohesion: 0.83
Nodes (3): source: https://developers.openai.com/api/docs/models/gpt-5.6-sol, status: 200, File inventory: docs/reference/models/raw/gpt-5.6--developers-openai-com-api-docs-models-gpt-5-6-sol.md

### Community 1029 - "gpt-5.6--openai-com-index-gpt-5-6"
Cohesion: 0.83
Nodes (3): source: https://openai.com/index/gpt-5-6/, status: 200, File inventory: docs/reference/models/raw/gpt-5.6--openai-com-index-gpt-5-6.md

### Community 1030 - "grok-4.5--docs-x-ai-docs-models"
Cohesion: 0.83
Nodes (3): source: https://docs.x.ai/docs/models, status: 200, File inventory: docs/reference/models/raw/grok-4.5--docs-x-ai-docs-models.md

### Community 1031 - "grok-4.5--docs-x-ai-docs-overview"
Cohesion: 0.83
Nodes (3): source: https://docs.x.ai/docs/overview, status: 200, File inventory: docs/reference/models/raw/grok-4.5--docs-x-ai-docs-overview.md

### Community 1032 - "openai-sol-card"
Cohesion: 0.50
Nodes (4): 7.3.2 CoT Controllability, Figure 14, Figure 15, Figure 16

### Community 1033 - "openai-sol-card"
Cohesion: 0.50
Nodes (4): 7.4.1 Metagaming in evaluations, Figure 17, Figure 18, Figure 19

### Community 1034 - "REWORK-round4-2026-09-05"
Cohesion: 0.83
Nodes (3): Pre-existing red test, not folded, Rework after GPT-6 Astra audit round 4, File inventory: docs/research/v050/REWORK-round4-2026-09-05.md

### Community 1035 - "install"
Cohesion: 1.00
Nodes (3): Ensure-Junction(), Get-NormalizedPath(), File inventory: install.ps1

### Community 1036 - "install"
Cohesion: 1.00
Nodes (3): link_skill(), install.sh script, File inventory: install.sh

### Community 1037 - "tasks"
Cohesion: 0.83
Nodes (3): File inventory: openspec/changes/resume-supervisor-typescript/tasks.md, R5D: bounded restore and Node supervisor, Tasks: resume-supervisor-typescript

### Community 1038 - "sprints"
Cohesion: 0.83
Nodes (3): File inventory: openspec/changes/v030-release-program/sprints.md, Execution safety prerequisite, Sprint order for Foreman v0.3.0

### Community 1039 - "release-coverage-main / release-coverage-cli"
Cohesion: 0.67
Nodes (3): File inventory: packages/orchestration/src/release-coverage-main.ts, liveReleaseCoverageCliServices, io

### Community 1040 - "launch"
Cohesion: 0.83
Nodes (3): File inventory: skills/foreman/scripts/lib/launch.sh, fl_resolve_launcher(), launch.sh script

### Community 1041 - "worker-cmd"
Cohesion: 0.83
Nodes (3): File inventory: skills/foreman/scripts/lib/worker-cmd.sh, worker-cmd.sh script, wc_build_argv()

### Community 1042 - "github-and-merge"
Cohesion: 0.83
Nodes (3): File inventory: skills/graphify/references/github-and-merge.md, graphify reference: GitHub clone and cross-repo merge, Step 0 - Clone GitHub repo(s) (only if a GitHub URL was given)

### Community 1043 - "transcribe"
Cohesion: 0.83
Nodes (3): File inventory: skills/graphify/references/transcribe.md, graphify reference: transcribe video and audio, Step 2.5 - Transcribe video / audio files (only if video files detected)

### Community 1044 - "parse_only"
Cohesion: 0.83
Nodes (3): File inventory: skills/scrapling/templates/parse_only.py, scrapling_parser, 纯 HTML 解析模板（不需要 fetchers 依赖） 用途: 已有 HTML 内容（来自 WebFetch/文件/API），只需解析提取 替换:…

### Community 1045 - "session-start"
Cohesion: 1.00
Nodes (3): File inventory: skills/superpowers/hooks/session-start, session-start script, escape_for_json()

### Community 1046 - "start-server"
Cohesion: 1.00
Nodes (3): File inventory: skills/superpowers/skills/brainstorming/scripts/start-server.sh, is_windows_like_shell(), start-server.sh script

### Community 1047 - "antigravity-tools"
Cohesion: 0.83
Nodes (3): File inventory: skills/superpowers/skills/using-superpowers/references/antigravity-tools.md, Antigravity CLI (`agy`) Tool Mapping, Task tracking

### Community 1048 - "test-antigravity-tools"
Cohesion: 1.00
Nodes (3): File inventory: skills/superpowers/tests/antigravity/test-antigravity-tools.sh, fail(), test-antigravity-tools.sh script

### Community 1049 - "spec"
Cohesion: 0.50
Nodes (4): Requirement: /api/log is a structurally banned endpoint, Scenario: a direct /api/log call is refused before HTTP, Scenario: non-zero offset paging against the commit log is refused, Scenario: the ban is proven by a negative test, not by absence of code

### Community 1050 - "spec"
Cohesion: 0.50
Nodes (4): Requirement: Author-field encoding for run_id, lane, and attempt, Scenario: Delimiter inside run_id is rejected, Scenario: Non-Foreman author string fails parse, Scenario: Valid identity encodes and parses round-trip

### Community 1051 - "spec"
Cohesion: 0.50
Nodes (4): Requirement: Canary fixtures fail closed when disabled, Scenario: anyURI canary expects UnexpectedEmptyResultError, Scenario: Branch-prefix canary rejects before HTTP, Scenario: Canaries fail closed when machinery is disabled

### Community 1052 - "spec"
Cohesion: 0.50
Nodes (4): Requirement: Closed OpenSpec workflows, Scenario: A bounded change is opened, Scenario: A competing plan appears, Scenario: An architectural change is opened

### Community 1053 - "spec"
Cohesion: 0.50
Nodes (4): Requirement: Dependency-bound release tranches, Scenario: A dependency is incomplete, Scenario: A focused package already exists, Scenario: Independent foundation tracks are ready

### Community 1054 - "spec"
Cohesion: 0.50
Nodes (4): Requirement: Graphify qualification before adoption, Scenario: Graphify passes qualification, Scenario: Graphify regresses, Scenario: The health gate is discriminating

### Community 1055 - "spec"
Cohesion: 0.50
Nodes (4): Requirement: Stable project registry, Scenario: A project path is unavailable, Scenario: A repository has linked worktrees, Scenario: A repository is not registered

### Community 1056 - "RELEASE-NOTES"
Cohesion: 0.50
Nodes (4): Brainstorm Server Reliability, Subagent Context Isolation, v5.0.2 (2026-03-11), Zero-Dependency Brainstorm Server

### Community 1057 - "RELEASE-NOTES"
Cohesion: 0.50
Nodes (4): Breaking Changes, Improvements, New Features, v5.0.0 (2026-03-09)

### Community 1058 - "RELEASE-NOTES"
Cohesion: 0.50
Nodes (4): Breaking Changes, Improvements, New Features, v3.2.0 (2025-10-18)

### Community 1059 - "RELEASE-NOTES"
Cohesion: 0.50
Nodes (4): Bug Fixes, OpenCode, Review Loop Refinements, v5.0.4 (2026-03-16)

### Community 1060 - "SKILL"
Cohesion: 0.50
Nodes (4): File Organization, Self-Contained Skill, Skill with Heavy Reference, Skill with Reusable Tool

### Community 1063 - "bugeventlog"
Cohesion: 0.67
Nodes (3): 2026-07-30 — Event 11: three-lens adversarial review corrected the architect on both open blockers, Correction 1 — the flake was real, but the architect's evidence was not, Correction 2 — the tov lane's soundness evidence was void

### Community 1079 - "gemini-pricing"
Cohesion: 0.67
Nodes (3): Batch, Gemini 2.5 Flash Preview TTS, Standard

### Community 1080 - "gemini-pricing"
Cohesion: 0.67
Nodes (3): Batch, Gemini 2.5 Pro Preview TTS, Standard

### Community 1081 - "gemini-pricing"
Cohesion: 0.67
Nodes (3): Batch, Gemini Embedding 2, Standard

### Community 1082 - "gemini-pricing"
Cohesion: 0.67
Nodes (3): Batch, Gemini 3.1 Flash Image (Nano Banana 2) 🍌, Standard

### Community 1083 - "gemini-pricing"
Cohesion: 0.67
Nodes (3): Batch, Gemini 3.1 Flash Lite Image (Nano Banana 2 Lite) 🍌, Standard

### Community 1084 - "gemini-pricing"
Cohesion: 0.67
Nodes (3): Batch, Gemini 3.1 Flash TTS Preview, Standard

### Community 1085 - "openai-sol-card"
Cohesion: 0.67
Nodes (3): 3.1.2 Forecasting Disallowed Content Changes with Deployment Simulation, Figure 1, Figure 2

### Community 1086 - "openai-sol-card"
Cohesion: 0.67
Nodes (3): 4.2 Prompt injection, Table, Table 5

### Community 1087 - "openai-sol-card"
Cohesion: 0.67
Nodes (3): 7.1 Forecasting Misaligned Behavior with Deployment Simulation of ChatGPT traffic, Figure 5, Figure 6

### Community 1088 - "openai-sol-card"
Cohesion: 0.67
Nodes (3): 9.1.1.4 TroubleshootingBench, Figure 28, Figure 29

### Community 1089 - "openai-sol-card"
Cohesion: 0.67
Nodes (3): 9.1.2.1.1 Capture the Flag (CTF) Challenges, Figure 30, Figure 31

### Community 1090 - "openai-sol-card"
Cohesion: 0.67
Nodes (3): 9.1.3.1 Internal Research Debugging Evaluation, Figure 37, Figure 38

### Community 1091 - "openai-sol-card"
Cohesion: 0.67
Nodes (3): 9.1.3.2 KernelGen 1P, Figure 39, Figure 40

### Community 1158 - "spec"
Cohesion: 0.67
Nodes (3): Requirement: Adapter targets the HTTP API directly, Scenario: Official client dependency is forbidden, Scenario: Raw HTTP client is used for a document write

### Community 1159 - "spec"
Cohesion: 0.67
Nodes (3): Requirement: Batched document writes at size 500, Scenario: Default ingest uses PUT upsert, Scenario: Ingest of 1200 nodes uses three commits

### Community 1160 - "spec"
Cohesion: 0.67
Nodes (3): Requirement: Connection and Basic authentication, Scenario: Database create uses verified endpoint shape, Scenario: Missing admin password fails closed

### Community 1161 - "spec"
Cohesion: 0.67
Nodes (3): Requirement: Distinct is structurally mandatory around Path queries, Scenario: No public raw Path builder without Distinct, Scenario: Path query is issued only with Distinct

### Community 1162 - "spec"
Cohesion: 0.67
Nodes (3): Requirement: Drop-and-rebuild scoped to graph.json-derived facts, Scenario: Event-log-derived facts are preserved, Scenario: Rebuild re-ingests graph.json facts

### Community 1163 - "spec"
Cohesion: 0.67
Nodes (3): Requirement: Fan-in appends of distinct documents require no CAS, Scenario: Concurrent distinct writers are not forced into CAS, Scenario: Distinct-document write without CAS is permitted

### Community 1164 - "spec"
Cohesion: 0.67
Nodes (3): Requirement: Ingest idempotency via content-hash batch skip, Scenario: Changed node invalidates hash skip for that batch, Scenario: Second identical ingest skips writes

### Community 1165 - "spec"
Cohesion: 0.67
Nodes (3): Requirement: Ingest reads graph.json only and refuses export files, Scenario: cypher.txt is refused by name, Scenario: graph.json ingest is accepted

### Community 1166 - "spec"
Cohesion: 0.67
Nodes (3): Requirement: Producing graphify version is stamped from caller, Scenario: Caller stamp is applied, Scenario: Missing graphify_version fails closed

### Community 1167 - "spec"
Cohesion: 0.67
Nodes (3): Requirement: Reification classifier closed outcome set, Scenario: Each property maps to exactly one class, Scenario: Unknown property fails closed

### Community 1168 - "spec"
Cohesion: 0.67
Nodes (3): Requirement: Rename-with-lineage detection via git correlation, Scenario: Correlation failure fails closed by default, Scenario: File rename produces lineage linkage

### Community 1169 - "spec"
Cohesion: 0.67
Nodes (3): Requirement: Two-pass ingest ordering documents before links, Scenario: Hyperedges are part of document pass when present, Scenario: Nodes commit before edges

### Community 1170 - "spec"
Cohesion: 0.67
Nodes (3): Requirement: Hermetic local embeddings, Scenario: The appliance runs offline, Scenario: The embedding identity changes

### Community 1171 - "spec"
Cohesion: 0.67
Nodes (3): Requirement: One active change authority, Scenario: A new tranche starts, Scenario: Human implementation-base approval

### Community 1172 - "spec"
Cohesion: 0.67
Nodes (3): Requirement: Promotion thresholds, Scenario: Any threshold fails or is inconclusive or uncomputable, Scenario: Every threshold passes

### Community 1173 - "RELEASE-NOTES"
Cohesion: 0.67
Nodes (3): Added, Fixed, v4.3.1 (2026-02-21)

### Community 1174 - "RELEASE-NOTES"
Cohesion: 0.67
Nodes (3): Added, Changed, v3.5.0 (2025-11-23)

### Community 1175 - "RELEASE-NOTES"
Cohesion: 0.67
Nodes (3): Bug Fixes, Changed, v5.0.5 (2026-03-17)

### Community 1176 - "RELEASE-NOTES"
Cohesion: 0.67
Nodes (3): Bug Fixes, Cursor Support, v5.0.3 (2026-03-15)

### Community 1177 - "RELEASE-NOTES"
Cohesion: 0.67
Nodes (3): Changed, Fixed, v4.3.0 (2026-02-12)

### Community 1178 - "RELEASE-NOTES"
Cohesion: 0.67
Nodes (3): GitHub Copilot CLI Support, OpenCode Fixes, v5.0.7 (2026-03-31)

## Knowledge Gaps
- **1016 isolated node(s):** `./local.js`, `File inventory: components/council/packages/adapter-claude/src/index.ts`, `File inventory: components/council/packages/adapter-codex/src/index.ts`, `File inventory: components/council/packages/adapter-grok/src/index.ts`, `File inventory: components/council/packages/application/src/index.ts` (+1011 more)
  These have ≤1 connection - possible missing edges or undocumented components. (Counts symbols only; 1055 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)
- **723 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `Text generation` connect `gemini-text` to `gemini-interactions`, `gemini-structured`, `gemini-thinking`?**
  _High betweenness centrality (0.000) - this node is a cross-community bridge._
- **Why does `Context caching` connect `gemini-cache / gemini-model` to `gemini-text`?**
  _High betweenness centrality (0.000) - this node is a cross-community bridge._
- **Why does `Function calling with the Gemini API` connect `gemini-tools` to `gemini-model / gemini-interactions`, `gemini-structured`, `gemini-thinking`?**
  _High betweenness centrality (0.000) - this node is a cross-community bridge._
- **What connects `./local.js`, `File inventory: components/council/packages/adapter-claude/src/index.ts`, `File inventory: components/council/packages/adapter-codex/src/index.ts` to the rest of the system?**
  _1016 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `identifiers / quorum.test` be split into smaller, more focused modules?**
  _Cohesion score 0.02826313957535677 - nodes in this community are weakly interconnected._
- **Should `backend-boundary.test / fm-session-golden.test` be split into smaller, more focused modules?**
  _Cohesion score 0.02934220251293422 - nodes in this community are weakly interconnected._
- **Should `execution-terminal-policy / execution-ledger` be split into smaller, more focused modules?**
  _Cohesion score 0.04044665012406948 - nodes in this community are weakly interconnected._