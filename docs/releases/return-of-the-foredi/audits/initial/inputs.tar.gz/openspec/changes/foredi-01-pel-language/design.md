# Pel language design

## Decision and source

Implement the published Pel language in strict TypeScript for Node.js 24.
Use `packages/pel/`, as selected by the release design and plan.
This overrides the research review's earlier suggestion to nest the language in orchestration.

The source is [Pel v2](https://arxiv.org/abs/2505.13453v2), sections 4 through 6.
The captured text is `docs/research/pel-release/sources/pel/arxiv-2505.13453v2.txt`.
Use the PDF digest in the adjacent `manifest.json` for fixture attribution.
No verified upstream implementation exists in the reviewed evidence.
Describe compatibility as conformance to this paper profile.

Requirements use [EARS](https://alistairmavin.com/ears/).
The catalog stores each requirement body without alteration.

## Files and boundaries

| Target | Responsibility |
| --- | --- |
| `packages/pel/package.json`, `tsconfig.json`, `tsconfig.test.json` | Strict NodeNext package and compiled test build |
| `packages/pel/src/tokenizer.ts`, `parser.ts`, `ast.ts` | UTF-8 input, tokens, AST, stable locations |
| `packages/pel/src/values.ts`, `arguments.ts`, `builtins.ts` | Values, argument binding, builtin descriptors |
| `packages/pel/src/evaluator.ts`, `continuation.ts` | Pure evaluation machine and serializable frames |
| `packages/pel/src/diagnostics.ts`, `profile.ts` | Typed diagnostics and frozen profile |
| `packages/pel/src/host-contract.ts`, `dependencies.ts` | Host suspension and dependency descriptions |
| `packages/pel/src/index.ts` | Public exports |
| `packages/pel/test/fixtures/paper-v2.json` | Paper, errata, and extension cases |
| `docs/reference/pel/compatibility.md`, `extensions.md` | Semantics, attribution, capability boundary |
| Root `tsconfig.json`, `tsconfig.all.json`, `package.json` | Workspace references and test discovery |

Keep deterministic transforms as ordinary TypeScript functions.
The language machine owns no timers, subprocesses, filesystem handles, or provider requests.
The orchestration Effect scope owns these resources.

## Public interfaces

Export `SourceSpan` with zero-based UTF-8 byte offsets and one-based line and Unicode-scalar columns.
Spans are half-open. CRLF counts as one newline.
AST nodes carry `nodeId`, `kind`, and `span`.
A node ID combines the source SHA-256 digest and child-index path.
The source digest includes the exact bytes, including comments and whitespace.

Export `parsePel(source: Uint8Array, profile: PelProfileV1): Result<PelProgram, readonly PelDiagnostic[]>`.
Export `startPel(program, environment, limits): PelStep`.
Export `resumePel(continuation, receipts): PelStep`.
Export `analyzeDependencies(program): DependencySummary`.
Export `formatPel(value): string` and `renderPelDiagnostic(source, diagnostic): string`.

`PelStep` is a discriminated union:
- `done`: final `PelValue` and consumed counters.
- `suspend`: nonempty ready `HostRequestV1[]`, `PelContinuationV1`, and consumed counters.
- `failed`: `PelDiagnostic`, preserved continuation, and consumed counters.

`PelValue` is a tagged union of finite number, string, Boolean, nil, key, pair, list, symbol, syntax, and closure.
Symbol and syntax values arise through quoting.
A closure contains AST identity, captured environment IDs, remaining ArgSpec, supplied arguments, and strictness.
Builtin closures contain registry IDs, never JavaScript code.
Callable lists keep the list tag and use the closure argument-binding protocol.

`HostFunctionDescriptorV1` contains a registry ID, name, ArgSpec, result schema ID, failure schema ID, effect kind, capability names, and resource declarations.
Resource declarations contain `reads`, `writes`, and `unknown`.
Only the host registry can create descriptors.
A Pel pair that resembles a descriptor remains data.

`HostRequestV1` contains request ID, source digest, node ID, invocation ordinal, registry ID, bound arguments, and expected result schema ID.
Request IDs hash the source digest, registry digest, node ID, and complete logical invocation path.
Loop iteration and nested call positions form the invocation path.
Each fully applied call produces one request.

`HostReceiptV1` has the exact shape `{requestId: string, outcome: {tag: "success", value: PelDataValue} | {tag: "failure", failure: HostEffectFailure}}`.
`PelDataValue` is the host-safe subset of `PelValue` listed below.
`HostEffectFailure` contains `code: string`, `message: string`, and optional structured `cause`.
The decoder accepts only failure codes declared by the immutable host registry's failure schema.
Base codes are `capability-denied`, `resource-denied`, `timeout`, `provider-failure`, `unknown-external-outcome`, and `reconciliation-required`.
M5 registers operation-specific failure codes through that schema without making the language import orchestration.
The structured cause can carry a boundary-specific code and safe detail.
The execution owner validates receipts and records effects.
The evaluator also checks request identity and the declared value schema.
Host values can be numbers, strings, booleans, nil, keys, pairs, or nested lists.
Host results cannot inject syntax, closures, symbols, registry descriptors, or executable source.
Native list lookup, `if`, `case`, `for`, and pipes consume returned values directly.

## Compatibility profile pel-paper-v2-foreman-1

Create a versioned fixture record with `id`, `class`, `paperSection`, `paperPage`, `sourceDigest`, `input`, `ast`, `resultOrError`, and `effects`.
Classes are `paper`, `erratum`, and `extension`.
Each correction below gets positive and negative fixtures.

| Subject | Deterministic behavior |
| --- | --- |
| Programs, §4.1 | Zero or more expressions. Empty program returns nil. Calls use parentheses. Bracket elements evaluate left to right. |
| Lexing, §4.1 | Unicode scalar symbols. Preserve spelling without normalization. Whitespace separates tokens. A semicolon starts a comment through newline. |
| Token boundaries | Delimiters are whitespace, parentheses, brackets, quote, double quote, semicolon, caret, and vertical bar. A bare vertical bar fails. |
| Constants | Recognize complete tokens `#t`, `#f`, and `#nil`. Reject other hash-prefixed tokens. |
| Numbers | Accept `-?digits(.digits)?`. Reject exponent notation and nonfinite values. Reject integer literals outside ±9007199254740991. Normalize negative zero. |
| Strings | Permit raw newlines. Decode \\n, \\r, \\t, \\b, \\f, \\v, \\0, \\\\, \\", \\xHH, \\uHHHH, and \\UHHHHHHHH. Reject malformed escapes and invalid scalar values. |
| Keywords | A colon requires one or more paper KEY characters: ASCII letters, digits, underscore, minus, plus, caret, slash, backslash, question mark, exclamation mark, greater-than, equals, period. |
| Pair formation | In unquoted list, argument, and top-level sequences, a key consumes the next non-key expression. Otherwise it pairs with nil. |
| Quotes | Quote consumes one full expression, including its pipe chain. Disable pair formation throughout quoted syntax. Return literal key, symbol, or syntax without evaluation. |
| Quoted data | Formatting preserves quoted structure. There is no implicit eval builtin. Quoted `':a` is a key value, not a named argument. |
| Nil, §4.2 | `()` equals `#nil`. Nil is not Boolean and cannot be a condition. `[]` remains an empty callable list. |
| Lists, §4.5 | Use one-based indices and inclusive slices. Reject index zero, negative indices, fractional indices, and indices beyond list length. |
| List calls | Signature is `:at #nil :from #nil :to #nil`. All nil returns the original list. At and non-nil slice bounds together fail. |
| Slices | Missing bounds mean first and last. Valid reversed bounds return an empty list. Empty-list default slicing returns an empty list. Explicit bounds on empty lists fail. |
| Selection | At accepts integer, quoted key, or a list of these. Multi-selection preserves request order and duplicates. Indexing a pair returns the pair. |
| Keys | Lookup returns the first matching pair value. A missing key returns nil. Duplicate keys remain ordered list entries. |
| Index errata | `([5 6 7 8] 1)` returns 5. `([5 6 7 8] () 1 3)` returns `[5 6 7]`. Replace the paper's loop indices `[0 2 4]` with `[1 3 5]`. |
| Definitions, §4.3 | `def` binds its symbol after value evaluation and returns that value. Bindings are immutable within a scope. Duplicate definitions fail. |
| Lexical capture | Lambdas capture their definition environment. Each invocation adds a child scope. A later definition cannot repair an earlier unbound capture. |
| Arguments | Lambdas have fixed ArgSpec. A bare key is required. A key followed by a value supplies a default. Explicit nil is a default, not an absent default. |
| Defaults | Evaluate default expressions once when the lambda forms, left to right, in its defining environment. Required parameters may follow defaults. |
| Binding | Positional arguments bind remaining parameters in declaration order. Named arguments bind by name. Missing required parameters return a partial closure. |
| Errors | Reject mixed modes, unknown names, duplicate names, and excess arguments. Reject rebinding a parameter already supplied to a partial closure. |
| Strictness | User lambdas are strict. Builtins can be non-strict. Partial non-strict closures capture syntax with the caller environment without evaluating it. |
| Pipes, §4.4 | Pipes associate left to right. Evaluate the left expression once. Without an unquoted caret, the right side must be a call and receives the value first. |
| Caret correction | Tokenize `^>` before standalone `^`. Replace every free caret in the right expression recursively with the same evaluated value. |
| Caret scope | Stop substitution at quotes. A nested pipe owns carets in its right operand. Carets in its left operand remain in the enclosing pipe's scope. |
| Lambda pipe scope | Free carets inside a lambda on the right receive the current value. The resulting lambda captures that value. Bare caret outside a pipe fails. |
| `if`, §4.6.1 | Signature `:cond :then :else #nil`. Evaluate one Boolean condition and only its selected branch. |
| `case`, §4.6.2 | Signature `:scrut :body`. Body is an unevaluated bracket sequence of condition and consequence expressions. Reject odd length. |
| Case conditions | A Boolean literal stands alone. Pipe the scrutinee into other condition expressions. Evaluate in order. Return first selected consequence or nil. |
| Natural-language case, §4.7 | A string condition suspends with `pel/nl-condition`, scrutinee, and condition text. Require a Boolean receipt. |
| `for`, §4.6.3 | Signature `:coll :iterator :body`. Require a list and binder symbol. Evaluate one body per element in source order. Return the ordered result list. |
| `do`, §4.6.4 | Accept expression arguments or one bracket sequence as unevaluated expressions. Evaluate in one child scope, sequentially. Return last value or nil. |
| `do/async`, §4.6.5 | Same sequence forms. Evaluate dependency-ready children. Wait for all results. Return the last source expression's value, not last completion. |
| Sequence arity correction | Only do and do/async use sequence ArgSpec. Zero expressions return nil. User lambdas and other builtins remain fixed-arity. |
| Dependencies, §5.2 | Top-level execution defaults to source order. Optional automatic mode releases acyclic dependency-ready expressions for host conflict checking. |
| Binding dependencies | In an asynchronous block, references to definitions in that block wait for those definitions. Cycles fail with PEL_DEPENDENCY_CYCLE. |
| Restart, §5.1 | Failures preserve frame/environment data. Restart choices are abort, replace-expression, replace-suffix, replace-program, and helper-repair. |

Recursive self-reference is supported through a reserved immutable environment cell during `def` evaluation.
The cell becomes available only after its closure value is complete.
Non-closure self-reference fails with `PEL_UNINITIALIZED_BINDING`.
Mutual forward references require asynchronous dependency analysis and cyclic definitions still fail.
There is no assignment, dynamic module loading, arbitrary JavaScript, or shell evaluator.

The paper uses arithmetic and utility names without complete signatures.
Freeze this small pure library: binary `+`, `-`, `*`, `/`, `pow`, `gt`, `lt`, `eq`, and `concat`.
Also provide unary `sqrt`, `len`, and `not`.
`+` additionally accepts one numeric list for the paper's vector pipe example.
This is a fixed overload, not general variadic support.
Numeric operations reject nonfinite results and unsafe integer results.
Division by zero returns `PEL_NUMERIC_DOMAIN`.
Equality is structural for data values, compares syntax structurally, and rejects closures with `PEL_TYPE`.
`len` accepts a list or string and counts Unicode scalar values for strings.
`concat` accepts two strings.
`print` is a host descriptor with `:vals :sep "" :nl #f` and returns its input after host output.
Its defaults follow the paper's prose at page 21.
The conflicting signature display becomes an erratum.
`summarize`, `meeting`, and hierarchical agent names are host registry examples, not grammar constructs.

## Bounds and failures

Defaults are 1 MiB source, 100000 tokens, 50000 AST nodes, and 256 syntax nesting levels.
Evaluation defaults are 100000 reductions, 10000 aggregate loop iterations, 256 call frames, and 16 MiB encoded values.
A host can lower bounds. Admission can supply larger finite bounds explicitly.
Every reduction consumes fuel before executing that reduction.
Each iteration consumes one aggregate iteration allowance before its body.
Repeated resume never resets counters.
Value encoding checks the total reachable data size with cycle-safe environment references.
Limit failure occurs before the over-limit expression can emit a host request.

Diagnostics contain code, severity, span, related spans, message, expected forms, and optional signature/help.
Stable codes include `PEL_LEX`, `PEL_PARSE`, `PEL_UNBOUND_SYMBOL`, `PEL_UNINITIALIZED_BINDING`, `PEL_DUPLICATE_BINDING`, `PEL_TYPE`, `PEL_ARGUMENT_MODE`, `PEL_ARGUMENT_NAME`, `PEL_ARITY`, `PEL_INDEX`, `PEL_NUMERIC_DOMAIN`, `PEL_CARET_SCOPE`, `PEL_DEPENDENCY_CYCLE`, `PEL_LIMIT`, `PEL_HOST_RESULT`, and `PEL_CONTINUATION_MISMATCH`.
An invalid parse returns no executable program.
A diagnostic never contains credentials, unrelated source files, or an invented successful result.

## Suspension and restart ownership

A fully applied registered host function suspends.
A partial host closure does not dispatch or reserve resources.
Multiple ready requests can appear for asynchronous children.
The host decides admissibility and concurrency using capability and read/write declarations.
An unknown resource set requires conservative serialization.
The host returns receipts by request ID in any completion order.
The evaluator rejects duplicate receipts and receipts for unknown requests.

Export `evaluateClosure(closure: PelClosureValue, args: readonly PelValue[], context: ClosureEvaluationContextV1): PelStep`.
The context fixes source/profile/registry digests, parent request ID, child invocation ID, lexical environment table, and allocated finite remaining limits.
Export `mergeClosureResult(parent: PelContinuationV1, invocationId: string, receipt: HostReceiptV1, consumed: PelCounters): PelStep`.
This function validates child identity, adds child counters, checks aggregate limits, and resumes the parent.
M4 debits child reductions and iterations against the shared run envelope before granting another allocation.
Concurrent children cannot each receive the whole unused budget.
Trusted host-library arguments can contain internal closure values for retry and race.
Provider return values cannot contain closures.

`PelContinuationV1` stores version, source/profile/registry digests, AST locations, frames, environment graph, pending requests, completed values, and counters.
Encode closures as code references plus lexical data, never native closures.
Round-trip encoding preserves pending identities and counters.
Reject a continuation under different source, profile, or registry digests.
Expression replacement creates a new revision through the execution owner.
Completed effects retain their old identities and receipts.
M1 does not repeat remote work, reset budgets, or choose a recovery authority.

`pel/nl-condition` uses the same host interface as every other model call.
Only its typed Boolean result enters Pel flow.
Authorization and host verification do not accept this predicate as evidence.

The paper's REPeL history, highlighting, completion, and interactive terminal interface are tooling.
M2 supplies source diagnostics and helper repair.
Durable restart and expression replacement belong to the execution milestone.
The profile records this allocation without claiming those runtime tools already exist.

## Planned validation

Create `tsconfig.test.json` with `rootDir: "."`, `outDir: "dist-test"`, and NodeNext compilation for source and tests.
Run `npm run typecheck`.
Add `packages/pel/test/**/*.test.ts` to the root `npm test` command's explicit test globs.
Run `npx tsc -p packages/pel/tsconfig.test.json`.
Run `node --test packages/pel/dist-test/test/*.test.js` on Node.js 24.
The catalog names exact planned test files and observable results.
No test implementation or language runtime is part of this drafting change.
