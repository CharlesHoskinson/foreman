# M5 implementation tasks

Status: planned. No implementation checkbox or runtime test is complete.
Use strict TypeScript on Node.js 24. Execute host functions inside the M4 Effect scope.

## 1. F-M5-01: Implement bounded candidate work

- [ ] 1.1 Add `pel-host-contract.ts` candidate, artifact, receipt, and argument decoders.
- [ ] 1.2 Add `pel-host-library.ts` registrations using M1 arguments and M2 effect descriptors.
- [ ] 1.3 Implement `pel-host-task.ts` using exact M3 profiles and admitted workspace resources.
- [ ] 1.4 Capture immutable candidate manifests from observed files with existing canonical hash functions.
- [ ] 1.5 Return ordinary Pel association-list values with immutable artifact references.
- [ ] 1.6 Implement T-M5-001 and T-M5-002 in `pel-host-task.test.ts`.
- [ ] 1.7 Run `npx tsx scripts/run-tests.ts "packages/orchestration/src/pel-host-task.test.ts"`.

Assert real candidate output, exact observed hashes, schema rejection, missing artifacts, and allowed-path enforcement.

## 2. F-M5-02: Verify an exact candidate

- [ ] 2.1 Implement `pel-host-verify.ts` against registered host argv gates and scoped environment bindings.
- [ ] 2.2 Capture pre-check and post-check candidate identities and reject mutation.
- [ ] 2.3 Reuse report freshness checks and register existing checks evidence through the execution ledger.
- [ ] 2.4 Reuse verification only for identical candidate, gate, environment, policy, and freshness bindings.
- [ ] 2.5 Implement T-M5-003 through T-M5-005 in `pel-host-verify.test.ts`.
- [ ] 2.6 Run `npx tsx scripts/run-tests.ts "packages/orchestration/src/pel-host-verify.test.ts" "packages/orchestration/src/report-freshness.test.ts"`.

Assert host-controlled pass and fail, one unchanged verification, changed-binding reruns, candidate mutation rejection, and honest crash recovery.

## 3. F-M5-03: Obtain independent vendor review

- [ ] 3.1 Implement `pel-host-review.ts` using immutable artifacts and observed M3 identity.
- [ ] 3.2 Port current-attempt audit invalidation from `audit-run.sh` into the typed host operation.
- [ ] 3.3 Reuse review trust separation and existing release evidence validation.
- [ ] 3.4 Reject same-vendor review and noncurrent candidate or verification bindings.
- [ ] 3.5 Implement T-M5-006 and T-M5-007 in `pel-host-review.test.ts`.
- [ ] 3.6 Run `npx tsx scripts/run-tests.ts "packages/orchestration/src/pel-host-review.test.ts" "packages/policy/src/release-authority.test.ts"`.

Assert independent observed identity, current-attempt evidence, stale approval invalidation, and unverified interruption or malformed results.

## 4. F-M5-04: Deliver and repair a native Pel workflow

- [ ] 4.1 Add `examples/pel/implement-verify-review.pel` using Grok, host verification, and Sol.
- [ ] 4.2 Add `examples/pel/repair-and-publish.pel` with native conditionals and bounded correction iteration.
- [ ] 4.3 Bind correction actions to existing implementation, correction, progress, and verification limits.
- [ ] 4.4 Add recorded provider and gate fixtures with one corrected candidate and one no-op repair.
- [ ] 4.5 Implement T-M5-008 through T-M5-010 in `pel-delivery.test.ts`.
- [ ] 4.6 Run `npm run build` and execute both examples through the compiled CLI fixture harness.
- [ ] 4.7 Run `npx tsx scripts/run-tests.ts "packages/orchestration/src/pel-delivery.test.ts"`.

Assert one authored Pel workflow, two provider assignments, complete evidence chains, bounded correction, and no repeated completed implementation after restart.

## 5. F-M5-05: Publish with existing explicit authority

- [ ] 5.1 Implement `pel-publication-service.ts` prepare, commit, and observe operations for an admitted Git ref destination.
- [ ] 5.2 Reuse existing release authority decoders, receipt binding, and execution action reservation.
- [ ] 5.3 Port required candidate, merge-base, and target conflict checks from current merge scripts into typed service functions.
- [ ] 5.4 Keep local integration and external publication as separate authorized operations and receipts.
- [ ] 5.5 Implement `pel-host-publish.ts` with needs-action output for absent explicit authority.
- [ ] 5.6 Revalidate candidate and destination under the resource lock immediately before publication.
- [ ] 5.7 Reconcile lost acknowledgements through exact destination observations without automatic republishing.
- [ ] 5.8 Implement T-M5-011 through T-M5-013 using temporary local repositories and a bare remote.
- [ ] 5.9 Run `npx tsx scripts/run-tests.ts "packages/orchestration/src/pel-host-publish.test.ts" "packages/orchestration/src/release-authority-cli.test.ts" "packages/policy/src/release-authority.test.ts"`.

Assert denied publication makes no mutation, authorized publication changes only the admitted ref, stale evidence fails, and lost acknowledgement stays truthful.
These tests use fixture authority only. They do not authorize publication to a real repository or release destination.

## 6. F-M5-06: Return actionable delivery results

- [ ] 6.1 Add `pel-delivery-result.ts` journal projection and text rendering for artifacts, checks, findings, and next action.
- [ ] 6.2 Extend M4 result rendering while retaining its lifecycle exit codes and unknown outcome fields.
- [ ] 6.3 Implement T-M5-014 and T-M5-015 in `pel-delivery-result.test.ts` and `pel-delivery.test.ts`.
- [ ] 6.4 Run `npx tsx scripts/run-tests.ts "packages/orchestration/src/pel-delivery-result.test.ts" "packages/orchestration/src/pel-delivery.test.ts"`.
- [ ] 6.5 Run `npm run typecheck`, `npm run build`, and compiled Node.js 24 CLI acceptance fixtures.
- [ ] 6.6 Run `npm run verify` with existing authority, ledger, freshness, and terminal policy tests.

Assert artifact references resolve, views agree, unavailable profiles do not fall back, and pending required milestones cannot produce success.
Record actual verification evidence during implementation. M6 owns legacy caller migration and deletion after these replacement fixtures pass.
