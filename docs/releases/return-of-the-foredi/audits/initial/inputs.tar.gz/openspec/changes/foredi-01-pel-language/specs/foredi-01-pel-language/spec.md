# Return of the ForeDi: Pel language

The normative profile and interfaces are in [design.md](../../design.md).
Tests are planned implementation contracts.

## ADDED Requirements

### Requirement: R-M1-001 Published syntax

When Pel source is parsed, the Foreman Pel parser SHALL produce the profile-defined AST with exact source spans.

#### Scenario: T-M1-001 Published syntax

- WHEN Calls (+ 1 2), evaluated lists [1 (+ 2 3)], () and #nil, :flag pairs, ':a, semicolon comments, escaped strings, and empty source.
- AND parsePel each fixture with pel-paper-v2-foreman-1.
- THEN Calls and lists have distinct AST tags, nil forms match, quote disables pairs, spans match byte offsets, and empty source evaluates to nil.

### Requirement: R-M1-002 Invalid syntax

If source violates the lexical or grammar profile, then the Foreman Pel parser SHALL return source-located diagnostics without an executable program.

#### Scenario: T-M1-002 Invalid syntax

- WHEN Inputs (+ 1, [1), a bare caret, malformed string escapes, #true, invalid UTF-8, and nonfinite numeric text.
- AND parsePel each invalid fixture.
- THEN PEL_PARSE, PEL_LEX, or PEL_CARET_SCOPE identifies the first invalid source range and no PelProgram is returned.

### Requirement: R-M1-003 Values and pairs

When Pel values are evaluated or formatted, the Foreman Pel evaluator SHALL preserve their profile-defined types and ordered pair structure.

#### Scenario: T-M1-003 Values and pairs

- WHEN [1 "two" #t #nil :a 1 :flag], quoted symbols and expressions, duplicate keys, Unicode strings, and numeric boundary fixtures.
- AND startPel each fixture and formatPel its result.
- THEN Types remain distinct, :flag pairs with nil, duplicate keys remain ordered, safe integers retain value, and invalid arithmetic returns PEL_NUMERIC_DOMAIN.

### Requirement: R-M1-004 Callable list semantics

When a list is called, the Foreman Pel evaluator SHALL apply one-based indexing, inclusive slicing, and ordered key selection.

#### Scenario: T-M1-004 Callable list semantics

- WHEN ([5 6 7 8] 1), ([5 6 7 8] () 1 3), ([:a 1 :b 2] :at [':b ':a]), missing keys, zero/fractional/out-of-range indices.
- AND startPel the callable-list fixture matrix.
- THEN Results are 5, [5 6 7], [2 1], and nil respectively. Invalid indices return PEL_INDEX. Mixed at and slice selectors return PEL_ARGUMENT_MODE.

### Requirement: R-M1-005 Lexical closures and defaults

When a lambda is created or invoked, the Foreman Pel evaluator SHALL preserve lexical capture and profile-defined default evaluation.

#### Scenario: T-M1-005 Lexical closures and defaults

- WHEN (def x 2) (def f (lambda [:y 3] (+ x y))) (f), shadowed child scopes, recursive factorial, and explicit nil defaults.
- AND startPel closure fixtures.
- THEN The default call returns 5. Child scope shadowing does not change captured x. Factorial 5 returns 120. Defaults evaluate once at lambda creation.

### Requirement: R-M1-006 Partial and named application

When a closure receives arguments, the Foreman Pel evaluator SHALL bind named or positional arguments under its fixed argument specification.

#### Scenario: T-M1-006 Partial and named application

- WHEN (def add (lambda [:x :y] (+ x y))) (def add5 (add 5)) (add5 10), named defaults, partial if, mixed modes, duplicate names, excess arguments.
- AND startPel argument fixtures with a host-call spy.
- THEN Partial addition returns 15. Partial non-strict if preserves unevaluated branches. Invalid modes, names, and counts return PEL_ARGUMENT_MODE, PEL_ARGUMENT_NAME, and PEL_ARITY.

### Requirement: R-M1-007 Pipe insertion

When a pipe is evaluated, the Foreman Pel evaluator SHALL insert its once-evaluated input at profile-defined caret positions.

#### Scenario: T-M1-007 Pipe insertion

- WHEN (test/once) ^> (+ ^ ^), [1 2 3 4] ^> (len) ^> (+ 5), nested pipe and quoted caret fixtures.
- AND startPel and resumePel once with test/once returning 5.
- THEN The first expression emits one host request and returns 10. The length pipe returns 9. Nested scopes bind correctly and quoted carets remain syntax.

### Requirement: R-M1-008 Selective conditionals and loops

When native conditional or loop functions are evaluated, the Foreman Pel evaluator SHALL select only required expressions and preserve result order.

#### Scenario: T-M1-008 Selective conditionals and loops

- WHEN (if #f (test/denied) 7), (case 3 [(gt 2) "yes" #t (test/denied)]), (for [1 2 3] i (* i 2)), nil conditions, odd case body.
- AND startPel each native-control fixture.
- THEN Results are 7, "yes", and [2 4 6]. No denied request appears. Nil conditions return PEL_TYPE and odd case bodies return PEL_ARITY.

### Requirement: R-M1-009 Sequence and dependency order

When do or do/async evaluates a sequence, the Foreman Pel evaluator SHALL return the last source expression after required dependencies complete.

#### Scenario: T-M1-009 Sequence and dependency order

- WHEN Sequential (do (def x 5) (+ x 10)), empty blocks, async requests A then B completing B before A, a forward dependency, and a dependency cycle.
- AND startPel and resumePel with reversed receipt completion order.
- THEN Sequential result is 15, empty result is nil, async result is B's value after A completes, dependencies wait, and cycles return PEL_DEPENDENCY_CYCLE.

### Requirement: R-M1-010 Operator diagnostics

When evaluation fails, the Foreman Pel evaluator SHALL return a stable error code, precise source span, and applicable function signature.

#### Scenario: T-M1-010 Operator diagnostics

- WHEN A two-line program with (print ["hello" name] :sep " ") on line 2 and a registered print signature.
- AND startPel then renderPelDiagnostic.
- THEN PEL_ARGUMENT_MODE identifies line 2, marks the complete call, prints the registered signature, and supplies a named-argument example without unrelated environment data.

### Requirement: R-M1-011 Finite evaluation

If an evaluation bound would be exceeded, then the Foreman Pel evaluator SHALL stop before the next expression emits a host request.

#### Scenario: T-M1-011 Finite evaluation

- WHEN (for [1 2 3] i (test/echo i)) with maxIterations=2, recursive fuel exhaustion, oversized input, deep nesting, and continuation resumes.
- AND startPel then resume valid receipts until the first bound failure.
- THEN Exactly two loop requests can occur. The third body emits none. PEL_LIMIT names the bound and consumed count. Resume retains previous counters.

### Requirement: R-M1-012 Ordinary host values

When a fully applied host function is reached, the Foreman Pel evaluator SHALL suspend and resume through validated ordinary Pel data.

#### Scenario: T-M1-012 Ordinary host values

- WHEN (test/flag) ^> (if :cond ^ :then (for [1 2] i (* i 2)) :else []), and an incomplete host closure.
- AND startPel then resumePel with a successful Boolean receipt.
- THEN One ready request appears, a true receipt yields [2 4], and the incomplete host closure produces no request or resource reservation.

### Requirement: R-M1-013 Natural-language predicates

When case reaches a string condition, the Foreman Pel evaluator SHALL request a typed natural-language predicate result through host suspension.

#### Scenario: T-M1-013 Natural-language predicates

- WHEN (case [:tier "premium"] ["is premium" 1 #t 0]) with pel/nl-condition registered, plus a non-Boolean receipt.
- AND startPel and resumePel with true, false, and malformed predicate receipts.
- THEN The request includes scrutinee and condition. Results are 1 or 0. A string receipt fails with PEL_HOST_RESULT. No language-level authorization is produced.

### Requirement: R-M1-014 Serializable recovery boundary

When a continuation is encoded and restored, the Foreman Pel evaluator SHALL preserve lexical data, pending request identities, and consumed limits.

#### Scenario: T-M1-014 Serializable recovery boundary

- WHEN A partially complete do/async with a captured closure, one completed receipt, pending requests, changed digest, and duplicate receipt.
- AND Encode/decode PelContinuationV1, resume with matching receipts, then try mismatched and duplicate receipts.
- THEN Matching restoration returns the same final value without repeating completed calls. Changed bindings return PEL_CONTINUATION_MISMATCH. Duplicate or unknown receipts return PEL_HOST_RESULT.

