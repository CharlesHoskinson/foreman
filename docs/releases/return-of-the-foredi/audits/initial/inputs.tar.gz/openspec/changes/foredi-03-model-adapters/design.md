# Model adapter design

## Context and evidence

Read [adapter evidence](../../../docs/research/pel-release/ADAPTER-EVIDENCE.md) and its [capture manifest](../../../docs/research/pel-release/sources/models/manifest.json).
Those captures document advertised behavior as of 2026-09-12.
They do not establish account access, installed CLI routing or completed Foreman tests.
Use the manifest's exact source hashes in profile evidence.

Requirements use the [official EARS patterns](https://alistairmavin.com/ears/).
All commands and test files below are planned implementation targets.

## Package and ownership

Create `packages/providers/package.json` and `packages/providers/tsconfig.json`.
Use the workspace's strict TypeScript and Effect conventions.
Export the public contract through `packages/providers/src/index.ts`.
Extend `tsconfig.json`, `tsconfig.all.json`, `package.json` and `scripts/build-runtime.ts` for package compilation and test discovery.
Use Node.js 24 for compiled product execution.

| Planned file | Contract or responsibility |
| --- | --- |
| `packages/providers/src/contract.ts` | ProviderRequestV1, ProviderEventV1, ProviderIdentityV1, ProviderTransport |
| `packages/providers/src/errors.ts` | Tagged Effect failures with safe diagnostics |
| `packages/providers/src/profiles.ts` | Six immutable profile definitions and pure control validation |
| `packages/providers/src/registry.ts` | Resolve explicit profile and transport with source-bound evidence |
| `packages/providers/src/events.ts` | Pure incremental event normalization and cursor handling |
| `packages/providers/src/tools.ts` | Tool-call/result encoding with host-supplied authorization and receipts |
| `packages/providers/src/output.ts` | Original host-schema validation after provider schema lowering |
| `packages/providers/src/continuation.ts` | Versioned opaque state envelope and prefix binding |
| `packages/providers/src/readiness.ts` | Separate discovery, auth, currency, identity and capability facts |
| `packages/providers/src/qualification.ts` | Evidence matching and bounded qualification reports |
| `packages/providers/src/transports/{xai-responses,anthropic-messages,openai-responses,google-interactions}.ts` | Four direct API protocols |
| `packages/providers/src/transports/{grok-acp,claude-code,codex-app-server,gemini-cli}.ts` | Four native coding protocols |

Reuse `packages/orchestration/src/credential-profile*.ts` for secret resolution.
Reuse `packages/launcher/src/supervise.ts` for scoped subprocess ownership.
Reuse Council schema lowering only through explicit provider capabilities and host validation.
M4 owns retries, deadlines, reservations, worktree authority, tool execution and durable event persistence.
Transports never run a second workflow loop.
Transport reconnection can continue an existing request within its limits. It cannot create a replacement request automatically.

## Shared service contract

`ProviderRequestV1` contains `schemaVersion: 1`, `effectId`, `profileId`, `transportId`, `trustedInstructions`,
`artifacts`, `toolPolicy`, `outputSchema`, `limits` and optional `continuation`.
Artifacts contain immutable content references and hashes. Credentials remain service references outside serialized requests.
Limits contain deadline, maximum input/output tokens, maximum tool calls and spend reservation reference.
Profile resolution adds profile hash, source-manifest hash and transport version.
No adapter accepts a generated instruction as authority.

`ProviderIdentityV1` discriminates `api` and `native`.
API identity includes provider, exact model, endpoint revision and response/interaction ID.
Native identity includes provider, exact model, protocol version and session/thread/turn IDs.
A response ID cannot act as a native session ID.

`ProviderEventV1` contains `effectId`, provider identity, source event ID or cursor and a discriminated payload.
The vocabulary is `started`, `text`, `tool-request`, `usage`, `checkpoint`, `completed`, `refused`, `failed`, `cancelled`.
Checkpoint payloads reference opaque continuation blobs in the existing session store.
Expose `ProviderGenerationPort.generate(GenerationRequest): Effect<GenerationResponse, ProviderFailure>` for M2.
Map its exact `modelProfileId` explicitly to `ProviderRequestV1.profileId`.
Preserve transportId, grammar mode, prompt, catalog, attempt index and the `{pelSource:string}` output envelope.
M2 owns the initial attempt plus two repairs, 60-second attempt bounds, 180-second total bound and 1 MiB source limit.
M3 makes one generation request per call and never parses authority from, repairs or executes the generated Pel.
Implement this mapping in `packages/providers/src/generation.ts`.
Usage retains observed token, cache and price-schedule dimensions. Unknown costs stay unknown.
The host applies conservative reservations when provider accounting is incomplete.
Completed means a schema-valid provider result. It never means host verification passed.

`ProviderTransport` exposes these Effect operations:

- `probe(input): Effect<ReadinessV1, ProbeFailure>`
- `start(request): Effect<Stream<ProviderEventV1, ProviderFailure>, ProviderFailure, Scope>`
- `sendToolResult(identity, result): Effect<void, ProviderFailure>`
- `cancel(identity): Effect<CancellationObservationV1, ProviderFailure>`
- `resume(request, identity, cursor): Effect<Stream<ProviderEventV1, ProviderFailure>, ProviderFailure, Scope>`

`ToolResultV1` carries the originating call ID, effect ID, authorization binding and host receipt reference.
The transport submits a result only through the admitted host tool port.
Native permission exchanges use the same port. A CLI with no adequate permission boundary cannot advertise unrestricted coding support.
Duplicate events preserve their source identity. M4's journal decides whether a committed tool effect has a reusable result.

Failures include `ModelUnavailable`, `ModelMismatch`, `UnsupportedCapability`, `CapabilityUnverified`,
`PromptChannelUnsupported`, `AuthenticationRequired`, `ProbeUnknown`, `OutputInvalid`, `OutputIncomplete`,
`MalformedEvent`, `ContinuationMismatch`, `ResumeUnavailable`, `OutcomeUnknown`, `RateLimited` and `TransportDisconnected`.
Each error carries safe context and a retry classification. The host decides whether a retry is allowed.
Never embed credentials, raw hidden reasoning or full sensitive provider payloads in public diagnostics.

## Exact profiles

| Profile | API and native targets | Required controls and negative fixtures |
| --- | --- | --- |
| `grok-4.6` | xAI Responses, Grok Build ACP | low/medium/high/xhigh. Reject max. Remote cancellation and cursor replay remain unknown pending endpoint evidence. |
| `claude-opus-5` | Messages, Claude Code stream-json | low/medium/high/xhigh/max. Reject disabled thinking at xhigh/max. |
| `claude-fable-5-1` | Messages, Claude Code stream-json | Adaptive thinking stays enabled. Reject manual budget, non-default sampling and forced any/named tool choice. |
| `gpt-6-astra` | Responses, Codex app server | low/medium/high/xhigh/max. Reject none. Preserve response reasoning items. |
| `gpt-5.6-sol` | Responses, Codex app server | none/low/medium/high/xhigh/max. Preserve Sol defaults and dated pricing independently. |
| `gemini-3.8-flash` | Interactions, Gemini CLI | low/medium/high. Reject minimal. Keep thought steps distinct from generateContent signatures. |

Exact model controls come from [Grok](https://docs.x.ai/developers/grok-4-6),
[Opus](https://platform.claude.com/docs/en/models/opus-5/overview),
[Fable changes](https://platform.claude.com/docs/en/models/fable-5-1/whats-new-fable-5-1),
[Astra](https://developers.openai.com/api/docs/models/gpt-6-astra),
[Sol](https://developers.openai.com/api/docs/models/gpt-5.6-sol) and
[Gemini](https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash).
Use captured limits without replacing an undocumented output limit with infinity.
Pricing records include effective date, tier, cache reads/writes and long-context thresholds.
Do not copy numeric prices into permanent execution defaults.

Initial coverage targets all six profiles on each family's direct API and native coding protocol.
Support remains unavailable until a cell has its required evidence.
An unsupported native capability stays visible and cannot silently switch to an API session.
Headless Codex, Grok fallback and Agent SDK modes require separate explicit transport records if added.
Do not add those modes merely to increase the support matrix.

## Semantic transport rules

For xAI, encode its own Responses semantics and encrypted thinking.
Its documentation does not establish OpenAI-compatible remote cancellation or cursor replay.
For OpenAI, preserve response items and use documented response-ID/cursor reconnection.
For Anthropic, preserve thinking blocks byte-for-byte and bind Fable's append-only prefix.
For Google, preserve Interactions thought steps and observe terminal state before chaining.
These distinctions follow the transport sources linked in the [adapter evidence](../../../docs/research/pel-release/ADAPTER-EVIDENCE.md).

Prompt channels are `protocol`, `stdin`, `file` or explicitly bounded `argv`.
Do not interpolate prompts into a shell command.
Extend the typed launcher input contract if stdin is required.
The current worker path cannot carry stdin while the Council Codex canary uses it.
Test both callers against the same byte-preservation fixtures.

Lower a response schema only within the selected provider's documented subset.
Validate the final result against the original host schema.
Treat refusal and truncation as terminal provider outcomes even if their envelopes are valid JSON.
Use a structured envelope containing Pel source when grammar constraints are unavailable.
A JSON string containing Pel does not establish Pel grammar validity.

## Cancellation, continuation and recovery

`CancellationObservationV1` has independent requested, acknowledged, localCleanup and remoteOutcome fields.
Remote outcome is `pending`, `cancelled`, `completed`, `unknown` or `unsupported`.
A closed socket or killed child does not establish remote cancellation.
Claude SIGTERM and interrupt fixtures preserve their different resume behavior.
OpenAI and Gemini poll or reconnect only as documented.
xAI remote cancellation remains unknown until separately qualified.

Opaque continuation envelopes include provider/model/transport identity, schema version, prefix hash, retention metadata and exact payload hash.
Store payloads through the existing protected session store.
Export concise conclusions through research interfaces, never hidden reasoning.
A changed model starts a new provider session with explicit artifact context.
Retention expiry returns `ResumeUnavailable`. Uncertain completion returns `OutcomeUnknown`.
Neither failure authorizes redispatch.

## Qualification and validation

Add `packages/providers/src/**/*.test.ts` to root `npm test`.
Add `test:providers` invoking the existing TypeScript test runner with that glob.
Implement T-M3-019 in `generation.test.ts` and T-M3-020 in `usage.test.ts`.
Run `npm run typecheck`, `npm run test:providers`, `npm run build` and `npm run verify-runtime`.
Expected result: compiled Node.js 24 product, complete fixture coverage and no hidden transport fallback.

Expose planned commands `foreman providers list --json` and `foreman providers qualify` through the existing orchestration CLI.
The default list is read-only and does not launch a workload.
Qualification requires an explicit account reference, exact profile, transport and limits file.
Default hard maxima per cell are 180 seconds, 30,000 tokens, two tool calls and USD 5.
A smaller host limit always wins. Unknown cost consumes the conservative reservation.
Use disposable workspaces and harmless tool fixtures.

A report records requested/observed identities, installed version, API revision, source/profile hashes, timestamps, bounds and each observed capability.
Include model-not-found, denial, refusal, truncation, stream loss, tool replay, expiry and cancellation outcomes.
Some failures need fault-injected contract tests rather than live reproduction.
Label those evidence types separately.
Run no live calls as part of ordinary deterministic tests.
No live test is recorded as passed in this change.
