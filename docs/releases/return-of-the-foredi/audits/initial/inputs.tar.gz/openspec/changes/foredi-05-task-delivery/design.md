# M5: Deliver useful work from Pel

## Outcome

An operator runs one Pel program and receives a candidate, host verification, independent review, and actionable findings.
Publication proceeds only when existing host authority explicitly covers the requested candidate and destination.

## Existing integration points

| Existing path | Retained behavior |
| --- | --- |
| `packages/orchestration/src/round-transaction.ts` | Attempt-bound implementation, checkpoint capture, gate execution, and report reading seams. |
| `packages/orchestration/src/round-live-services.ts` | Worktree command execution, checkpoint capture, bounded report reads, and environment handling. |
| `packages/orchestration/src/report-freshness.ts` | Reject stale, missing, and wrong-attempt evidence. |
| `packages/orchestration/src/execution-ledger.ts` | Reserve actions, register authority and outcomes, and preserve attempt limits. |
| `packages/orchestration/src/execution-terminal-policy.ts` | Require declared milestones before terminal success. |
| `packages/policy/src/release-authority.ts` | Decode authority, bind source receipts, and check current candidate evidence. |
| `packages/orchestration/src/release-authority-cli.ts` | Reuse typed authority and outcome registration. Do not shell through its CLI. |
| `packages/orchestration/src/release-policy.ts` | Preserve deterministic policy checks and exact release bindings. |
| `components/council/packages/application/src/prompt-preflight.ts` | Reuse trusted-instruction and untrusted-evidence separation. |
| `components/council/packages/application/src/schema-lowering.ts` | Reuse checked schema lowering where transport qualification permits it. |
| `skills/foreman/scripts/audit-run.sh` | Port current audit invalidation and current-attempt evidence semantics into typed services. |
| `skills/foreman/scripts/merge-gate.sh` | Preserve merge-base, branch, candidate, and release-authority checks during typed publication implementation. |
| `skills/foreman/scripts/wt-merge.sh` | Preserve isolated candidate capture and target conflict checks where integration is requested. |

The baseline does not contain a generic typed publication transaction.
Implement that missing host operation while reusing current authority and invariants. Do not claim that the shell merge gate publishes remotely.
The publication destination is a host-admitted descriptor. Pel never supplies arbitrary shell commands or unrestricted URLs.

## Planned files and interfaces

All new executable code uses strict TypeScript on Node.js 24. Effect owns each host operation's fallible resources within the M4 run scope.

| Planned path | Export |
| --- | --- |
| `packages/orchestration/src/pel-host-contract.ts` | `CandidateRefV1`, `VerificationReceiptV1`, `ReviewReceiptV1`, `PublicationReceiptV1`, and strict decoders. |
| `packages/orchestration/src/pel-host-library.ts` | `makeForemanHostRegistry()` extends M2 descriptors with the four executable handlers. |
| `packages/orchestration/src/pel-host-task.ts` | `runTask(args: TaskArgsV1, ctx: HostContextV1): Effect.Effect<PelValue, HostEffectFailure, TaskServices>`. |
| `packages/orchestration/src/pel-host-verify.ts` | `verifyCandidate(args: VerifyArgsV1, ctx): Effect.Effect<PelValue, HostEffectFailure, VerifyServices>`. |
| `packages/orchestration/src/pel-host-review.ts` | `reviewCandidate(args: ReviewArgsV1, ctx): Effect.Effect<PelValue, HostEffectFailure, ReviewServices>`. |
| `packages/orchestration/src/pel-host-publish.ts` | `publishCandidate(args: PublishArgsV1, ctx): Effect.Effect<PelValue, HostEffectFailure, PublishServices>`. |
| `packages/orchestration/src/pel-publication-service.ts` | `PublicationService.prepare`, `commit`, and `observe` adapt existing authority, candidate checks, and destination transport. |
| `packages/orchestration/src/pel-delivery-result.ts` | `projectDeliveryResult(events): DeliveryResultV1` and plain-text rendering. |
| `packages/orchestration/src/pel-delivery.test.ts` | Compiled CLI workflow fixtures and the first vertical slice. |
| `examples/pel/implement-verify-review.pel` | Executable native Pel example for Grok, host verification, and Sol. |
| `examples/pel/repair-and-publish.pel` | Bounded repair and separately authorized publication example. |

`HostContextV1` contains M4 effect identity, attempt, bound contract, admitted workspace, registry, artifact root, and resource grants.
Host functions do not reserve independent retry loops. M4 dispatch validates grants and reserves through the existing ledger.
Each handler reports typed success or failure through M1 `HostReceiptV1`. Durable completion returns an ordinary `PelValue`.

## Function and value contracts

All four functions are ordinary registered Pel functions with M1 `ArgSpec`, fixed named arguments, output schemas, and M2 effect declarations.
Only admitted full application can dispatch. Partial application stores values. Unselected branches remain inert.

| Function | Named arguments | Result keys |
| --- | --- | --- |
| `fm/task` | `:id`, `:model`, `:input`, `:output` | `status`, `candidate`, `artifacts`, `implementation-receipt`, `findings` |
| `fm/verify` | `:id`, `:input`, `:gate` | Prior candidate keys plus `verification`, `checks`, `findings` |
| `fm/review` | `:id`, `:model`, `:input`, `:policy` | Prior candidate and verification keys plus `review`, `verdict`, `findings` |
| `fm/publish` | `:id`, `:input`, `:destination` | Prior evidence keys plus `publication`, `status`, `next-action` |

Values use the M1 association-list representation with keyword keys, such as `[:passed #t :candidate "artifact:c1"]`.
Native lookup uses `(result :at ':passed)`. Values contain immutable artifact and receipt references, not privileged capability objects.
Returned reference strings cannot authorize operations. The host resolves them against the current run and checks their digests and authority.
`TaskArgsV1.input` accepts a bounded artifact reference or an ordinary Pel value containing admitted artifact references.
`output` selects a registered schema. Unknown schemas and oversized or malformed provider results yield typed errors.
`gate` selects a host-owned argv vector and environment binding. It cannot contain a command string supplied by a model.
`policy` selects registered independent-review policy. The host checks actual provider identity before recording an authorizing review.
`destination` resolves a host-owned target descriptor, including repository, remote, ref, operation, and expected destination identity.
There is no `approved` Boolean argument and no model-generated authority receipt.

`CandidateRefV1` contains repository ID, base commit, candidate commit, tree digest, diff digest, allowed-path digest, artifact manifest digest, and producing attempt.
`VerificationReceiptV1` additionally binds gate digest, environment digest, candidate identity, execution attempt, result, and report digest.
`ReviewReceiptV1` binds candidate and verification receipt, observed implementer and reviewer vendors/models/transports, review policy, findings, and report digest.
`PublicationReceiptV1` binds candidate, verification, review, authority receipt, destination, operation identity, and observed external result.
The existing policy receipt schema remains canonical. These host records refer to it and add Pel effect linkage.
Use `canonicalize` and `sha256Hex` from `packages/core`. Do not introduce a second canonicalization scheme.

## Implementation and verification

`fm/task` uses an admitted isolated worktree and the exact M3 provider profile.
Trusted instructions and untrusted task evidence occupy separate fields in `ProviderRequestV1`.
Provider tool requests pass through M4 dispatch policy. They cannot expand writable paths or host authority.
The host captures an immutable candidate manifest after the provider stops. Provider prose cannot certify changed files or completed checks.
A no-op implementation has `status = "no-change"` with observed artifacts and no invented completion evidence.
A result outside allowed paths fails with `candidate-out-of-scope`. Preserve the candidate for inspection without promoting it.

`fm/verify` runs the admitted gate in a scope that protects candidate identity.
It returns `:passed #t` only for a matching host pass and `:passed #f` for an observed failed check.
It captures pre-check and post-check tree identities. Any candidate mutation invalidates the receipt.
A check failure returns `status = "verification-failed"` with bounded findings and report references as ordinary Pel data.
Transport, report corruption, and policy failures use typed failures. Do not convert infrastructure failure into a passing check.
Reuse an existing verification receipt only when candidate, gate, environment, policy, and evidence freshness bindings match exactly.
Repeated unchanged verification consumes no new verification action. A changed binding requires a new allowed verification reservation.
This preserves one full verification per unchanged candidate and environment.

## Independent review and bounded repair

`fm/review` gives the reviewer immutable candidate artifacts and host verification evidence.
It records in-progress review state before dispatch. It cannot reuse an old approved report as the current attempt result.
Actual observed vendor identity must differ from the implementer's vendor. Changing only model names cannot satisfy independence.
Review verdicts are `approved`, `changes-requested`, or `unverified`. Missing, refused, interrupted, or malformed review is unverified.
The host records reviewer evidence provenance and findings before a review can satisfy a milestone.
A model-generated verification or publication claim remains untrusted review content.

The first example uses Grok `grok-4.6`, host `candidate-full` verification, and Sol `gpt-5.6-sol` with `independent-review` policy.
Its pipeline is the release design's existing `fm/task ^> fm/verify ^> fm/review` program.
Run it with recorded profiles first. A live run requires the exact model/transport capabilities to be qualified by M3.
A second fixture rebinds admitted model profile data and executes the same control flow.
Missing qualification produces an actionable unsupported-profile result, never a silent fallback.

The repair example uses native `if` and bounded `for` with `fm/task`, `fm/verify`, and `fm/review` results.
A review finding triggers at most the correction rounds admitted in `ExecutionContractV1`.
`fm/retry` handles eligible transient transport failures only. It does not reinterpret a negative review as a transport failure.
Each changed candidate invalidates its previous verification and review bindings.
A no-op correction preserves findings and terminates with needs-action once the admitted progress rule or correction bound applies.
No task DSL, stage scheduler, or private re-prompt loop is added.

## Authorized publication

`PublicationService.prepare` checks the exact candidate, all required receipts, current authority, destination identity, and resource ownership.
A missing publication grant yields ordinary Pel `status = "needs-action"` and a concrete authorization request referencing the prepared evidence.
This is an expected workflow outcome. It performs zero integration, push, or release mutation.
M4 records this unresolved required milestone as run `needs-action`, even when pure evaluation returns its result normally.
A malformed, wrong-candidate, or forged authority receipt yields `publication-authority-invalid`.

`commit` repeats authority and candidate checks under the destination resource lock.
Reserve the existing `integrate` or `publish` action through `EndstopLedger.executeChild` before its effect.
Local integration and external publication are separate operations with separate receipts and permissions.
Implement the first destination as an admitted Git ref update with an expected old object ID and an immutable candidate commit.
Use exact argv through the existing launcher. Do not use a shell command string or force publication onto an unexpected ref.
Preserve target index and merge-base protections for any host-admitted integration operation.
Unimplemented destination kinds return `publication-destination-unsupported` before external mutation.

`observe` checks the exact admitted remote ref or destination operation identity after interruption.
Confirmed publication produces a durable receipt. A lost acknowledgement yields `unknown-external-outcome` and M4 reconciliation.
The runtime does not repeat an uncertain publication automatically. Local process exit alone cannot establish publication success.
Publish authorization cannot originate in Pel text, natural-language predicates, provider tool output, or an audit verdict alone.
This planning change does not register publication authority or publish anything.

## Operator results and errors

`DeliveryResultV1` extends M4 `RunResultV1` with candidate, checks, review, publication, findings, and `nextAction` fields.
The text view links artifact paths and names the source-located failing host call.
The standard command is `foreman run FILE`. It resolves existing project configuration and authority without mandatory manual JSON preparation.
The JSON view preserves typed error codes and exact identities. Both views derive from the same journal projection.
Use M4 lifecycle exit codes, including `3` for needs-action and `5` for pending work.
A completed implementation with required review missing is not run success.
A delivered candidate may be successful when the admitted contract requires no publication milestone.

Specific host error codes are `task-output-invalid`, `artifact-missing`, `candidate-out-of-scope`, `candidate-changed`, `verification-unavailable`, `review-not-independent`, `review-invalid`, `publication-authority-invalid`, and `publication-destination-unsupported`.
`HostEffectFailure` carries these registered operation-specific codes plus the M4 common codes.
Do not retry authentication, identity, evidence, or authorization failures automatically.
Show the safe next operation and the required artifact reference. Do not expose credential values or opaque provider state.

## Planned validation

Use deterministic recorded Grok and Sol events, temporary Git repositories, fake gate commands, and a local bare remote.
Test the compiled product through `node skills/foreman/runtime/dist/foreman.js` after `npm run build`.
A temporary fixture authority permits publication only to that fixture remote.
Test publication denial, candidate mutation, stale review, forged receipts, same-vendor review, no-op repair, and lost acknowledgement.
Test process crashes during host verification and after each effect receipt. Assert completed provider work is not dispatched again.
Run `npx tsx scripts/run-tests.ts "packages/orchestration/src/pel-host-*.test.ts" "packages/orchestration/src/pel-delivery*.test.ts"`.
Run `npm run typecheck` and `npm run verify` after implementation. Runtime tests described here have not been executed during planning.
