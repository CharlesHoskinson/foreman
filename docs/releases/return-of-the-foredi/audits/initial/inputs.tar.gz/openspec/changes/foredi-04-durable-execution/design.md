# M4: Execute and recover Pel programs

## Outcome

One command executes an admitted Pel program. Operators can inspect results, request cancellation, and resume interrupted work with its original limits.
A durable receipt supplies the same ordinary Pel value after recovery.

## Existing integration points

| Existing path | Use in M4 |
| --- | --- |
| `packages/event-log/src/run-journal.ts` | Reuse `RunJournal.allocate`, `transact`, `append`, and `reserveResumeAttempt`. |
| `packages/event-log/src/stored-event.ts` | Keep the frozen envelope. Put versioned Pel records inside the opaque payload. |
| `packages/orchestration/src/execution-ledger.ts` | Reuse `EndstopLedger.execute`, `executeChild`, authority registration, and durable reservations. |
| `packages/orchestration/src/execution-terminal-policy.ts` | Preserve limit accounting, terminal rejection, and milestone decisions. |
| `packages/orchestration/src/round-transaction.ts` | Reuse attempt, command, checkpoint, and report service seams. Keep historical round behavior. |
| `packages/orchestration/src/resume-decision.ts` | Retain corruption, current-attempt, and ownership checks for legacy histories. |
| `packages/orchestration/src/supervisor.ts` | Keep discovery and exclusive ownership. Route Pel recovery to the new run owner. |
| `packages/orchestration/src/resume-queue-execution.ts` | Delegate admitted Pel continuation to the run owner. Do not add another retry loop. |
| `packages/launcher/src/supervise.ts` | Retain bounded subprocess output, process cleanup, timeout, and cancellation. |

The inspected journal supports generic event types. It has no Pel continuation decoder today.
The graph is navigation evidence. Direct source inspection established these integration points.

## Planned TypeScript interfaces

All paths below are planned unless listed above. Compile strict TypeScript and execute the product with Node.js 24.
Use Effect 3 through the existing workspace dependency for fallible services and scoped resource ownership.

| Path | Export and responsibility |
| --- | --- |
| `packages/orchestration/src/pel-run-contract.ts` | `ExecutionBindingV1`, `RunStatusV1`, `RunResultV1`, `RunFailure`, strict record decoders. |
| `packages/orchestration/src/pel-runner.ts` | `runProgram(checked: CheckedProgramV1, binding: ExecutionBindingV1): Effect.Effect<RunResultV1, RunFailure, RunServices>`. Own the single run scope. |
| `packages/orchestration/src/pel-effects.ts` | `executeHostEffect(request, context): Effect.Effect<PelValue, HostEffectFailure, RunServices>`. Consume M1 suspension requests through M2 descriptors. |
| `packages/orchestration/src/pel-journal.ts` | `recordIntent`, `recordObservation`, `recordResult`, and `replayPelRun`. Adapt existing journal operations. |
| `packages/orchestration/src/pel-resource-scope.ts` | `acquireEffectResources(reads, writes, owner)` and scoped concurrency permits. |
| `packages/orchestration/src/pel-recovery.ts` | `resumeProgram`, `reconcileEffect`, and `validateRevision`. Reuse recorded results. |
| `packages/orchestration/src/pel-control-functions.ts` | Register `fm/race`, `fm/retry`, and `fm/checkpoint` using M1 `ArgSpec` and M2 effect descriptors. |
| `packages/orchestration/src/pel-authoring-cli.ts` | Extend M2 argument parsing and command handlers for lifecycle commands. |
| `packages/orchestration/src/pel-authoring-main.ts` | Extend M2 compiled CLI entry point. |

`RunServices` contains journal, ledger, provider registry, host dispatcher, launcher, resource scope, and clock services.
`ExecutionBindingV1` contains run ID, attempt identity, contract ID and hash, authority hash, checked-program digest, state-root reference, and owner lease reference.
M2 supplies `CheckedProgramV1` and `PlanPreviewV1`. M1 supplies `PelValue`, `PelStep`, and its data-only continuation.
`PelStep` is `done`, `suspend`, or `failed`. The owner records a host result before supplying it to the evaluator.
The `suspend` step contains nonempty `ready: HostRequestV1[]`, a `PelContinuationV1`, and consumed counters.
The owner validates and schedules that ready batch. It supplies `HostReceiptV1` success values or typed host failures to M1.
Ready requests can wait for resource permits without creating a second scheduling authority.
The M3 `ProviderRequestV1` includes effect identity, exact profile, transport, instructions, artifacts, tool policy, schema, limits, and opaque continuation.
The runtime calls `ProviderTransport.start`, `sendToolResult`, `cancel`, and `resume`. Adapters own transport I/O only.

`RunStatusV1.state` is `running | suspended | cancel-requested | cancelled | needs-action | succeeded | failed`.
`RunStatusV1.externalOutcome` is `none | pending | confirmed-complete | confirmed-cancelled | unknown`.
`needs-action` is recoverable. Terminal statuses remain terminal unless a separate, admitted successor run references their history.
`RunResultV1` adds program digest, attempt, final Pel value, artifact references, receipt references, usage bounds, and source-located diagnostics.
A diagnostic contains `code`, `sourceSpan`, `effectId`, `retryable`, and `nextAction`. Secret values never enter diagnostics.

`RunFailure.code` is one of `binding-mismatch`, `owner-busy`, `journal-corrupt`, `journal-write-failed`, `continuation-incompatible`, `budget-exhausted`, or `terminal-run`.
`HostEffectFailure.code` also includes `capability-denied`, `resource-denied`, `timeout`, `provider-failure`, `unknown-external-outcome`, and `reconciliation-required`.
Preserve the M3 provider failure category and observed cancellation outcome as structured causes.

## Journal and recovery protocol

Use `pel.run.v1`, `pel.effect.intent.v1`, `pel.effect.observed.v1`, `pel.effect.result.v1`, `pel.checkpoint.v1`, and `pel.cancel.v1` payload types.
Each payload includes schema version, checked digest, runtime version, language profile, attempt identity, and relevant authority binding.
M1 `requestId` hashes source and registry digests, AST node identity, and the full logical invocation path.
M4 `effectId` hashes run ID, admitted revision digest, attempt identity, request ID, and retry ordinal.
Persist that deterministic mapping in each intent and receipt. Ordinal zero identifies the initial attempt.
Retries increment the ordinal and link the prior effect ID. A prior receipt never completes a new retry ordinal.
Replay can reuse a receipt only when the complete mapping matches. Repeated loop visits have distinct M1 invocation paths.
Checkpoint values contain AST positions, lexical values, pure closure code references, captured values, and pending effect identities.
Store data-only bounded records. Do not serialize JavaScript closures, capabilities, process handles, or secret material.
Opaque provider continuation belongs to its original profile and transport. Journal entries reference its protected artifact by hash.

For each external effect:

1. Validate the resolved arguments against M2's checked capability and budget envelope.
2. Reserve the action through the existing execution ledger using a stable effect key.
3. Append an intent and reservation reference before dispatch.
4. Dispatch through the registered host operation.
5. Append provider request or session identity when observed.
6. Validate the result and append its canonical Pel value or immutable result artifact reference.
7. Resume evaluation from that recorded value.

Ledger reservation and intent append are not assumed to share one atomic transaction.
Recovery joins them by stable effect key. A reservation without intent remains spent until deterministic reconciliation confirms no dispatch.
The current reservation API may need an additive typed effect key. Its owner remains `EndstopLedger`.
A crash after intent can leave an unknown outcome even without a provider request ID.
Never infer no dispatch from a missing provider ID. Reconcile through M3 when supported, otherwise require a bound recovery decision.
The supported decision file schema is `PelRecoveryDecisionV1` with run, effect, checked digest, decision, evidence refs, and authority receipt.
Decisions are `accept-result`, `confirm-no-dispatch`, or `abandon`. A decision cannot grant broader capabilities or replenish limits.
Unresolved external cost keeps the original conservative reservation. Recorded receipt replay performs zero provider calls.
Identical duplicate receipts are no-ops. Conflicting receipts fail with `journal-corrupt` and preserve both evidence references.

`fm/checkpoint :name` returns an association list containing its name and journal sequence.
Resume validates journal ordering, hashes, attempt identity, runtime compatibility, and the owner lease before evaluator activation.
A source edit requires `foreman resume RUN --revision FILE --decision FILE` with a checked revision decision.
The revision records parent digest, completed-prefix digest, unchanged effect identities, authority binding, and original budget counters.
An incompatible runtime or altered completed prefix yields `continuation-incompatible`. No effect is dispatched.

## Native execution and resource ownership

Native `do` preserves source order. Native `do/async` preserves the M1 last-source-expression result contract.
The runtime applies M1 dependency edges and M2 resolved resource declarations before dispatching eligible expressions.
Parallel read/read access is allowed. Write/write and read/write overlap waits for exclusive access.
Canonical worktree identity includes repository identity and resolved path. Symlink aliases cannot bypass a conflict.
An unknown resource declaration takes the admitted workspace-wide exclusive lock.
Acquire complete resource sets in canonical order. Release them with the effect scope to avoid deadlock.
Provider concurrency permits and resource permits belong to the same run owner, with no scheduler database.

`fm/race :tasks [closures] :winner "first-valid"` requires separate writable worktrees for all contenders.
The winner is the first schema-valid, policy-eligible result with a committed journal decision.
Simultaneous eligibility uses source order. The owner cancels losers and waits for local cleanup.
Unknown remote cancellation remains visible and charged. Losing artifacts remain isolated and cannot become publication inputs.
`fm/retry :attempts N :on [categories] :body closure` uses the existing action, cost, and deadline budgets.
Only declared transient failures can retry. Authentication failure, profile mismatch, policy denial, and invalid capabilities cannot retry.
A retry creates a new provider session when required. It never forwards opaque state across models or transports.
Timeouts interrupt local work and request remote cancellation. Neither timeout nor process exit confirms remote cancellation.

Trusted control-function arguments can contain internal `PelClosureValue` data. Ordinary host return values cannot contain closures.
M1 exports `evaluateClosure(closure: PelClosureValue, args: readonly PelValue[], context: ClosureEvaluationContextV1): PelStep`.
The context binds program, profile, registry, parent request, child invocation, lexical environment, and allocated finite remaining limits.
M1 exports `mergeClosureResult(parent: PelContinuationV1, invocationId: string, receipt: HostReceiptV1, consumed: PelCounters): PelStep`.
M4 runs child evaluation within the same run scope and dispatches its suspended host batches through the existing dispatcher.
M4 debits child reduction and iteration counters from the shared run envelope before granting another tranche.
Children cannot each inherit the full unused run budget. M1 validates child identity and counter limits when merging the result.
Never pass internal closure values to provider transports or persist them as JavaScript functions.

## Command behavior

`foreman run FILE` resolves the configured project state root and existing execution authority, then checks and admits the program.
This is the standard operator entry point. It requires no separately authored JSON task plan or repeated manual admission ceremony.
`--binding FILE` and `--state-root DIR` provide explicit integration and fixture overrides. They cannot expand existing authority.
`--json` selects machine-readable output for any lifecycle command.
`foreman status RUN --state-root DIR --json` derives status from the journal and performs no provider call.
`foreman cancel RUN --state-root DIR --json` appends an idempotent cancellation request and signals the current owner.
`foreman resume RUN --state-root DIR --json` recovers only after ownership, history, authority, and budget checks.
`--decision FILE` supplies an explicit recovery record. `--revision FILE` additionally supplies changed Pel source.
State-root arguments on status, cancel, and resume are optional overrides. Normal commands resolve the same configured project root.
The compiled test entry point is `node skills/foreman/runtime/dist/foreman.js` with the same arguments.
The public `foreman` entry point forwards to that bundle through the M2 command wiring.

Lifecycle exit codes are `0` succeeded, `1` failed, `2` invalid request, `3` needs-action, `4` cancelled, and `5` pending.
`status` returns that state code. `cancel` returns `5` while confirmation is pending, then `4` only for confirmed cancellation.
A successful read of a failed run does not emit an execution-success code.
Local ownership recovery uses existing supervisor lease evidence. A stale process identifier alone cannot authorize takeover.

## Planned validation

Use deterministic provider fixtures, injected clocks, resource barriers, journal fault seams, and isolated temporary repositories.
Cover six crash boundaries: before reservation, after reservation, after dispatch, after external completion, during verification, and during cleanup.
M5 supplies the verification-specific fault fixture. M4 tests the same host-service boundary using a deterministic verifier.
Each catalog test names an exact TypeScript target. None of these runtime tests has been executed in this planning change.
Run focused tests through `npx tsx scripts/run-tests.ts "packages/orchestration/src/pel-*.test.ts"`.
Run `npm run typecheck`, `npm run build`, and the compiled Node.js CLI acceptance fixtures.
Run `npm run verify` after implementation. Retain journal, execution ledger, terminal policy, and legacy resume regression coverage.
