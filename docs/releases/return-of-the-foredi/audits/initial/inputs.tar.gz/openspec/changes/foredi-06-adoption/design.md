# Adoption design

## Scope and source baseline

This milestone delivers working user features for **Return of the ForeDi**.
A numerical version requires reconciliation with the active release program.
Do not interpret the v0.5 bootstrap merge as completion of v0.5.

Use these planning sources:

- [Release design](../../../docs/superpowers/specs/2026-09-12-pel-release-design.md)
- [Release plan](../../../docs/superpowers/plans/2026-09-12-pel-release-plan.md)
- [Architecture and deletion map](../../../docs/research/pel-release/ARCHITECTURE-AND-DELETION-MAP.md)
- [Graph coverage](../../../docs/research/pel-release/GRAPH-COVERAGE.md)
- [Provider evidence](../../../docs/research/pel-release/ADAPTER-EVIDENCE.md)

Use the [official EARS patterns](https://alistairmavin.com/ears/) for the linked requirements.
All target paths, commands and assertions below are planned work.
No command result or reduction percentage is reported as measured.

## Implementation boundaries

All new executable source and tests use strict TypeScript.
Run compiled product entry points on Node.js 24.
Use Effect for filesystem transactions, process resources, timeouts and concurrent work.
Keep counting, decoding and report projection as pure TypeScript functions.

| Planned path | Responsibility |
| --- | --- |
| `packages/orchestration/src/pel-adoption.ts` | Installed workflow checks and public example metadata |
| `packages/orchestration/src/pel-install.ts` | Install prerequisites, archive validation and compatible rollback |
| `packages/orchestration/src/pel-migration.ts` | Pure legacy decoding and Pel emission, with parity report construction |
| `packages/orchestration/src/pel-simplification.ts` | Deterministic cohort, line and instruction measurements |
| `packages/orchestration/src/pel-research-context.ts` | Bounded reads, provenance checks and optional vault links |
| `packages/orchestration/src/pel-research-refresh.ts` | Atomic publication of derived research projections |
| `packages/orchestration/src/pel-package.ts` | Runtime/example/profile manifest verification |
| `packages/orchestration/src/pel-support.ts` | Safe diagnostic bundle projection from existing records |
| `scripts/build-runtime.ts` | Compile and package the same runtime entry points |
| `examples/pel/` | Shipped Pel workflows and model-specific variants |
| `docs/guides/pel/{install,quickstart,examples,migration,research,support}.md` | User instructions verified against installed product |

Extend the existing CLI router instead of creating a new control plane.
Reuse the M4 execution owner for all examples and imported workflows.
Use existing graph-context, session-store and graph-store services for bounded context.
Do not introduce a new authoritative graph or execution database.

## Installation and first successful task

The archive contains compiled runtime, command launcher, manifests, profile evidence, examples and matching documentation.
The launcher only locates Node.js and forwards exact arguments and byte streams.
It owns no business rules or durable state.
A clean-install test starts outside the checkout with no global tsx, Bun, Deno or Python dependency.

Implement `InstallManifestV1` with candidate hash, archive file hashes, required Node range, runtime schema range and example paths.
`installPackage(input)` returns `Effect<InstalledPackageV1, InstallFailure>`.
Resolve and validate the complete manifest before replacing an existing installation.
Use temporary staging and an atomic installed-version switch.
Tagged failures include `InstallPrerequisiteMissing`, `PackageIntegrityMismatch` and `InstallIoFailure`.

Document the exact supported archive command after the existing installer interface is selected.
Acceptance tests invoke that same documented command rather than an internal-only setup path.
The product must work from copied installation files.

The quickstart covers these concrete steps:

1. Install the archive on Node.js 24.
2. Configure explicit credential references for the selected provider transports.
3. Run `foreman providers list --json` and inspect readiness.
4. Check and preview `examples/pel/implement-review.pel`.
5. Configure the project's existing authority and bounded workspace during setup.
6. Start the workflow with one `foreman run <file>` command.
7. Inspect `foreman status <run-id>`, then demonstrate cancel or resume.

“One command” measures starting a standard workflow after installation, credentials and admission exist.
The run command resolves configured project state and authority through the existing host.
Explicit `--binding` and `--state-root` overrides remain available when needed.
The standard workflow does not require manually assembling a new JSON authority file for each task.
It does not conceal these prerequisites or count their prior completion as free installation.
The standard example performs implementation, host verification and independent review.
It uses Grok implementation and Sol review when those exact cells are qualified.
The same control flow has a second provider assignment fixture.
Do not force account access or fabricate qualification to make the quickstart look successful.

## Examples and profile selection

Ship these files under `examples/pel/`:

- `implement-review.pel` for sequential implementation, verification and independent review.
- `parallel-read.pel` for independent bounded read tasks.
- `bounded-rework.pel` for typed failures and a fixed retry bound.
- `race-cancel.pel` for isolated candidates, a host-valid winner and loser cleanup.
- `resume-checkpoint.pel` for interrupted work and recorded-effect reuse.
- `research-prepare.pel` for source-linked advisory context.
- `profiles/<exact-id>.pel` for each of the six requested model identities.

Each example carries purpose, expected artifacts, capability envelope and observed status instructions.
Use ordinary Pel and the frozen Foreman library.
Profile examples make separate API/native transport choices explicit through the supported admission configuration.
Do not create a second editable workflow JSON format.
Generated previews and provider registry records remain derived outputs.

Readiness is an account-and-transport fact from M3.
Show unavailable, unsupported and unknown cases with safe remedies.
A model-profile example is not evidence that the model has run.
The core examples must execute through deterministic fake transports in normal tests.
Live example runs require matching qualification evidence and explicit limits.

## Legacy migration without dual ownership

`importLegacyWorkflow(input): Either<MigrationDiagnostic, MigratedPelV1>` is a pure decoder and emitter.
`MigratedPelV1` contains Pel text, source hash, originating format/version and a derived parity report.
It does not contain another editable workflow representation.
`foreman migrate <legacy-input> --out <file.pel>` reads supported recorded or dormant plans.
Unknown fields and unsupported semantics produce `UnsupportedLegacyConstruct` with a source locator.
The importer never guesses a weaker interpretation.

The parity corpus includes implementation, verification, review, bounded rework, parallel work, race and interrupted recovery.
Council cases retain independence, blinding, quorum and authority policy.
Trace comparison ignores documented transport timing and compares required host effects, identities, limits and terminal outcomes.
Use historical fixtures for existing formats and fake providers for candidate execution.
Reuse original event records rather than rewriting history into a new schema.

An active legacy run keeps its current controller.
Migration returns `ActiveLegacyRun` with the current owner and a supported completion or recovery route.
The migration tool cannot transfer an active lease to the Pel runtime.
Historical status remains readable after old execution code is removed.

Implement replacement in complete caller-to-controller slices:

| Legacy path | Candidate disposition |
| --- | --- |
| `skills/foreman/scripts/vendor-multiround.sh` | Move bounded attempts into Pel and delete the old loop |
| `skills/foreman/scripts/lib/worker-cmd.sh` | Move exact command construction into M3 transports |
| `skills/foreman/scripts/adapters/{grok,codex,claude,agy}.sh` | Delete transport behavior or retain a thin compatibility adapter |
| `skills/foreman/scripts/{lane-run,worker-run,audit-run,resume,watch,lane-supervise}.sh` | Migrate callers to the compiled CLI and delete dispatch/recovery behavior |
| `packages/orchestration/src/{round-reducer,resume-queue-execution,supervisor}.ts` | Consolidate workflow branches under M4 while retaining required discovery and leases |
| `components/council/packages/adapter-{grok,claude,codex}/src/preflight.ts` | Replace duplicate encoding with M3 and preserve Council policy |
| `packages/orchestration/src/round-contract.ts` | Retain historical decoder after authored round plans retire |

Retain execution ledger, terminal policy, credentials, launcher containment, publication transactions and historical decoders.
Do not delete a safety property to reduce a line count.
Thin compatibility adapters only locate Node.js, forward argv/environment, execute one compiled entry point and preserve status and byte streams.
They cannot parse domain data, own state, retry, schedule or supervise work.
Prove each complete replacement with caller searches and execution tests.
Advisory graph traversal cannot establish the absence of callers by itself.

## Measurement contract

Freeze `docs/release-metrics/foredi-baseline.json` before implementation changes enter the cohort.
This is a measurement input, not a workflow plan.
Pin baseline `441c3fb9f6acb2656760d03cc79e7c706fb8b7dd`, source hashes, selected paths, behavior classifications and counting-tool version.
Classify active v0.5, lane-runtime-typescript and workflow-weight-reduction obligations by retained, replaced or deferred status.
Preserve the original authority and evidence references.
No classification silently marks an obligation complete.

`SimplificationBaselineV1` records old glue files/ranges and required instruction sources.
`SimplificationResultV1` records candidate files/ranges, replacement mapping, exclusions, raw counts and ratios.
Count nonblank production source lines with one pinned deterministic rule.
Include new Pel, provider and orchestration code that replaces cohort behavior, wherever those lines reside.
For mixed-purpose modules, freeze exact ranges and document why excluded lines implement retained responsibilities.
Report full package and repository production growth alongside the scoped cohort count.

Compute:

- `glueReduction = 1 - candidateReplacementGlueLines / baselineGlueLines`
- `instructionReduction = 1 - candidateRequiredTokens / baselineRequiredTokens`

Acceptance requires at least 0.40 glue reduction and 0.50 instruction reduction.
Keep generated files, tests and immutable archives outside production counts, with separate totals.
Do not move replacement behavior outside the old directory and omit it.
Do not omit mandatory instruction text because it moved into help, profiles or generated prompts.
Pin the tokenizer package, version and options in the baseline.
Count the complete required cold-start orchestration instructions through first standard-workflow start.
Keep optional tutorials separate and report their counts.

Also report commands after prerequisites, workflow loops, entry points, provider conditionals and durable state owners.
Assert one active control-flow owner per run and one authoritative event history.
Assert exactly one reusable full verification for unchanged candidate/base/check/tool/dependency/environment bindings.
A changed binding must invalidate reuse.
Measure deterministic fixtures and actual candidate data separately.
No baseline or candidate number is invented by this specification.

## Research and optional Obsidian context

The runtime uses a portable repository research bundle by default.
The local authoring vault `/home/charl/vaults/Foreman` is optional and never hardcoded as an installation dependency.
No Obsidian plugin controls Foreman's execution authority.
The captured plugin does not establish Grok support or control of all six models.

Implement these CLI views:

- `foreman research query <text> --json --limit <n>`
- `foreman research status --json`
- `foreman research refresh --bundle <captured-bundle>`
- Optional `--vault <path>` for linked external context.

`ResearchContextV1` contains bounded excerpts, source locators, raw/clean hashes, capturedAt, claim class, freshness and extraction coverage.
Claim classes distinguish hypothesis, adopted decision, verified observation and open question.
Return explicit missing or stale markers.
A missing optional vault does not block check, plan, run, status or resume.
Research text remains untrusted evidence and cannot change capabilities or host results.

Refresh reads an explicitly selected captured source bundle.
It validates manifests and atomically publishes derived notes/index/graph references.
It does not silently fetch new websites or rewrite immutable raw captures.
Changed source hashes invalidate dependent claims and graph freshness.
An interrupted refresh preserves the old readable snapshot with stale status.

Provide linked Markdown instructions that open notes and source locators in Obsidian.
Expose provenance and graph coverage warnings in CLI output and exported research views.
Keep the advisory Graphify 0.9.61 graph separate from the existing 0.9.48-qualified graph.
This release does not upgrade that qualification by renaming an artifact.
Unknown syntax, dangling edges and unsupported extraction remain visible.
Store no hidden reasoning in the research bundle or vault export.

## Packaging, support and rollback

`PackageSupportV1` records the selected release name/version, candidate, runtime schemas and exact model/transport evidence.
Do not claim a transport works because its fixture suite passes.
Include documentation, examples and support matrix from the same candidate.
Retain unresolved v0.5 obligations and their source references in release notes.
Assign the numerical version only after the existing release program reconciles it.

`foreman support export --run <id> --out <bundle>` produces reproducible, redacted context.
Include installed version, platform, exact provider identities, safe error codes and relevant event IDs.
Exclude credentials, bearer tokens, environment secret values, hidden reasoning and sensitive prompt payloads.
Use existing redaction policy and test malicious field names and nested provider errors.

`foreman install rollback --to <installed-version>` checks journal and checkpoint schema compatibility before switching packages.
Restore a known compatible package atomically.
Leave execution history and profile evidence intact.
An incompatible active checkpoint returns `RollbackIncompatible`.
Offer the compatible current runtime's resume/export route rather than rewriting history.
Rollback must not resurrect a retired second scheduler.

## Planned validation

Use `npm run typecheck`, `npm run test`, `npm run build`, `npm run verify-runtime` and `npm run verify`.
Run the existing architecture policy and install checks where applicable.
The catalog's TypeScript tests are the targeted adoption suite.
Add `test:adoption` to invoke `scripts/run-tests.ts` with the exact `pel-*.test.ts` adoption targets.
Run clean-install tests against copied candidate archives and compiled Node.js product code.
They cannot depend on checkout-only modules or the external vault.

Assert all shipped examples execute through fake qualified profiles.
Assert unsupported examples fail before effects.
Assert one migration removes a complete legacy control path and all corpus outcomes remain equivalent.
Run measurement against the frozen baseline and report both raw counts and ratios.
Verify support export redaction and compatible/incompatible rollback.
Publication remains the existing separately authorized transaction after the working candidate satisfies its current release policy.
