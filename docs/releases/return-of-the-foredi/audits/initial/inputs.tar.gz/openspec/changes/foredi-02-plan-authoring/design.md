# Pel authoring design

## Product behavior

`foreman check workflow.pel` reports language and environment errors.
`foreman plan workflow.pel` displays the checked effects and remaining uncertainty.
Both commands accept `--json`.
Neither command executes the source program's host effects.

`foreman plan --prompt "Implement the approved change and request review" --model gpt-6-astra --transport openai-responses` explicitly requests generation.
Generation returns Pel source and its locally checked preview.
It does not start tasks, reserve execution resources, or publish changes.

The canonical artifact remains Pel source.
A preview is derived data bound to that source.
Operators cannot edit a preview into a new executable workflow.

This change depends on M1.
The provider port permits fixture-based implementation before M3 transports exist.
Live generation requires a qualified M3 model and transport.
M4 owns execution admission, effect conflicts, journal records, and durable revisions.

Requirements use [EARS](https://alistairmavin.com/ears/).

## Exact files

| Target | Responsibility |
| --- | --- |
| `packages/pel/src/checker.ts` | Scope, arity, literal types, profile validation |
| `packages/pel/src/analysis.ts` | Abstract values, reachable effects, dynamic regions |
| `packages/pel/src/preview.ts` | CheckedProgramV1 and PlanPreviewV1 derivation |
| `packages/pel/src/binding.ts` | Canonical hashes and binding validation |
| `packages/orchestration/src/pel-authoring-contract.ts` | CLI service ports and error unions |
| `packages/orchestration/src/pel-authoring-cli.ts` | check and plan argument handling |
| `packages/orchestration/src/pel-authoring-main.ts` | Node.js 24 entry and Effect resource scope |
| `packages/orchestration/src/pel-generation.ts` | Provider generation and capped local repair |
| `packages/orchestration/src/pel-draft-session.ts` | In-memory history, completion, and revision commands |
| `packages/providers/package.json`, `tsconfig.json`, `src/contract.ts` | Minimal generation-port package bootstrap, extended by M3 |
| `scripts/build-runtime.ts` | Bundle authoring entry as `dist/foreman.js` |
| Root `package.json` | Include explicit Pel test globs |
| `docs/reference/pel/authoring.md` | Command help and diagnostic examples |
| `examples/pel/{sequential,conditional,parallel,repair}.pel` | Useful native Pel programs |

Register the public `foreman` launcher through the existing installation mechanism.
Its adapter only locates Node.js 24, forwards exact arguments, and preserves streams and status.
The same bundle later accepts the M4 run, status, resume, and cancel subcommands.
Do not add another command parser for those operations.

## Service boundaries

Export `checkPel(input: CheckInputV1): CheckResultV1`.
Export `planPel(checked: CheckedProgramV1): PlanPreviewV1`.
These are ordinary deterministic TypeScript functions.
Their inputs include source bytes, M1 profile, immutable registry snapshot, provider profile snapshot, policy envelope, and artifact digests.
They import no filesystem, subprocess, network, credential, or live-provider service.

`CheckResultV1` is `ok` with checked program and warnings, or `invalid` with diagnostics.
The CLI adapter reads only explicitly selected source and snapshot files.
Read each file through a bounded Effect scope.
The CLI writes only stdout and stderr.
No default cache, history file, journal, lock, worktree, or reservation is created.
Network-free check and file-based plan do not perform auth probes or fetch missing artifacts.

`AuthoringSnapshotV1` contains languageProfileId, languageProfileDigest, registryDigest, providerProfilesDigest, policyDigest, artifactDigests, and source-independent finite limits.
Artifact digests use normalized artifact IDs and SHA-256.
The CLI accepts `--context path.json` for this existing host-data snapshot.
Without that flag, use the installed immutable default authoring snapshot.
This JSON carries host metadata, not control flow or a second task language.

Check source arguments before opening files.
Use exit 0 for a valid check or preview, 2 for source/capability/limit errors, 3 for input/environment errors, and 4 for exhausted generation.
For `--json`, write one versioned JSON object on stdout.
Human diagnostics go to stderr only when JSON mode is absent.
Argument misuse returns exit 2 with `PEL_CLI_USAGE`.

## Checking and pure interpretation

Validate identifiers in every executable syntax region.
Quoted syntax is data and does not require symbol resolution.
Resolve lexical scopes, fixed ArgSpec, default arguments, partial closures, and immutable definitions.
Check all statically known types before evaluation.
A dead branch can still contain a syntax, unknown-symbol, or argument-shape error.
Capabilities in a provably unselected valid branch do not count as reachable effects.

Abstract evaluation preserves the M1 native semantics.
Pure calls evaluate under the same fuel and value limits.
A host call yields an abstract result derived from its output schema.
That abstract value flows through native list lookup, pipes, closures, conditions, and loops.
Do not run the host function to improve a preview.

The abstract domain contains known data, schema-constrained unknown data, finite closure sets, and unknown values with origin spans.
Merge branch summaries conservatively.
A pure recursive computation stops at the shared fuel bound.
An unknown-length loop becomes a dynamic region with the admitted iteration bound.
Known oversized loops fail before any host descriptor is emitted.

## PlanPreviewV1

Fields are `schemaVersion: 1`, binding, finalValueSummary, effects, dependencies, dynamicRegions, diagnostics, and limits.
Effects contain nodeId, invocationPath or bounded region ID, registryId, argument summaries, exact model profile, transport, capability requirements, resource reads/writes, and applicable host gates.
An unknown field is tagged `unresolved` with a reason and source span.
Do not render unresolved fields as empty values or successful verification.

Dependency edges distinguish value dependencies from resource conflicts.
Display independent writes to the same worktree as a serialization constraint.
Unknown resources conflict with all writes in their permitted resource scope.
The preview describes constraints.
The M4 execution scope owns actual scheduling.

For `if` with an unknown condition, preserve both possible effect branches.
For `case`, show ordered candidate branches and predicate effects.
For `for`, retain iteration order and an aggregate upper bound.
For `do/async`, show dependency-ready work and resource serialization.
Do not claim a complete static graph for programs with provider-dependent control flow.

## Capabilities and bounded dynamic regions

Each registered descriptor declares required capability names and its output schema.
The installed snapshot supplies allowed capability IDs, exact model/transport pairs, resource scope, schema IDs, and finite effect/cost/time bounds.
The source cannot grant capabilities through keyword pairs or model-generated text.

A dynamic region contains:
- Stable region ID and source spans.
- Reason: unknown condition, unknown collection, unknown callable, or unknown argument.
- Possible registered function IDs and exact allowed model/transport pairs.
- Capability set and normalized read/write resource envelope.
- Maximum iterations, calls, output bytes, cost units, and elapsed milliseconds.
- Result schema and the host requirements that remain deferred.

A known host function with an unresolved argument can pass only when its envelope is finite and the argument is schema-constrained.
An unresolved callable must have a finite registered function set or finite known Pel closure set.
Reject arbitrary unknown callable values.
Unknown paths require a declared finite resource scope and host validation before dispatch.
A wildcard naming all registry functions is not a finite authoring declaration.
The checker rejects unsupported effect kinds, unknown registry IDs, forbidden capabilities, unsupported model/transport pairs, and absent bounds.

Use `PEL_CAPABILITY_DENIED`, `PEL_UNSUPPORTED_EFFECT`, `PEL_PROFILE_UNSUPPORTED`, `PEL_SCHEMA`, and `PEL_DYNAMIC_EFFECT_UNBOUNDED`.
Report the call span, requested value, and allowed alternatives from the snapshot.
Do not suggest a silently substituted model.
If every reachable effect fits its envelope, mark the preview `bounded-dynamic`.
This status permits a later admission check. It is not an authority grant.
M4 revalidates each actual resolved effect before reservation and dispatch.

## Source and environment binding

`CheckedProgramV1` contains original source bytes, sourceDigest, normalized AST, language profile, validated snapshot, bindingDigest, and analysis.
It is a process-local checked value, not an alternate authoring format.
`PlanBindingV1` contains sourceDigest, languageProfileDigest, registryDigest, providerProfilesDigest, policyDigest, and sorted artifactDigests.
Canonical JSON uses sorted object keys, preserves array order, rejects duplicate keys, and forbids undefined values.
Hash canonical UTF-8 bytes with SHA-256.
Changing any binding component requires a new preview.
Whitespace changes sourceDigest even if the normalized AST remains equivalent.
Provider-dependent branches do not remove the binding requirement.

An exported preview cannot provide trusted checked state.
M4 reads canonical Pel source and validates binding against its own current authority and environment.
A forged preview with edited capabilities fails binding validation.

## Generation and repair

M2 imports the M3 boundary `ProviderGenerationPort.generate(GenerationRequest): Effect<GenerationResponse, ProviderFailure>`.
M2 creates the minimal strict TypeScript providers package and generation-only contract exports.
Add its project reference and Effect dependency using the existing workspace conventions.
M3 extends these exports with adapter contracts and transport implementations.
Until M3 exists, contract tests use a local typed fixture port.
The interface remains the same.

`GenerationRequest` contains modelProfileId, transportId, prompt, registry catalog, output schema, grammar mode, finite limits, and attempt.
M3 maps modelProfileId to `ProviderRequestV1.profileId` without changing identity.
`GenerationResponse` contains pelSource, exact observed profile and transport identities, provider request ID, and usage.
`ProviderFailure` initially exports the generation categories auth, timeout, cancelled, refused, identity-mismatch, unavailable-model, malformed-output, and transport.
Each failure carries a message, optional request ID, and available usage.
M3 extends the shared typed union for its additional operations.
Export `generatePelPlan(request: GenerationRequest, snapshot: AuthoringSnapshotV1): Effect<GeneratedPlanV1, PelGenerationFailure, ProviderGenerationPort>`.
`GeneratedPlanV1` contains pelSource, preview, attempt count, provider identities, and cumulative usage.
`PelGenerationFailure` contains a stable code, bounded per-attempt diagnostics, cumulative usage, and an optional typed provider cause.
The output envelope is exactly `{pelSource: string}`.
Reject extra fields, missing source, non-string source, and more than 1 MiB of source.
Catalog descriptions and artifact text are untrusted prompt data.
The trusted request selects capabilities and limits separately.

Use provider grammar constraints only if the chosen profile explicitly supports that endpoint's mechanism.
Otherwise request the structured source envelope and perform local parsing.
A JSON string does not constrain the grammar inside it.
Unknown constraint support uses envelope mode.
A requested mandatory grammar mode on an unsupported profile fails with `PEL_PROFILE_UNSUPPORTED`.

The loop performs attempt 0 plus repair attempts 1 and 2.
Each call has a 60-second timeout.
The whole operation has a 180-second deadline and the host-supplied finite token and cost budget.
A call cannot begin if its reservation exceeds the remaining generation budget.
Timeout, cancellation, auth failure, identity mismatch, refusal, or unavailable model stops the loop without a syntax repair.
Local lexical, parse, schema, capability, or boundedness failures can request a repair.

Each repair receives the previous source, local diagnostic codes and spans, applicable signatures, and the same immutable capability snapshot.
It cannot expand capabilities, change the exact model, or reset limits.
Accept the first source that passes local check and preview.
After three locally invalid responses, return `PEL_GENERATION_EXHAUSTED` with all three diagnostic sets and bounded source samples.
Return exit 4.
Do not return an accepted plan or dispatch any generated operation.
Usage for all attempts remains visible.

The prompt operation owns one Effect scope for cancellation, provider resources, timeouts, and counters.
File-based check and plan never invoke this port.
Default generation output writes only exact Pel source to stdout.
The preview and human diagnostics go to stderr.
The operator can redirect stdout directly to a Pel file.
With `--json`, stdout instead contains one `GeneratedPlanV1` object and stderr contains no preview text.

## Interactive draft correction

`foreman plan workflow.pel --interactive` opens an in-memory draft session.
It provides source-span highlighting, immutable-registry symbol completion, and command history.
The terminal interface owns its readline resources through Effect.
No history or source file is written automatically.

Commands are `show`, `check`, `preview`, `history`, `undo`, `replace-expression <node-id>`, `replace-suffix <node-id>`, `replace-program`, `repair`, `export`, and `abort`.
Replacement commands read a Pel fragment terminated by a line containing only `.end`.
Reject a fragment above the source limit.
Expression replacement requires exactly one parsed expression.
Suffix replacement starts at a top-level expression.
Every replacement creates a new draft source digest and runs local checking.
Undo restores a prior draft without executing its source.
Export writes exact current source to stdout.

The explicit `repair` command uses the same bounded generation service.
It requires a selected exact model and transport.
The UI displays provider use before starting that requested operation.
Pure commands cannot invoke it implicitly.
The session keeps at most 100 source revisions and at most 16 MiB of revision bytes.
Before exceeding either bound, discard the oldest revision.
Retain the current revision and show the oldest available revision number.

These commands implement the paper's authoring restart choices and editor conveniences.
They affect unexecuted drafts.
M4 owns recovery from a running program, completed receipts, and authorized durable revisions.
The UI returns `PEL_DRAFT_EXECUTED` if passed a run-bound continuation.

## Useful examples

Create four examples with the same registry fixtures used by acceptance tests.
The sequential example uses the release's ordinary host function calls:

```lisp
(fm/task :id "implement" :model "grok-4.6"
  :input "artifact:approved-spec" :output "schema:candidate-v1")
^> (fm/verify :id "verify" :input ^ :gate "candidate-full")
^> (fm/review :id "review" :model "gpt-5.6-sol"
  :input ^ :policy "independent-review")
```

The conditional example looks up a Boolean host result through a callable list:

```lisp
(def result (fm/verify :id "verify" :input "artifact:c1" :gate "candidate-full"))
(if (result :at ':passed)
  (fm/review :id "review" :model "gpt-5.6-sol"
    :input result :policy "independent-review")
  [:status "verification-failed"])
```

The parallel example uses `do/async` with two distinct admitted resource scopes.
The repair example demonstrates a mixed-argument diagnostic and a corrected named call.
Document exact expected human and JSON output for each fixture.
Examples use source, values, and native control flow without a separate task DSL.

## Planned validation

Run `npm run typecheck`.
Compile Pel tests with `npx tsc -p packages/pel/tsconfig.test.json`.
Run `node --test packages/pel/dist-test/test/{checker,analysis,preview,binding}.test.js`.
Compile authoring tests with `npx esbuild packages/orchestration/src/{pel-authoring-cli,pel-generation,pel-draft-session}.test.ts --bundle --platform=node --format=esm --target=node24 --outdir=packages/orchestration/dist-pel-test`.
Run `node --test packages/orchestration/dist-pel-test/{pel-authoring-cli,pel-generation,pel-draft-session}.test.js`.
The preceding workspace typecheck checks these test sources before bundling.
Build the CLI with `npm run build`.
Run `node skills/foreman/runtime/dist/foreman.js plan examples/pel/sequential.pel --context packages/pel/test/fixtures/authoring-snapshot.json --json`.
Tests deny provider, network, subprocess, write, and reservation services in file-based check and plan.
The catalog defines observable assertions. These commands have not run for implementation in this drafting change.
