# M1 implementation tasks

All checkboxes describe future work. Test files and commands are planned.

## F-M1-01 Published grammar and source locations

- [ ] Create the strict TypeScript package configuration and workspace references.
- [ ] Add `packages/pel/test/**/*.test.ts` to the root test command's explicit globs.
- [ ] Implement tokenizer spans and lexical errors in `packages/pel/src/tokenizer.ts`.
- [ ] Implement AST parsing and quote rules in `packages/pel/src/parser.ts`.
- [ ] Add the R-M1-001 and R-M1-002 fixtures in `packages/pel/test/syntax.test.ts`.

## F-M1-02 Values and callable lists

- [ ] Implement value tags and canonical formatting in `packages/pel/src/values.ts`.
- [ ] Implement pair formation and callable-list lookup in `packages/pel/src/builtins.ts`.
- [ ] Add the R-M1-003 and R-M1-004 fixtures in `packages/pel/test/values.test.ts`.
- [ ] Write the paper-linked errata table in `docs/reference/pel/compatibility.md`.

## F-M1-03 Closures and argument binding

- [ ] Implement immutable lexical environments and closures in `packages/pel/src/evaluator.ts`.
- [ ] Implement defaults and partial argument binding in `packages/pel/src/arguments.ts`.
- [ ] Implement fixed pure builtin signatures in `packages/pel/src/builtins.ts`.
- [ ] Add the R-M1-005 and R-M1-006 fixtures in `packages/pel/test/closures.test.ts`.

## F-M1-04 Pipes and native control flow

- [ ] Implement recursive pipe insertion in `packages/pel/src/evaluator.ts`.
- [ ] Implement non-strict if, case, for, do, and do/async in `packages/pel/src/builtins.ts`.
- [ ] Implement dependency analysis in `packages/pel/src/dependencies.ts`.
- [ ] Add the R-M1-007 through R-M1-009 fixtures in `packages/pel/test/control.test.ts`.

## F-M1-05 Diagnostics and evaluation limits

- [ ] Implement structured source diagnostics in `packages/pel/src/diagnostics.ts`.
- [ ] Implement counters and pre-reduction limit checks in `packages/pel/src/evaluator.ts`.
- [ ] Add the R-M1-010 and R-M1-011 fixtures in `packages/pel/test/limits.test.ts`.

## F-M1-06 Host suspension and recovery data

- [ ] Define host descriptors, requests, and receipts in `packages/pel/src/host-contract.ts`.
- [ ] Implement suspension and validated resume in `packages/pel/src/evaluator.ts`.
- [ ] Implement child closure evaluation and counter merging in `packages/pel/src/evaluator.ts`.
- [ ] Implement data-only continuation encoding in `packages/pel/src/continuation.ts`.
- [ ] Add the R-M1-012 through R-M1-014 fixtures in `packages/pel/test/host-contract.test.ts`.
- [ ] Document host extension and REPeL ownership in `docs/reference/pel/extensions.md`.

## Validation

- [ ] Run `npm run typecheck` and confirm zero TypeScript errors.
- [ ] Run `npx tsc -p packages/pel/tsconfig.test.json` and confirm compilation succeeds.
- [ ] Run `node --test packages/pel/dist-test/test/*.test.js` and confirm every catalog assertion passes.
- [ ] Run `openspec validate foredi-01-pel-language --strict` and confirm no validation errors.
