# M4 implementation tasks

Status: planned. No implementation checkbox or runtime test is complete.
Use strict TypeScript on Node.js 24. Keep Effect resource and error ownership inside `packages/orchestration`.

## 1. F-M4-01: Start and inspect a durable run

- [ ] 1.1 Add `pel-run-contract.ts` with strict execution binding, run status, result, and failure decoders.
- [ ] 1.2 Add `pel-runner.ts` using the existing supervisor lease and one Effect scope per admitted run.
- [ ] 1.3 Extend M2 `pel-authoring-cli.ts` and `pel-authoring-main.ts` with lifecycle arguments and documented exit codes.
- [ ] 1.4 Revalidate each resolved M1 host request against M2 envelopes before reserving it.
- [ ] 1.5 Implement T-M4-001 and T-M4-002 in `pel-runner.test.ts` and `pel-effects.test.ts`.
- [ ] 1.6 Run `npx tsx scripts/run-tests.ts "packages/orchestration/src/pel-runner.test.ts" "packages/orchestration/src/pel-effects.test.ts"`.

Assert one owner, one dispatch, exact authority binding, and zero reservation for denied dynamic effects.

## 2. F-M4-02: Resume recorded host results

- [ ] 2.1 Add `pel-journal.ts` record decoders inside the existing stored-event payload envelope.
- [ ] 2.2 Bind evaluator request IDs to durable effect IDs with attempt and retry ordinals.
- [ ] 2.3 Adapt `EndstopLedger` reservation keys without introducing another accounting owner.
- [ ] 2.4 Record intent before dispatch and validated results before evaluator continuation.
- [ ] 2.5 Implement reservation-without-intent recovery and identical receipt deduplication.
- [ ] 2.6 Implement T-M4-003 through T-M4-005 with all six interruption fixtures.
- [ ] 2.7 Run `npx tsx scripts/run-tests.ts "packages/orchestration/src/pel-journal.test.ts" "packages/orchestration/src/pel-recovery.test.ts"`.

Assert exact Pel value replay, unchanged budgets, unknown outcome classification, and conflicting receipt rejection.

## 3. F-M4-03: Execute bounded native concurrency

- [ ] 3.1 Add `pel-resource-scope.ts` with canonical resource sets, deterministic acquisition order, and scoped permits.
- [ ] 3.2 Dispatch eligible requests from M1 native `do/async` batches within M2 dependency and resource envelopes.
- [ ] 3.3 Add `fm/race` registration and isolated closure execution to `pel-control-functions.ts`.
- [ ] 3.4 Persist winner selection before exposing its result and clean up losing scopes.
- [ ] 3.5 Implement T-M4-006 through T-M4-008 with resource barriers and observed cancellation fixtures.
- [ ] 3.6 Run `npx tsx scripts/run-tests.ts "packages/orchestration/src/pel-resource-scope.test.ts" "packages/orchestration/src/pel-control-functions.test.ts"`.

Assert source-result semantics, maximum concurrency, alias conflict serialization, isolated race artifacts, and truthful loser outcomes.

## 4. F-M4-04: Control retries and timeouts

- [ ] 4.1 Implement `fm/retry` with typed transient categories and existing persistent action limits.
- [ ] 4.2 Link each retry ordinal to its parent effect and its original cost and deadline budget.
- [ ] 4.3 Apply scoped timeouts through the existing launcher and M3 cancellation observations.
- [ ] 4.4 Make duplicate operator cancellation requests idempotent in `pel-journal.ts`.
- [ ] 4.5 Implement T-M4-009 through T-M4-011 with clocks, provider observations, and restart fixtures.
- [ ] 4.6 Run `npx tsx scripts/run-tests.ts "packages/orchestration/src/pel-control-functions.test.ts" "packages/orchestration/src/pel-runner.test.ts" "packages/orchestration/src/pel-authoring-cli.test.ts"`.

Assert spent retry preservation, nonretryable authentication failure, local cleanup, pending exit 5, and confirmed-cancelled exit 4.

## 5. F-M4-05: Recover unknown outcomes and revisions

- [ ] 5.1 Implement `fm/checkpoint` with M1 data-only continuation and protected provider artifact references.
- [ ] 5.2 Add `pel-recovery.ts` compatibility, current-attempt, lease, and completed-prefix validation.
- [ ] 5.3 Decode `PelRecoveryDecisionV1` and bind each explicit decision to its effect and authority evidence.
- [ ] 5.4 Implement observation-based reconciliation through M3 existing provider identities without redispatch.
- [ ] 5.5 Implement source revision records that retain original authority, counters, and completed effects.
- [ ] 5.6 Route Pel supervisor and resume-queue paths into `resumeProgram`, preserving legacy decoders.
- [ ] 5.7 Implement T-M4-012 through T-M4-014 and T-M4-016 in `pel-recovery.test.ts`.
- [ ] 5.8 Run `npx tsx scripts/run-tests.ts "packages/orchestration/src/pel-recovery.test.ts" "packages/orchestration/src/resume-decision.test.ts" "packages/orchestration/src/resume-queue-execution.test.ts"`.

Assert closure capture recovery, no duplicate completed effect, refusal of altered prefixes, and unchanged terminal budgets.

## 6. F-M4-06: Explain run outcomes

- [ ] 6.1 Project status and results from the journal with source spans, evidence references, and conservative usage bounds.
- [ ] 6.2 Render text and JSON through the same result decoder in `pel-authoring-cli.ts`.
- [ ] 6.3 Implement T-M4-015 with provider calls forbidden during status reads.
- [ ] 6.4 Run `npx tsx scripts/run-tests.ts "packages/orchestration/src/pel-authoring-cli.test.ts"`.
- [ ] 6.5 Run `npm run typecheck` and `npm run build`.
- [ ] 6.6 Run compiled lifecycle fixtures through `node skills/foreman/runtime/dist/foreman.js`.
- [ ] 6.7 Run `npm run verify` and inspect existing journal, ledger, terminal policy, launcher, and resume results.

Assert status and result agreement, readable next actions, correct lifecycle exit codes, and zero secret disclosure.
Record actual commands and results during implementation. Do not mark planned catalog tests as historical evidence.
