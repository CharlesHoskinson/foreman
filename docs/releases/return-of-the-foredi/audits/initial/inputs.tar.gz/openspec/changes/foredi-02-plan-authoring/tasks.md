# M2 implementation tasks

All checkboxes describe future implementation. Tests and commands are planned.

## F-M2-01 Source checking

- [ ] Implement scope and argument checking in `packages/pel/src/checker.ts`.
- [ ] Define typed authoring inputs and errors in `packages/orchestration/src/pel-authoring-contract.ts`.
- [ ] Implement check argument handling in `packages/orchestration/src/pel-authoring-cli.ts`.
- [ ] Add R-M2-001 and R-M2-002 fixtures in the catalog test targets.

## F-M2-02 Pure effect previews

- [ ] Implement abstract Pel values in `packages/pel/src/analysis.ts`.
- [ ] Implement PlanPreviewV1 rendering in `packages/pel/src/preview.ts`.
- [ ] Add R-M2-003 and R-M2-004 fixtures in the catalog test targets.

## F-M2-03 Capability and dynamic-region analysis

- [ ] Implement descriptor and capability checks in `packages/pel/src/analysis.ts`.
- [ ] Implement finite dynamic-region envelopes in `packages/pel/src/analysis.ts`.
- [ ] Add R-M2-005 and R-M2-006 fixtures in the catalog test targets.

## F-M2-04 Exact preview binding

- [ ] Implement PlanBindingV1 hashing in `packages/pel/src/binding.ts`.
- [ ] Reject mismatched imported bindings in `packages/pel/src/binding.ts`.
- [ ] Add the R-M2-007 fixture in `packages/pel/test/binding.test.ts`.

## F-M2-05 Bounded natural-language generation

- [ ] Define the shared generation port contract in coordination with M3.
- [ ] Create the minimal providers package metadata, TypeScript configuration, and generation-only contract exports.
- [ ] Add the providers project reference and Effect dependency to the workspace.
- [ ] Implement the generation loop in `packages/orchestration/src/pel-generation.ts`.
- [ ] Implement attempt timeouts and aggregate limits through Effect.
- [ ] Add R-M2-008 through R-M2-010 fixtures in `packages/orchestration/src/pel-generation.test.ts`.
- [ ] Wire explicit prompt generation into the plan command.

## F-M2-06 Operator diagnostics and draft editing

- [ ] Implement source context and registry-backed help in the authoring CLI.
- [ ] Implement draft revision commands in `packages/orchestration/src/pel-draft-session.ts`.
- [ ] Implement in-memory history, completion, and bounded revision storage.
- [ ] Add R-M2-011 through R-M2-013 fixtures in the catalog test targets.
- [ ] Write the four Pel examples and `docs/reference/pel/authoring.md`.
- [ ] Add the Node.js authoring entry to `scripts/build-runtime.ts`.
- [ ] Register the public foreman launcher through the existing installation mechanism.
- [ ] Add Pel tests to the explicit root test globs.
- [ ] Add the compiled authoring test bundle command from design.md to package test scripts.

## Validation

- [ ] Run `npm run typecheck` and confirm zero errors.
- [ ] Compile Pel tests and bundle authoring tests with the commands listed in design.md.
- [ ] Run the compiled Node.js 24 test commands listed in design.md.
- [ ] Build the runtime and confirm the sequential example produces the catalog preview.
- [ ] Run `openspec validate foredi-02-plan-authoring --strict` and confirm no validation errors.
