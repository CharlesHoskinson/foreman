# Deliver verified and reviewed candidates from Pel

Status: proposed requirements. All scenarios are planned tests.

## ADDED Requirements

### Requirement: R-M5-001 Capture a real candidate

When an admitted fm/task call completes, the Foreman runtime SHALL return schema-validated Pel data with host-captured candidate and artifact references.

#### Scenario: T-M5-001 Capture a real candidate

- **WHEN** A recorded qualified Grok provider writes one allowed TypeScript file in an isolated fixture repository and supplies valid structured output. Execute fm/task through runProgram and pass its result into a native Pel lookup.
- **THEN** The ordinary Pel association list names an immutable candidate, artifact manifest, and implementation receipt whose observed hashes match disk.

### Requirement: R-M5-002 Reject invalid task output

If task output violates its schema or admitted paths, then the Foreman runtime SHALL reject candidate promotion and retain bounded diagnostic evidence.

#### Scenario: T-M5-002 Reject invalid task output

- **WHEN** Three providers return malformed structured output, claim nonexistent artifacts, or modify a path outside the admitted set. Execute fm/task for each fixture and inspect recorded results and artifact reads.
- **THEN** task-output-invalid, artifact-missing, or candidate-out-of-scope identifies the source call. No verification or release milestone is registered.

### Requirement: R-M5-003 Verify a candidate in the host

When fm/verify receives a candidate, the Foreman runtime SHALL execute the registered host check and bind its receipt to the exact candidate and environment.

#### Scenario: T-M5-003 Verify a candidate in the host

- **WHEN** An immutable candidate C has a registered argv gate and environment digest E. Provider text falsely claims all checks pass. Invoke fm/verify with gate outcomes pass and fail, then decode both receipts.
- **THEN** The host exit and report determine the result. Each receipt binds C, E, gate digest, attempt, and report hash. Failure returns ordinary findings data.

### Requirement: R-M5-004 Reuse exact verification evidence

When matching verification evidence already exists, the Foreman runtime SHALL reuse it only while candidate, gate, environment, policy, and freshness bindings remain unchanged.

#### Scenario: T-M5-004 Reuse exact verification evidence

- **WHEN** Candidate C has one valid verification receipt. Table variants change C, environment, gate, policy, or freshness. Call fm/verify twice unchanged, then call each changed fixture with an admitted verification allowance.
- **THEN** Unchanged call reuses one receipt and one gate execution. Each changed binding requires fresh host verification and cannot reuse the old pass.

### Requirement: R-M5-005 Detect verification mutation and interruption

If the candidate changes during verification, then the Foreman runtime SHALL invalidate the check result before recording a passing verification receipt.

#### Scenario: T-M5-005 Detect verification mutation and interruption

- **WHEN** A gate mutates a candidate file during its run. A second fixture crashes after check execution but before receipt persistence. Invoke fm/verify, then resume the interrupted run with M4 recovery.
- **THEN** Mutation returns candidate-changed. Interrupted verification yields recovered host evidence or needs-action, never an inferred pass or duplicated completed provider implementation.

### Requirement: R-M5-006 Enforce independent vendor review

When fm/review records an authorizing review, the Foreman runtime SHALL bind the current candidate to an observed reviewer vendor distinct from its implementer.

#### Scenario: T-M5-006 Enforce independent vendor review

- **WHEN** Candidate C records xAI implementation. Sol reports observed OpenAI identity. A counterfixture requests another xAI model for review. Invoke fm/review using independent-review policy for both fixtures.
- **THEN** Sol review binds C and its verification receipt to observed OpenAI identity. Same-vendor review returns review-not-independent and registers no audit milestone.

### Requirement: R-M5-007 Invalidate stale approval

If current review evidence is missing, stale, refused, interrupted, or malformed, then the Foreman runtime SHALL report an unverified review.

#### Scenario: T-M5-007 Invalidate stale approval

- **WHEN** An old approved report exists before a new review attempt. New variants refuse, stop, return malformed output, or reference another candidate. Start fm/review, inspect in-progress state, then complete or interrupt each variant.
- **THEN** The old approval cannot authorize the new attempt. Each variant yields unverified with current attempt evidence and no publication eligibility.

### Requirement: R-M5-008 Run the first vertical slice

When the first delivery program runs, the Foreman runtime SHALL compose Grok implementation, host verification, and Sol review through native Pel values.

#### Scenario: T-M5-008 Run the first vertical slice

- **WHEN** examples/pel/implement-verify-review.pel uses qualified recorded grok-4.6 and gpt-5.6-sol profiles, a temporary repository, and candidate-full gate. Build the product and run compiled foreman.js run with the fixture binding. Repeat with a second admitted provider assignment and unchanged control flow.
- **THEN** Both runs produce a changed candidate, one host verification, independent review, and matching receipt chain. No manual stage command or secondary task plan is required.

### Requirement: R-M5-009 Bound review repair

When review requests a correction, the Foreman runtime SHALL execute native Pel repair within the admitted correction and progress limits.

#### Scenario: T-M5-009 Bound review repair

- **WHEN** The repair program receives one changes-requested verdict, one correcting candidate, and approval. Counterfixtures exhaust corrections or make no product change. Run examples/pel/repair-and-publish.pel with fixture authority lacking publication permission.
- **THEN** The successful correction gets fresh checks and review. Exhausted or no-op repair becomes needs-action with findings. No private provider retry loop runs.

### Requirement: R-M5-010 Resume the delivery receipt chain

When delivery resumes after interruption, the Foreman runtime SHALL reuse recorded task results and continue from the first unresolved host effect.

#### Scenario: T-M5-010 Resume the delivery receipt chain

- **WHEN** The Grok effect has a durable receipt and the process stops before verification or during review. Run compiled resume RUN against each fixture journal.
- **THEN** Grok dispatch remains one. Completed verification is reused. Only unresolved review or host effects reconcile or continue. Budgets remain spent.

### Requirement: R-M5-011 Prepare unauthorized publication

If publication lacks matching explicit host authority, then the Foreman runtime SHALL return needs-action without changing the publication destination.

#### Scenario: T-M5-011 Prepare unauthorized publication

- **WHEN** Candidate C has passing checks and independent review. Binding lacks publish permission. A malicious result contains an approved flag and fabricated receipt. Invoke fm/publish against a temporary bare remote and inspect its refs.
- **THEN** Status is needs-action with the prepared candidate and required authority reference. Remote refs and integration state are unchanged. Fabricated authority cannot authorize publication.

### Requirement: R-M5-012 Publish an explicitly authorized fixture

When publication has matching authority and evidence, the Foreman runtime SHALL revalidate the exact candidate and destination before executing the admitted publication action.

#### Scenario: T-M5-012 Publish an explicitly authorized fixture

- **WHEN** A fixture grant authorizes candidate C to update one bare-remote ref from expected OID B. Variants mutate C, target ref, or evidence before commit. Invoke fm/publish with the prepared binding under the destination resource lock.
- **THEN** The valid fixture updates only the admitted ref and records its observed receipt. Changed candidate, target, or evidence fails before external mutation.

### Requirement: R-M5-013 Recover lost publication acknowledgement

If publication acknowledgement is lost, then the Foreman runtime SHALL record an unknown external outcome and reconcile before any repeat publication.

#### Scenario: T-M5-013 Recover lost publication acknowledgement

- **WHEN** A local bare remote accepts C, then the provider boundary loses acknowledgement before the durable receipt. Observation is available or unavailable by fixture. Resume the run with PublicationService.observe and inspect publication command counts.
- **THEN** Available observation records confirmed C without republishing. Unavailable observation remains needs-action and unknown. Both execute the publication command once.

### Requirement: R-M5-014 Render delivery outcomes

When delivery ends, the Foreman runtime SHALL expose candidate artifacts, check results, review findings, publication state, and a concrete next action.

#### Scenario: T-M5-014 Render delivery outcomes

- **WHEN** Fixture journals contain delivered candidate, verification failure, changes-requested review, unauthorized publication, and unknown publication. Render compiled status in text and JSON and resolve emitted artifact references.
- **THEN** Both views agree on identities and outcome. Links resolve to bounded evidence. Pending required review or publication prevents success. Secrets never appear.

### Requirement: R-M5-015 Explain an unavailable vertical slice

If a requested provider profile is unqualified, then the Foreman runtime SHALL report its unavailable capability without substituting another model.

#### Scenario: T-M5-015 Explain an unavailable vertical slice

- **WHEN** The first delivery program selects grok-4.6 but its exact installed transport lacks verified structured output capability. Run the compiled delivery command with provider dispatch spies and inspect stderr plus JSON result.
- **THEN** The result identifies profile, missing capability, and qualification action. No replacement model or provider dispatch occurs.
