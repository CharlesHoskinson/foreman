# Execute and recover Pel programs

Status: proposed requirements. All scenarios are planned tests.

## ADDED Requirements

### Requirement: R-M4-001 Start an admitted run

When an admitted run starts, the Foreman runtime SHALL bind one exclusive Effect owner to its checked program and execution contract.

#### Scenario: T-M4-001 Start an admitted run

- **WHEN** A checked deterministic host program and matching ExecutionBindingV1 in a temporary state root. Run the compiled foreman.js run fixture.pel --binding binding.json --state-root DIR --json command twice concurrently.
- **THEN** One owner dispatches the host effect once. The other returns owner-busy. The stored binding matches program, attempt, and authority.

### Requirement: R-M4-002 Reject a dynamic capability escape

If a resolved host request exceeds its checked envelope, then the Foreman runtime SHALL reject that request before reservation or dispatch.

#### Scenario: T-M4-002 Reject a dynamic capability escape

- **WHEN** A checked conditional returns a write path outside its admitted worktree after a recorded provider result. Resume the evaluator and inspect ledger and provider invocation spies.
- **THEN** capability-denied or resource-denied names the source span. No action reservation or provider call exists for the rejected effect.

### Requirement: R-M4-003 Persist and replay a host result

When a host call suspends evaluation, the Foreman runtime SHALL persist its bound intent before dispatch and its validated result before continuation.

#### Scenario: T-M4-003 Persist and replay a host result

- **WHEN** A host result is an association list. Fault injection stops the process immediately after result append. Execute, restart from the same journal, and evaluate the next native pipe expression.
- **THEN** Journal order is reservation reference, intent, observation, result. Resume returns the identical Pel value. The completed host dispatch count stays one.

### Requirement: R-M4-004 Cover six interruption boundaries

If execution stops between reservation and result persistence, then the Foreman runtime SHALL recover its existing reservation and classify the external outcome.

#### Scenario: T-M4-004 Cover six interruption boundaries

- **WHEN** Table fixtures stop before reservation, after reservation, after dispatch without provider ID, after external completion, during fake verification, and during cleanup. For each fixture run resumeProgram with observed-complete, confirmed-no-dispatch, or unavailable provider reconciliation.
- **THEN** Budgets never increase. No completed receipt is re-executed. Missing external evidence yields needs-action with unknown outcome, including missing provider identity.

### Requirement: R-M4-005 Reject conflicting receipts

If duplicate result receipts conflict, then the Foreman runtime SHALL reject recovery with journal-corrupt and preserve the conflicting evidence.

#### Scenario: T-M4-005 Reject conflicting receipts

- **WHEN** One journal repeats an identical result. Another repeats its effect identity with a different canonical result hash. Call replayPelRun on both journals.
- **THEN** Identical delivery yields one result. Conflicting delivery returns journal-corrupt before continuation or provider dispatch.

### Requirement: R-M4-006 Schedule native expressions

When native do or do/async evaluates host expressions, the Foreman runtime SHALL preserve Pel result semantics within admitted concurrency and resource limits.

#### Scenario: T-M4-006 Schedule native expressions

- **WHEN** Source order contains three do/async expressions with completion barriers in reverse order and a concurrency limit of two. A second program uses do. Evaluate both programs with the instrumented host registry.
- **THEN** do dispatches in source order. do/async never exceeds two active effects and returns the last source expression result despite reverse completion.

### Requirement: R-M4-007 Serialize independent symbol writes

While host requests have overlapping write resources, the Foreman runtime SHALL serialize those requests under the same canonical resource identity.

#### Scenario: T-M4-007 Serialize independent symbol writes

- **WHEN** Independent symbols write one worktree through its real path and a symlink alias. Additional requests declare read/read and unknown resources. Evaluate native do/async and record acquisition intervals.
- **THEN** Conflicting writes and unknown workspace effects never overlap. Independent reads can overlap. All permits release after failure.

### Requirement: R-M4-008 Race isolated contenders

When fm/race selects a winner, the Foreman runtime SHALL preserve isolated contender artifacts and record one winner with truthful loser cancellation.

#### Scenario: T-M4-008 Race isolated contenders

- **WHEN** Two isolated task closures complete on the same clock tick. One losing transport reports cancellation unknown. A negative fixture shares writable resources. Invoke fm/race with first-valid winner policy and inspect resource, journal, and provider events.
- **THEN** Source order selects the tied eligible winner. Loser artifacts cannot become winner inputs. Unknown cancellation stays visible. Shared worktree race rejects before dispatch.

### Requirement: R-M4-009 Bound retries across restarts

When fm/retry receives a declared transient failure, the Foreman runtime SHALL reserve each retry within the original action, cost, and deadline limits.

#### Scenario: T-M4-009 Bound retries across restarts

- **WHEN** A provider emits rate-limit twice, then success. Limits permit one retry. A second fixture reports authentication failure. Run fm/retry :attempts 3, restart after the first retry reservation, and inspect dispatch counts.
- **THEN** Exactly two calls occur for the rate-limit fixture and budget-exhausted ends it. Authentication failure receives zero retries. Restart retains deadline and spent reservations.

### Requirement: R-M4-010 Timeout without inventing remote cancellation

When an effect timeout expires, the Foreman runtime SHALL interrupt local work and record the observed remote cancellation state.

#### Scenario: T-M4-010 Timeout without inventing remote cancellation

- **WHEN** A scoped child process stalls. Its provider accepts cancellation but reports no terminal outcome. Advance the injected clock beyond the admitted timeout and await local cleanup.
- **THEN** Local process resources close. State remains cancel-requested or needs-action with unknown external outcome. Usage remains conservatively reserved.

### Requirement: R-M4-011 Cancel a running provider

When an operator requests cancellation, the Foreman runtime SHALL persist an idempotent request and report cancelled only after required cancellation confirmation.

#### Scenario: T-M4-011 Cancel a running provider

- **WHEN** A running provider yields requested, acknowledged, then confirmed-cancelled observations under controlled barriers. Invoke compiled cancel twice, then status before and after terminal confirmation.
- **THEN** One cancellation intent exists. Pending calls exit 5 with cancel-requested. Confirmed cleanup and terminal cancellation produce cancelled with exit 4.

### Requirement: R-M4-012 Resume a checkpoint with lexical values

When fm/checkpoint completes, the Foreman runtime SHALL record a versioned data-only continuation bound to its program, attempt, and consumed limits.

#### Scenario: T-M4-012 Resume a checkpoint with lexical values

- **WHEN** A closure captures a list, completes one host effect, checkpoints, and stops before the next expression. Decode the stored checkpoint and call resumeProgram using the same runtime and profile.
- **THEN** The list and closure capture survive as AST/environment data. Prior receipts replay without calls. All budget counters match their previous values.

### Requirement: R-M4-013 Reconcile a lost external result

If an external outcome remains unknown, then the Foreman runtime SHALL require bound reconciliation evidence before continuing or repeating that effect.

#### Scenario: T-M4-013 Reconcile a lost external result

- **WHEN** Provider completion occurs before receipt append. Its identity can be observed in one fixture and remains unavailable in another. Resume both fixtures, then submit a PelRecoveryDecisionV1 for the unavailable fixture with matching and mismatching effect digests.
- **THEN** Observed completion records one receipt. Unavailable outcome stays needs-action without redispatch. A mismatched decision fails. Valid evidence resolves only its bound effect.

### Requirement: R-M4-014 Validate revised source

When an operator submits a source revision, the Foreman runtime SHALL preserve the completed prefix, authority, and consumed limits before resuming.

#### Scenario: T-M4-014 Validate revised source

- **WHEN** A completed-prefix checkpoint has one pending expression. Revisions either change only that expression or alter a completed call, authority, or budget. Run compiled resume RUN --revision revised.pel --decision revision.json against each fixture.
- **THEN** The valid revision records parent and completed-prefix digests. Each altered binding fails before dispatch. Terminal runs cannot restart their spent budget.

### Requirement: R-M4-015 Render truthful status

When an operator requests run status, the Foreman runtime SHALL derive outcome, evidence, usage bounds, and next action from the existing journal.

#### Scenario: T-M4-015 Render truthful status

- **WHEN** Journals represent succeeded, failed, cancelled, pending cancellation, and unknown remote outcome with unknown final cost. Run compiled status RUN --state-root DIR --json and text mode with provider calls forbidden.
- **THEN** Views agree on state, effect ID, source span, receipt paths, reserved usage, and next action. Unknown fields remain unknown. No provider call occurs.

### Requirement: R-M4-016 Refuse invalid recovery

If recovery history is corrupt, incompatible, or owned by another active process, then the Foreman runtime SHALL refuse continuation with an actionable diagnostic.

#### Scenario: T-M4-016 Refuse invalid recovery

- **WHEN** Fixtures contain unordered sequence, wrong attempt, changed runtime profile, incompatible continuation, and live foreign owner lease. Call resumeProgram for each fixture and collect result diagnostics.
- **THEN** Each fails before host dispatch with journal-corrupt, binding-mismatch, continuation-incompatible, or owner-busy and a source or evidence reference.
