# Exact model profiles and shared provider adapters

All scenarios are planned tests. This change records no runtime qualification or measured release completion.

## ADDED Requirements

### Requirement: R-M3-001 Six exact profile identities

The Foreman provider registry SHALL define the six exact model profiles and four provider families listed in the design.

#### Scenario: T-M3-001 Six exact profile identities

- WHEN the following fixture is prepared: Six-profile registry fixture and an unrecognized model alias.
- AND the test performs: resolveProfile for every declared ID and the alias.
- THEN Exactly six profiles map to xai, anthropic, openai or google. The alias returns ModelUnavailable without dispatch.

### Requirement: R-M3-002 Model-specific reasoning validation

If requested reasoning controls violate a model profile, then the Foreman provider adapter SHALL return UnsupportedCapability before transport dispatch.

#### Scenario: T-M3-002 Model-specific reasoning validation

- WHEN the following fixture is prepared: Grok max, Astra none, Gemini minimal, Fable thinking disabled, Fable manual budget, Fable forced tool, and Opus disabled thinking at xhigh/max.
- AND the test performs: validateRequest for each invalid request and valid adjacent controls.
- THEN Each invalid control returns UnsupportedCapability with the exact field. Valid controls remain unchanged. Dispatch count is zero for invalid requests.

### Requirement: R-M3-003 Source-bound capability resolution

When a provider request resolves, the Foreman provider registry SHALL bind its profile hash, transport version, source manifest hash and capability evidence.

#### Scenario: T-M3-003 Source-bound capability resolution

- WHEN the following fixture is prepared: A sourced profile with supported, unsupported, unknown and verified capability fields.
- AND the test performs: resolveRequest for an explicit model and transport.
- THEN Resolved request retains all evidence identities and unknown fields. Unverified required capabilities return CapabilityUnverified.

### Requirement: R-M3-004 Separate API and native identities

The Foreman provider adapter SHALL keep API request identities separate from native coding session identities.

#### Scenario: T-M3-004 Separate API and native identities

- WHEN the following fixture is prepared: All four API and four native transport fixtures, including an equal textual response ID and session ID.
- AND the test performs: encodeRequest and decodeIdentity for each fixture.
- THEN Discriminated identities retain provider, exact model, transport and API revision or CLI version. Equal strings do not compare as equal identities.

### Requirement: R-M3-005 Exact prompt channel bytes

When a native transport receives a prompt, the Foreman provider adapter SHALL deliver its exact bytes through a declared prompt channel.

#### Scenario: T-M3-005 Exact prompt channel bytes

- WHEN the following fixture is prepared: UTF-8 prompt containing newlines, quotes, dollar signs and 128 KiB content. Fixtures declare stdin, file or protocol input.
- AND the test performs: start each native fake process or protocol peer and capture delivered bytes.
- THEN Prompt hashes match for each channel. Stdin bytes reach the launcher. An unsupported channel returns PromptChannelUnsupported before spawn.

### Requirement: R-M3-006 No weaker transport fallback

If a transport lacks a requested capability, then the Foreman provider adapter SHALL reject dispatch without changing model, permissions or output behavior.

#### Scenario: T-M3-006 No weaker transport fallback

- WHEN the following fixture is prepared: Native fixture lacks permission round trips or schema output. API fixture lacks grammar support.
- AND the test performs: start with each required capability and inspect captured process/API calls.
- THEN UnsupportedCapability reports the missing field and zero dispatches. No headless, weaker schema or alternate model fallback occurs.

### Requirement: R-M3-007 Semantic stream events

When a provider event arrives, the Foreman provider adapter SHALL emit a normalized event with its provider identity and original semantic status.

#### Scenario: T-M3-007 Semantic stream events

- WHEN the following fixture is prepared: Per-transport started, text, tool, usage, checkpoint, completion, refusal, truncation, malformed and duplicate event fixtures.
- AND the test performs: decodeEvents with fragmented byte chunks and repeated cursors.
- THEN Events use the shared vocabulary. Refusal remains refused, truncation becomes failed/OutputIncomplete, and duplicates retain deduplication identity without another tool dispatch.

### Requirement: R-M3-008 Authorized tool/result correlation

When a provider requests a tool, the Foreman provider adapter SHALL preserve its call identifier and return only a host-authorized tool result.

#### Scenario: T-M3-008 Authorized tool/result correlation

- WHEN the following fixture is prepared: Two parallel tool calls with distinct IDs, invalid arguments, a denied call and a previously recorded tool result.
- AND the test performs: decodeEvents then sendToolResult through a recording host tool port.
- THEN Valid results match originating IDs. Invalid and denied calls perform zero tool effects. A replay reuses the recorded result through the host journal.

### Requirement: R-M3-009 Original host output schema

If final output violates the host schema, then the Foreman provider adapter SHALL return OutputInvalid without producing a completed result.

#### Scenario: T-M3-009 Original host output schema

- WHEN the following fixture is prepared: Provider-native structured output accepts a case-changed enum, missing required field or weakening schema transformation.
- AND the test performs: validateFinal with the original strict host schema.
- THEN OutputInvalid includes a safe field path. No completed event or verified-candidate claim appears.

### Requirement: R-M3-010 Opaque continuation binding

When a continuation is stored or resumed, the Foreman provider adapter SHALL preserve opaque reasoning bytes and their originating model, transport and prefix binding.

#### Scenario: T-M3-010 Opaque continuation binding

- WHEN the following fixture is prepared: OpenAI reasoning items, xAI encrypted thinking, Fable thinking blocks and Gemini Interactions thought steps with exact byte hashes.
- AND the test performs: encodeContinuation then resume with matching and changed model, transport and prefix.
- THEN Matching round trips preserve hashes and tool IDs. Changed bindings return ContinuationMismatch. No opaque reasoning appears in text events or research exports.

### Requirement: R-M3-011 Observed cancellation outcomes

When cancellation is requested, the Foreman provider adapter SHALL report request, acknowledgement, local cleanup and observed remote outcome separately.

#### Scenario: T-M3-011 Observed cancellation outcomes

- WHEN the following fixture is prepared: OpenAI and Gemini asynchronous cancellation, xAI unverified remote cancellation, Claude SIGTERM versus interrupt, and a native process tree.
- AND the test performs: cancel under Effect scope with a fake clock, then observe terminal events.
- THEN Local children exit within the configured cleanup bound. Remote outcome remains pending, unknown or unsupported until observed. No local signal fabricates remote cancelled.

### Requirement: R-M3-012 Unavailable and uncertain resume

If continuation retention expired or remote outcome is unknown, then the Foreman provider adapter SHALL return ResumeUnavailable or OutcomeUnknown without automatic redispatch.

#### Scenario: T-M3-012 Unavailable and uncertain resume

- WHEN the following fixture is prepared: Expired API ID, interrupted stream before receipt, Gemini in_progress interaction, and missing native session.
- AND the test performs: resume with the persisted provider identity and cursor.
- THEN Expired state returns ResumeUnavailable. Unknown outcome returns OutcomeUnknown. In-progress Google interaction is observed before chaining. New dispatch count stays zero.

### Requirement: R-M3-013 Independent readiness facts

When readiness is inspected, the Foreman provider adapter SHALL report discovery, authentication, currency, model identity and capabilities as separate evidence-bearing facts.

#### Scenario: T-M3-013 Independent readiness facts

- WHEN the following fixture is prepared: Installed old CLI, authenticated account, unavailable exact model and unknown permission capability.
- AND the test performs: probe using read-only fake commands and metadata endpoints.
- THEN Each fact has independent value, evidence kind, observation time and safe diagnostic. No update, login or model workload runs in a metadata-only probe.

### Requirement: R-M3-014 Unknown authentication diagnosis

If an authentication probe times out or cannot parse its response, then the Foreman provider adapter SHALL report unknown without a login instruction.

#### Scenario: T-M3-014 Unknown authentication diagnosis

- WHEN the following fixture is prepared: Timeout, network failure, changed banner, explicit signed-out response and explicit signed-in response.
- AND the test performs: probe and render diagnostic for each fixture.
- THEN Uncertain responses report unknown. Only explicit signed-out evidence reports not-authenticated and login remediation. Secrets are absent from diagnostics.

### Requirement: R-M3-015 Observed exact model identity

When observed model identity differs from the requested profile, the Foreman provider adapter SHALL return ModelMismatch and retain both identities.

#### Scenario: T-M3-015 Observed exact model identity

- WHEN the following fixture is prepared: A native CLI routes gpt-6-astra to another model, or provides no trustworthy identity metadata.
- AND the test performs: qualifyIdentity using protocol metadata rather than generated answer text.
- THEN Mismatch returns ModelMismatch. Missing metadata remains unknown and unusable for exact-model qualification. No self-reported answer establishes identity.

### Requirement: R-M3-016 Complete contract fixture matrix

The Foreman provider contract suite SHALL exercise each advertised model and transport combination with provider-specific positive and negative fixtures.

#### Scenario: T-M3-016 Complete contract fixture matrix

- WHEN the following fixture is prepared: Six profiles by four family-specific API/native pairs, with unsupported cells declared explicitly.
- AND the test performs: npm run test:providers after wiring the planned script to scripts/run-tests.ts.
- THEN Fixture report covers every declared cell, chunk boundaries, limits, tools, refusal, malformed output, continuity and cancellation. Unsupported cells have negative tests.

### Requirement: R-M3-017 Bounded live qualification

When an authorized live qualification runs, the Foreman provider adapter SHALL enforce its explicit account, model, transport, time and spend bounds.

#### Scenario: T-M3-017 Bounded live qualification

- WHEN the following fixture is prepared: Explicit selected account and exact installed transport, at most two tool calls, max 30,000 tokens, 180 seconds and USD 5 per cell.
- AND the test performs: foreman providers qualify --profile <exact-id> --transport <id> --limits qualification.json for each claimed cell.
- THEN Report records observed identity, versions, source/profile hashes, requested and observed lifecycle outcomes, usage and failures. Cap exhaustion stops the cell without widening limits.

### Requirement: R-M3-018 Truthful support evidence

When provider support is displayed, the Foreman provider registry SHALL distinguish documented capabilities from fixture-tested and live-qualified capabilities.

#### Scenario: T-M3-018 Truthful support evidence

- WHEN the following fixture is prepared: Documented-only, fixture-only, current live-qualified, expired and changed-version evidence records.
- AND the test performs: foreman providers list --json and resolve a required capability.
- THEN Only matching live evidence labels a cell live-qualified. Missing or stale evidence stays explicit. Fixture success alone cannot label a model ready.

### Requirement: R-M3-019 Bounded Pel generation port

When Pel generation is requested, the Foreman provider adapter SHALL perform one exact-profile generation attempt using the selected grammar capability or structured envelope.

#### Scenario: T-M3-019 Bounded Pel generation port

- WHEN the following fixture is prepared: M2 GenerationRequest with exact modelProfileId, transportId, grammar mode, prompt, catalog, attempt index and {pelSource:string} envelope.
- AND the test performs: ProviderGenerationPort.generate with supported grammar, envelope-only, invalid envelope and 1 MiB overflow fixtures.
- THEN Each call dispatches at most one request. Output is a validated envelope within limits. Unsupported grammar fails explicitly. The adapter neither repairs nor executes Pel.

### Requirement: R-M3-020 Usage accounting and admitted limits

When usage or a request limit is observed, the Foreman provider adapter SHALL preserve accounting dimensions and enforce the stricter admitted limit.

#### Scenario: T-M3-020 Usage accounting and admitted limits

- WHEN the following fixture is prepared: Each profile has cache-read/write counters, dated pricing metadata, long-context thresholds and missing cost fields. Requests exhaust tokens, time and tool bounds.
- AND the test performs: Normalize usage and run each bounded stream under a fake clock and recording host reservation port.
- THEN Observed counters and price identity survive normalization. Unknown cost remains unknown with conservative reservation. Limits stop the stream without widening budget or silently retrying.

