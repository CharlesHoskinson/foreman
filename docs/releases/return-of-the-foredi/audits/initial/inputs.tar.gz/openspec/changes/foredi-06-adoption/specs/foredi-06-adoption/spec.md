# Install, migrate and use Return of the ForeDi

All scenarios are planned tests. This change records no runtime qualification or measured release completion.

## ADDED Requirements

### Requirement: R-M6-001 Clean Node.js installation

When a clean installation completes, the Foreman installer SHALL provide the compiled Node.js 24 CLI and matching Pel examples.

#### Scenario: T-M6-001 Clean Node.js installation

- WHEN the following fixture is prepared: A clean temporary directory with Node.js 24, no checkout, no vault and no global TypeScript runner.
- AND the test performs: Install the candidate archive using its documented install command, then run foreman --version and foreman check examples/pel/implement-review.pel.
- THEN Commands execute from packaged files. Version and source manifest match the archive. The example passes check without provider traffic.

### Requirement: R-M6-002 One-command admitted workflow

When the quickstart starts an admitted workflow, the Foreman CLI SHALL execute the supplied Pel file with one foreman run command.

#### Scenario: T-M6-002 One-command admitted workflow

- WHEN the following fixture is prepared: Clean installed product, a prepared repository with configured project authority and qualified fake Grok/Sol profiles.
- AND the test performs: foreman run examples/pel/implement-review.pel, then foreman status <run-id> --json.
- THEN One command starts implementation, host verification and independent review. Status names the actual task, exact model and terminal outcome.

### Requirement: R-M6-003 Installation prerequisite diagnosis

If installation prerequisites are missing, then the Foreman installer SHALL report the missing prerequisite before changing the existing installation.

#### Scenario: T-M6-003 Installation prerequisite diagnosis

- WHEN the following fixture is prepared: Node.js 22 fixture, missing archive file, or invalid archive manifest with an existing working installation.
- AND the test performs: Run the planned TypeScript install command against each fixture.
- THEN InstallPrerequisiteMissing or PackageIntegrityMismatch names the cause. Existing installed bytes and executable entry point remain unchanged.

### Requirement: R-M6-004 Useful executable examples

The Foreman example collection SHALL include sequential work, parallel work, bounded rework, review, race cancellation, recovery and research preparation.

#### Scenario: T-M6-004 Useful executable examples

- WHEN the following fixture is prepared: Packaged examples/pel corpus and deterministic fake provider transcripts.
- AND the test performs: foreman check each example, then execute each through the installed test harness.
- THEN Every file parses and admits under its documented capabilities. Observable outputs demonstrate its named behavior and contain no implicit publication.

### Requirement: R-M6-005 Exact profile examples

When an example selects a model, the Foreman CLI SHALL display the exact profile, transport and readiness evidence before execution.

#### Scenario: T-M6-005 Exact profile examples

- WHEN the following fixture is prepared: Six profile examples selecting grok-4.6, claude-opus-5, claude-fable-5-1, gpt-6-astra, gpt-5.6-sol and gemini-3.8-flash.
- AND the test performs: foreman plan each profile example and foreman providers list --json.
- THEN All six exact IDs remain visible. Unqualified accounts or transports remain unavailable. Missing readiness does not trigger a fallback or claim a tested model.

### Requirement: R-M6-006 Unavailable provider failure

If an example's required provider is unavailable, then the Foreman CLI SHALL explain the missing capability without starting the workflow.

#### Scenario: T-M6-006 Unavailable provider failure

- WHEN the following fixture is prepared: Documented example with unavailable model identity or unverified native permission support.
- AND the test performs: foreman run the example using its documented command.
- THEN Nonzero exit reports ModelUnavailable or CapabilityUnverified with actionable configuration details. Provider call, reservation and worktree counts remain zero.

### Requirement: R-M6-007 Legacy import and parity

When a supported legacy workflow is imported, the Foreman migration tool SHALL emit Pel source and a parity report.

#### Scenario: T-M6-007 Legacy import and parity

- WHEN the following fixture is prepared: Frozen corpus for implement/verify/review, bounded rework, parallel work, race, interruption and Council review with expected traces.
- AND the test performs: foreman migrate <legacy-input> --out <file.pel>, then check and execute through fake host fixtures.
- THEN Output contains one authored Pel file and derived diagnostics. New traces preserve required effects, identities, limits, terminal decisions and independent review.

### Requirement: R-M6-008 Active legacy ownership

While a legacy run remains active, the Foreman migration tool SHALL preserve its current execution owner and durable history.

#### Scenario: T-M6-008 Active legacy ownership

- WHEN the following fixture is prepared: An active legacy run with a lease, reservations and completed tool receipts.
- AND the test performs: Attempt migration and resume through the new CLI.
- THEN Migration returns ActiveLegacyRun. The existing owner continues. Journal hashes and budgets remain unchanged. No second controller starts.

### Requirement: R-M6-009 Historical decoding and thin adapters

When a legacy execution path is retired, the Foreman CLI SHALL preserve historical status and resume diagnostics through the existing record decoders.

#### Scenario: T-M6-009 Historical decoding and thin adapters

- WHEN the following fixture is prepared: Terminal legacy histories and the retired shell entry-point cohort identified in design.md.
- AND the test performs: Read each history using foreman status, invoke each supported compatibility adapter, and search callers.
- THEN Historical identities remain readable. Thin adapters forward exact argv, env, stdout, stderr and exit status to one compiled entry point. Retired schedulers have no active callers.

### Requirement: R-M6-010 Reproducible baseline comparison

When simplification is measured, the Foreman measurement tool SHALL compare the frozen baseline and candidate with identical cohort and counting rules.

#### Scenario: T-M6-010 Reproducible baseline comparison

- WHEN the following fixture is prepared: Pinned baseline 441c3fb9f6acb2656760d03cc79e7c706fb8b7dd, frozen cohort, exact tokenizer and candidate revision.
- AND the test performs: node skills/foreman/runtime/dist/pel-simplification.js --baseline <manifest> --candidate <revision>.
- THEN Report includes old and replacement production lines, generated/test/archive exclusions, command count, instruction tokens, owners and total production growth with file hashes.

### Requirement: R-M6-011 Measured net simplification

The Foreman migrated workflow cohort SHALL reduce orchestration glue lines by at least 40 percent and required instruction tokens by at least 50 percent.

#### Scenario: T-M6-011 Measured net simplification

- WHEN the following fixture is prepared: The frozen implementation cohort, all new replacement glue, and the complete mandatory quickstart instruction corpus.
- AND the test performs: Run the simplification measurement against the candidate and compare its acceptance fields.
- THEN Net glue reduction is at least 0.40 and instruction reduction at least 0.50. Moving code or instructions outside old paths does not remove them from counts.

### Requirement: R-M6-012 Verification receipt reuse

When an unchanged candidate repeats verification, the Foreman execution owner SHALL reuse the matching host receipt and report one full verification execution.

#### Scenario: T-M6-012 Verification receipt reuse

- WHEN the following fixture is prepared: Migrated standard workflow runs twice with identical candidate, base, checks, dependencies, tools and environment.
- AND the test performs: Execute the corpus twice, then change each verification binding in a table-driven test.
- THEN Identical bindings invoke the full verifier once. Any changed binding invokes it again. Each run has one control-flow owner and one event history.

### Requirement: R-M6-013 Source-linked research query

When a user requests research context, the Foreman research reader SHALL return bounded source-linked results with claim status and freshness.

#### Scenario: T-M6-013 Source-linked research query

- WHEN the following fixture is prepared: Repository research bundle containing paper claims, adopted decisions, hypotheses, coverage warnings and provider source captures.
- AND the test performs: foreman research query "Fable forced tools" --json --limit 5 without a vault path.
- THEN Results include source locator, source hash, capture time, claim class and freshness. Unsupported extraction remains visible. Hidden reasoning and secrets are absent.

### Requirement: R-M6-014 Atomic research freshness

When research inputs change, the Foreman research reader SHALL mark derived notes and graphs stale until a matching refresh completes.

#### Scenario: T-M6-014 Atomic research freshness

- WHEN the following fixture is prepared: A copied bundle with one changed source hash, one missing source and interrupted refresh metadata.
- AND the test performs: foreman research status --json, then foreman research refresh --bundle <path> against a complete captured bundle.
- THEN Stale and missing inputs appear explicitly. Refresh atomically publishes matching derived hashes and provenance. Interrupted refresh preserves the previous readable snapshot.

### Requirement: R-M6-015 Optional Obsidian context

Where an external Obsidian vault is configured, the Foreman research reader SHALL expose its linked context without granting it execution authority.

#### Scenario: T-M6-015 Optional Obsidian context

- WHEN the following fixture is prepared: Optional temporary Obsidian vault with wikilinks, advisory graph nodes and a note containing an execution instruction.
- AND the test performs: foreman research query with --vault <path>, then remove the vault and run the standard Pel example.
- THEN Query preserves note links and provenance. Note instructions cannot grant capabilities. Core workflow still works without the vault and reports optional context absence.

### Requirement: R-M6-016 Matching release package

When a release package is assembled, the Foreman packaging tool SHALL include matching runtime, examples, profile evidence and migration documentation.

#### Scenario: T-M6-016 Matching release package

- WHEN the following fixture is prepared: Candidate build with generated runtime, source manifest, support matrix and unresolved v0.5 obligation references.
- AND the test performs: Build and inspect the archive, then run npm run verify and the clean-install suite on its unchanged candidate.
- THEN Archive hashes match the candidate. Support labels reflect exact qualified cells. Outstanding v0.5 obligations retain their status. No invented numerical release version appears.

### Requirement: R-M6-017 Compatible runtime rollback

When an installed release rolls back, the Foreman rollback tool SHALL restore the compatible runtime without rewriting execution history.

#### Scenario: T-M6-017 Compatible runtime rollback

- WHEN the following fixture is prepared: Current and previous package manifests with supported journal/checkpoint schema versions, plus an incompatible active checkpoint fixture.
- AND the test performs: foreman install rollback --to <installed-version> with each fixture.
- THEN Compatible rollback restores package bytes and leaves history intact. Incompatible active state returns RollbackIncompatible with an actionable recovery path.

### Requirement: R-M6-018 Safe support diagnostics

When support diagnostics are exported, the Foreman CLI SHALL report reproducible feature context with secret and reasoning redaction.

#### Scenario: T-M6-018 Safe support diagnostics

- WHEN the following fixture is prepared: Failed packaged quickstart with a model mismatch, run IDs, provider evidence, source version, secret fixture and opaque reasoning blob.
- AND the test performs: foreman support export --run <id> --out <bundle>.
- THEN Bundle includes version, platform, exact profile/transport, safe failure, relevant event IDs and reproduction command. Secrets, tokens and hidden reasoning are absent.

