# Return of the ForeDi: Pel plan authoring

The command and analysis contracts are in [design.md](../../design.md).
Tests are planned implementation contracts.

## ADDED Requirements

### Requirement: R-M2-001 Source check command

When an operator checks a Pel file, the Foreman authoring service SHALL report source validity against the selected immutable authoring snapshot.

#### Scenario: T-M2-001 Source check command

- WHEN Valid arithmetic source, unmatched delimiter, unknown symbol, mixed argument call, and quoted unknown symbol.
- AND foreman check <fixture.pel> --context fixtures/authoring-snapshot.json --json.
- THEN Valid and quoted-data fixtures exit 0. Invalid fixtures exit 2 with the expected PEL_PARSE, PEL_UNBOUND_SYMBOL, or PEL_ARGUMENT_MODE span.

### Requirement: R-M2-002 Check input failures

If a selected authoring input is unavailable or invalid, then the Foreman authoring service SHALL return an input diagnostic without probing external services.

#### Scenario: T-M2-002 Check input failures

- WHEN Missing source, oversized snapshot, invalid registry digest, and unsupported installed profile with provider/network/process/write spies.
- AND foreman check <fixture.pel> --context <snapshot.json> --json.
- THEN Input failures exit 3 and name the failing input. All external probe, provider, process, write, and reservation counts remain zero.

### Requirement: R-M2-003 Pure effect preview

When a Pel file is previewed, the Foreman authoring service SHALL derive host-effect descriptions without executing those effects.

#### Scenario: T-M2-003 Pure effect preview

- WHEN Sequential task/verify/review Pel example and file-read adapter limited to source plus selected snapshot.
- AND foreman plan examples/pel/sequential.pel --context fixtures/authoring-snapshot.json --json.
- THEN The preview shows three ordered host effects with exact model profiles, capabilities, and gates. No provider call, process, write, lock, or reservation occurs.

### Requirement: R-M2-004 Native control-flow preview

When preview values remain unresolved, the Foreman authoring service SHALL preserve native control-flow alternatives and explain their dependencies.

#### Scenario: T-M2-004 Native control-flow preview

- WHEN Unknown Boolean host result feeding if, a bounded unknown collection feeding for, and do/async with overlapping worktree writes.
- AND checkPel then planPel using schema-constrained host descriptors.
- THEN Both possible branches remain visible, the loop shows its iteration bound, and overlapping writes show a serialization edge. No unresolved value appears as success.

### Requirement: R-M2-005 Unsupported effects

If a reachable effect violates the authoring snapshot, then the Foreman authoring service SHALL reject it with the source location and violated constraint.

#### Scenario: T-M2-005 Unsupported effects

- WHEN Calls to known descriptors with denied capability, unsupported effect kind, unavailable exact model/transport pair, and invalid output schema.
- AND checkPel each hostile fixture.
- THEN PEL_CAPABILITY_DENIED, PEL_UNSUPPORTED_EFFECT, PEL_PROFILE_UNSUPPORTED, or PEL_SCHEMA identifies the offending call. No alternate model is substituted.

### Requirement: R-M2-006 Finite dynamic regions

When future effects depend on unresolved values, the Foreman authoring service SHALL require finite capability, resource, model, and resource-consumption envelopes.

#### Scenario: T-M2-006 Finite dynamic regions

- WHEN Unknown path constrained to workspace A, unknown collection bounded to 4 iterations, unknown callable with two registered alternatives, and versions without bounds.
- AND checkPel then planPel each dynamic fixture.
- THEN Bounded fixtures produce bounded-dynamic regions with all envelope fields. Missing bounds or arbitrary unknown callable values fail with PEL_DYNAMIC_EFFECT_UNBOUNDED.

### Requirement: R-M2-007 Binding invalidation

When any source or environment binding changes, the Foreman authoring service SHALL require a newly checked preview.

#### Scenario: T-M2-007 Binding invalidation

- WHEN One checked preview followed by independent mutations to whitespace, language profile, registry, provider profiles, policy, and artifact digest.
- AND Compute PlanBindingV1 and validate each mutated exported preview against the current snapshot.
- THEN Every mutation invalidates the previous binding. Equivalent ASTs with different source bytes still have different source digests. Edited capability JSON is rejected.

### Requirement: R-M2-008 Explicit bounded generation

When an operator requests natural-language generation, the Foreman authoring service SHALL produce locally checked Pel through the selected exact model and transport.

#### Scenario: T-M2-008 Explicit bounded generation

- WHEN Fixture generation port for gpt-6-astra/openai-responses with grammar unsupported, returning {pelSource:"(+ 1 2)"}.
- AND foreman plan --prompt "add one and two" --model gpt-6-astra --transport openai-responses --json.
- THEN One envelope-mode request occurs. Output contains accepted source and a preview returning 3. No generated host operation executes and model identity is unchanged.

### Requirement: R-M2-009 Repair exhaustion

If three generated candidates fail local validation, then the Foreman authoring service SHALL stop with all attempt diagnostics and no accepted plan.

#### Scenario: T-M2-009 Repair exhaustion

- WHEN Fixture provider returns malformed Pel on attempt 0, a forbidden capability on attempt 1, and an unbounded dynamic call on attempt 2.
- AND Run generatePelPlan with maxRepairs=2 and a finite generation budget.
- THEN Exactly three generation calls occur. PEL_GENERATION_EXHAUSTED carries all diagnostic sets and cumulative usage. CLI exits 4 and dispatch count is zero.

### Requirement: R-M2-010 Generation bounds and fatal failures

If generation exceeds its limits or encounters a fatal provider failure, then the Foreman authoring service SHALL stop without further repair calls.

#### Scenario: T-M2-010 Generation bounds and fatal failures

- WHEN Fake-clock cases for 60-second attempt timeout, 180-second total deadline, exhausted cost budget, cancellation, auth failure, refusal, and observed model mismatch.
- AND Run generatePelPlan under an Effect scope and advance the fixture clock to each boundary.
- THEN The scope closes, no subsequent request starts, cumulative usage remains visible, and a typed cause identifies timeout, budget, cancellation, or provider failure.

### Requirement: R-M2-011 Operator source guidance

When an operator receives a diagnostic, the Foreman authoring service SHALL show the source range, cause, and applicable registered usage.

#### Scenario: T-M2-011 Operator source guidance

- WHEN Mixed positional/named fm/task call, unsupported model, unresolved branch, and unknown symbol near a registered function name.
- AND Render human and JSON check/plan output for each fixture.
- THEN Human output includes filename, line, column, caret range, cause, and useful signature. JSON preserves structured fields and unresolved reasons without invented success.

### Requirement: R-M2-012 Draft revision tools

When an operator edits an interactive draft, the Foreman authoring service SHALL preserve bounded revision history and recheck each source revision.

#### Scenario: T-M2-012 Draft revision tools

- WHEN A draft session uses replace-expression, replace-suffix, replace-program, history, undo, completion, export, abort, and a run-bound continuation input.
- AND Drive pel-draft-session through fixture readline input, including 101 small revisions and a large revision sequence.
- THEN Each replacement creates a new digest, undo restores exact bytes, history stays within 100 revisions and 16 MiB, export writes source, and run-bound input returns PEL_DRAFT_EXECUTED.

### Requirement: R-M2-013 Runnable authoring examples

When installed examples are checked and previewed, the Foreman authoring service SHALL produce their documented native Pel outcomes.

#### Scenario: T-M2-013 Runnable authoring examples

- WHEN Sequential, conditional, parallel, and repair examples with the version-matched fixture authoring snapshot and a clean installed Node.js 24 bundle.
- AND Run installed foreman check and plan for each example, then run the corrected repair variant.
- THEN Valid examples exit 0 with expected effects and dependencies. The malformed repair fixture exits 2. Its corrected named call exits 0. No example executes provider work.

